<?php
session_start();
require_once '../Model/KpiModel.php';

class LearningController {
    private $model;

    public function __construct($dbConnection) {
        $this->model = new KpiModel($dbConnection);
    }

    public function handleFormSubmission() {
        // Require login
        if (!isset($_SESSION['DIVISION'])) {
            echo "Unauthorized access";
            exit;
        }

        // ---- Collect raw inputs (do not fail early; we'll validate below) ----
        $categoryId  = $_POST['categoryId']  ?? null;
        $year        = $_POST['year']        ?? null;
        $frequencyId = $_POST['frequencyId'] ?? null;
        $itemvalue   = $_POST['itemvalue']   ?? null;
        $airportId   = $_POST['airportId']   ?? null;

        // Optional fields used by some KPIs
        $description   = $_POST['description']   ?? '';
        $travelType    = $_POST['travel_type']   ?? 0;               // kept for compatibility
        $trainingType  = $_POST['trainingId']    ?? null;            // NEW: from "Number of trainings" form
        $month         = $_POST['month']         ?? null;            // used when frequencyId implies monthly
        $quarter       = $_POST['quarter']       ?? null;            // used when frequencyId implies quarterly

        // ---- Sanitize / validate basics ----
        $categoryId  = filter_var($categoryId,  FILTER_VALIDATE_INT);
        $year        = filter_var($year,        FILTER_VALIDATE_INT);
        $frequencyId = filter_var($frequencyId, FILTER_VALIDATE_INT);
        // Accept numeric string for itemvalue; percentage or counts allowed
        $itemvalue   = filter_var($itemvalue,   FILTER_VALIDATE_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $airportId   = filter_var($airportId,   FILTER_VALIDATE_INT);
        $description = is_string($description) ? trim($description) : '';

        // Optional typed fields
        $travelType   = ($travelType === '' || $travelType === null) ? 0 : filter_var($travelType, FILTER_VALIDATE_INT);
        $trainingType = ($trainingType === '' || $trainingType === null) ? null : filter_var($trainingType, FILTER_VALIDATE_INT);
        $month        = ($month === '' || $month === null) ? null : filter_var($month, FILTER_VALIDATE_INT);
        $quarter      = ($quarter === '' || $quarter === null) ? null : filter_var($quarter, FILTER_VALIDATE_INT);

        $errors = [];
        if ($categoryId === false)  $errors[] = "Invalid category ID";
        if ($year === false || $year < 2000 || $year > (int)date('Y') + 2) $errors[] = "Invalid year";
        if ($frequencyId === false) $errors[] = "Invalid frequency ID";
        if ($itemvalue === false)   $errors[] = "Invalid item value";
        if ($airportId === false)   $errors[] = "Invalid airport ID";

        // Division gating: Learning & Growth categories
        // Keep as you had: HR + shared category 30
        $allowedCategories = [27, 28, 29, 30];
        if (!in_array($categoryId, $allowedCategories, true)) {
            $errors[] = "Invalid category for Learning & Growth";
        }

        // Frequency to period fields:
        // 1 = Monthly -> require/use month
        // 2 = Quarterly -> require/use quarter
        // 3 = Annual -> month/quarter stored as 0
        // (If you have different codes, adjust as needed.)
        $periodMonth = 0;
        $periodQuarter = 0;

        if ($frequencyId === 1) {
            // Monthly
            if ($month === null || $month === false || $month < 1 || $month > 12) {
                $errors[] = "Month (1-12) is required for monthly entries";
            } else {
                $periodMonth = (int)$month;
            }
        } elseif ($frequencyId === 2) {
            // Quarterly
            if ($quarter === null || $quarter === false || $quarter < 1 || $quarter > 4) {
                $errors[] = "Quarter (1-4) is required for quarterly entries";
            } else {
                $periodQuarter = (int)$quarter;
            }
        } else {
            // Annual or other -> leave as 0
            $periodMonth = 0;
            $periodQuarter = 0;
        }

        // Special handling (optional): Employee Turnover (cat 29)
        // If you later change the form to post 'left_employees' & 'avg_employees',
        // you can auto-compute percentage here. Current form sends a single itemvalue,
        // so we keep existing behavior and store the provided value as-is.
        if ($categoryId === 29) {
            // Example (uncomment if your form is updated):
            // $left = isset($_POST['left_employees']) ? floatval($_POST['left_employees']) : null;
            // $avg  = isset($_POST['avg_employees']) ? floatval($_POST['avg_employees']) : null;
            // if ($left !== null && $avg !== null && $avg > 0) { $itemvalue = ($left / $avg) * 100.0; }
        }

        if (!empty($errors)) {
            echo implode(", ", $errors);
            exit;
        }

        // Get division_id from session division map
        $divisionMap = [
            'HR'  => 18,
            'MKT' => 17,
            'AM'  => 13,
            'SCM' => 16,
            'Sec' => 14,
            'ANS' => 12,
            'EANE'=> 15,
        ];
        $divisionId = $divisionMap[$_SESSION['DIVISION']] ?? 0;

        // ---- Persist ----
        $result = $this->model->saveKpi(
            $categoryId,
            $year,
            $periodMonth,
            $periodQuarter,
            $frequencyId,
            $itemvalue,
            $airportId,
            // keep old param order for compatibility:
            $travelType,   // travel_type (still supported)
            $description,  // description
            $divisionId,   // division_id
            $trainingType  // NEW: training_type (nullable, used for cat 28)
        );

        if ($result === true) {
            echo "Success";
        } else {
            echo "Error saving data: " . ($result ?: 'Unknown error');
        }
    }
}

// DB connection
$dbConnection = new mysqli('localhost', 'root', '', 'kpi-dashboard');
if ($dbConnection->connect_error) {
    die("Database connection failed: " . $dbConnection->connect_error);
}

$controller = new LearningController($dbConnection);
$controller->handleFormSubmission();
