<?php
session_start();
require_once '../database/db.php';

// Show errors for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is logged in
if (!isset($_SESSION['USER'])) {
    header("Location: ../view/login.php");
    exit;
}

// Validate POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../add-user.php?error=Invalid request method");
    exit;
}

// Get and sanitize data from the form
$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
$display_name = trim($_POST['display_name'] ?? '');
$user_type = $_POST['user_type'] ?? '';
$division_id = $_POST['division_id'] ?? '';

// Validate required fields
if (empty($username) || empty($password) || empty($display_name) || empty($user_type)) {
    header("Location: ../add-user.php?error=All fields are required");
    exit;
}

// For non-superadmin users, division is required
if ($user_type !== 'superadmin' && empty($division_id)) {
    header("Location: ../add-user.php?error=Division is required for this user type");
    exit;
}

// Set division_id to NULL for superadmin users
if ($user_type === 'superadmin') {
    $division_id = null;
}

// Validate user type
$allowed_types = ['admin', 'division_user', 'superadmin'];
if (!in_array($user_type, $allowed_types)) {
    header("Location: ../add-user.php?error=Invalid user type");
    exit;
}

try {
    // Get database connection
    $conn = (new db())->getConnection();
    
    if (!$conn) {
        throw new Exception("Database connection failed");
    }
    
    // Check if username already exists
    $check_query = "SELECT UserName FROM news_user WHERE UserName = ?";
    $check_stmt = $conn->prepare($check_query);
    
    if (!$check_stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $check_stmt->bind_param("s", $username);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows > 0) {
        $check_stmt->close();
        $conn->close();
        header("Location: ../add-user.php?error=Username already exists");
        exit;
    }
    
    $check_stmt->close();
    
    // Hash password (consider using password_hash() instead of md5 for better security)
    $hashed_password = md5($password);
    
    // Insert new user into database
    $insert_query = "INSERT INTO news_user (UserName, Password, display_name, UserType, division_id) VALUES (?, ?, ?, ?, ?)";
    $insert_stmt = $conn->prepare($insert_query);
    
    if (!$insert_stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    // Bind parameters - use "i" for integer (division_id) and "s" for strings
    if ($division_id === null) {
        $insert_stmt->bind_param("ssssi", $username, $hashed_password, $display_name, $user_type, $division_id);
    } else {
        $division_id = (int)$division_id; // Ensure it's an integer
        $insert_stmt->bind_param("ssssi", $username, $hashed_password, $display_name, $user_type, $division_id);
    }
    
    if ($insert_stmt->execute()) {
        $insert_stmt->close();
        $conn->close();
        
        // Success - redirect with success message
        header("Location: ../add-user.php?success=1");
        exit;
    } else {
        throw new Exception("Execute failed: " . $insert_stmt->error);
    }
    
} catch (Exception $e) {
    // Log error (in production, log to file instead of displaying)
    error_log("Add user error: " . $e->getMessage());
    
    // Close connections if open
    if (isset($insert_stmt)) $insert_stmt->close();
    if (isset($check_stmt)) $check_stmt->close();
    if (isset($conn)) $conn->close();
    
    // Redirect with error message
    header("Location: ../add-user.php?error=" . urlencode("An error occurred while creating the user"));
    exit;
}
?>