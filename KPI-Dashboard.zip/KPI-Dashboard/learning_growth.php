<?php
include 'includes/header.php';
include 'includes/leftnav.php';
?>

<div id="toast-success" style="
    position: fixed;
    top: 60px;
    right: 20px;
    z-index: 9999;
    background-color: #28a745;
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    display: none;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
">
    Data saved successfully!
</div>

			<main class="content">
				<div class="container-fluid">

					<div class="header">
						<h1 class="header-title">
							Learning & Growth
						</h1>
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="dashboard-default.html">Main</a></li>
								<li class="breadcrumb-item"><a href="#">BSC - Data Management</a></li>
								<li class="breadcrumb-item active" aria-current="page">Learning & Growth</li>
							</ol>
						</nav>

                        <?php if ($division === 'HR'): ?>
            <div class="mb-4 text-end">
                <a href="learning_kpi_view_HR.php" class="btn btn-outline-primary">View Details</a>
            </div>
            <?php endif; ?>
					</div>
					
					<?php if ($_SESSION['DIVISION'] === 'HR') : ?>
					<!-- Employee job satisfaction - HR Only -->
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header' >
                                    <h1 class='card-title mb-0'>Employee job satisfaction</h1>
                                    <h6>Please enter the employee job satisfaction level based on survey (in %). If no survey was conducted this year, indicate "Not Applicable"</h6>
                                </div>                              
                                <div class='card-body ' id="collapseJobSatisfaction">
                                    <div class="mb-3">
                                        <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/learningController.php">
                                            <input type="hidden" name="categoryId" value="27" />
                                            
                                            <div class="col-12">
                                                <label>Year</label>
                                                <select class="form-control" name="year" required>
                                                    <?php 
                                                    $currentYear = date('Y');
                                                    for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                        <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <input type="hidden" name="frequencyId" value="3">
                                            <input type="hidden" name="airportId" value="1">

                                            
                                            <div class="col-12">
                                                <label>Value (%)</label>

                                                <select class="form-control mb-2" id="valueSelector1" onchange="toggleValueInput('1')">
                                                    <option value="enter">Enter Percentage</option>
                                                    <option value="0">Not Applicable</option>
                                                </select>

                                                <div class="input-group mb-2 me-sm-2" id="percentageInput1">
                                                    <div class="input-group-text">%</div>
                                                    <input type="number" 
                                                        min="0" max="100" step="0.01" 
                                                        class="form-control" 
                                                        id="itemvalueInput1"
                                                        name="itemvalue"
                                                        placeholder="0 - 100%">
                                                </div>
                                            </div>
                                            
                                            <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Number of trainings conducted - HR Only -->
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header' >
                                    <h1 class='card-title mb-0'>Number of trainings conducted (Local & Foreign)</h1>
                                </div>                              
                                <div class='card-body ' id="collapseTrainings">
                                    <div class="mb-4">
                                        <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/learningController.php">
                                            <input type="hidden" name="categoryId" value="28" />
                                            
                                            <div class="col-12">
                                                <label>Year</label>
                                                <select class="form-control" name="year" required>
                                                    <?php 
                                                    $currentYear = date('Y');
                                                    for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                        <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <input type="hidden" name="frequencyId" value="3">
                                            <input type="hidden" name="airportId" value="1">

                                            <div class="col-12">
                                                <label>Training Type</label>
                                                <select class="form-control" name="trainingId" required>
                                                    <option value="" disabled selected>Select Training Type</option>
                                                    <option value="1">Local</option>
                                                    <option value="2">Foreign</option>
                                                </select>
                                            </div>

                                             <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>
                                            
                                            <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                 
                    <!-- Employee turnover - HR Only -->
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header'>
                                    <h1 class='card-title mb-0'>Employee turnover</h1>
                                    <h6>Provide the employee turnover rate for this year. Use the formula: 
                                        (No. of employees who left ÷ average number of employees during the year) × 100
                                    </h6>
                                </div>
                                <div class='card-body' id="collapseTurnover">
                                    <div class="mb-3">
                                        <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/learningController.php" id="turnoverForm">
                                            <input type="hidden" name="categoryId" value="29" />

                                            <!-- Year Selection -->
                                            <div class="col-12">
                                                <label>Year</label>
                                                <select class="form-control" name="year" required>
                                                    <?php 
                                                    $currentYear = date('Y');
                                                    for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                        <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <input type="hidden" name="frequencyId" value="3">
                                            <input type="hidden" name="airportId" value="1">
                                            <input type="hidden" name="itemvalue" id="dynamicItemValue">
                                            <input type="hidden" name="description" id="dynamicDescription">

                                            <!-- First Value Field (e.g., Employees Left) -->
                                            <div class="col-12">
                                                <label>Value (Employees Left)</label>
                                                <div class="input-group mb-2 me-sm-2">
                                                    <div class="input-group-text">Value</div>
                                                    <input type="number" step="0.01" class="form-control" name="employees_left" placeholder="Employees Left" required min="0">
                                                </div>
                                                <button type="button" class="btn mt-3 btn-primary" onclick="submitValue('employees_left', 'Employees Left')">Submit Employees Left</button>
                                            </div>

                                            <!-- Second Value Field (e.g., Average Number of Employees) -->
                                            <div class="col-12">
                                                <label>Value (Average Employees)</label>
                                                <div class="input-group mb-2 me-sm-2">
                                                    <div class="input-group-text">Value</div>
                                                    <input type="number" step="0.01" class="form-control" name="average_employees" placeholder="Average Employees" required min="0">
                                                </div>
                                                <button type="button" class="btn mt-3 btn-primary" onclick="submitValue('average_employees', 'Average Employees')">Submit Average Employees</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endif; ?>
                    
                    
                    
<!-- No. of new products / services / process improvements introduced -->
        <div class='row'>
            <div class='col-12'>
                <div class='card'>
                    <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="true" aria-controls="collapse2">
                        <h1 class='card-title mb-0'>No. of new products / services / process improvements introduced </h1>
                        <h6>List and count the number of new products, services, or process improvements introduced by your division during the reporting period. Include a brief description or title for each item.</h6>
                    </div>                              
                    <div class='card-body collapse' id="collapse2">
                        <div class="mb-3">
                            <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                <input type="hidden" name="categoryId" value="30">

                                <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect1" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect1" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                <input type="hidden" name="airportId" value="1">

                                
                       <!-- Description Field for Products / Services / Process Improvements -->
                        <div class="col-12">
                            <label>Description</label>
                            <textarea class="form-control" name="description" rows="1" placeholder="Enter brief description " required></textarea>
                        </div>


                                 <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                <button type="submit" class="btn mt-3  btn-primary">Submit</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
                   
                    
                    

				</div>
			</main>
<?php
include 'includes/footer.php'; 
?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const toast = document.getElementById('toast-success');

    document.querySelectorAll(".kpi-form").forEach(form => {
        form.addEventListener("submit", function(e) {
            e.preventDefault();

            const formData = new FormData(form);
            const submitButton = form.querySelector('button[type="submit"]');

            submitButton.disabled = true;
            submitButton.innerHTML = 'Saving...';

            fetch("Controller/learningController.php", {
                method: "POST",
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(res => {
                if (res.trim() === "Success") {
                    form.reset();
                    showToast("Data saved successfully!", true);
                } else {
                    showToast("Error: " + res, false);
                }
            })
            .catch(error => {
                showToast("AJAX error: " + error.message, false);
            })
            .finally(() => {
                submitButton.disabled = false;
                submitButton.innerHTML = 'Submit';
            });
        });
    });

    function showToast(message, isSuccess) {
        toast.textContent = message;
        toast.style.backgroundColor = isSuccess ? '#28a745' : '#dc3545'; // Green or Red
        toast.style.display = 'block';

        setTimeout(() => {
            toast.style.display = 'none';
        }, 3000);
    }
});

function toggleValueInput(formId) {
    const selector = document.getElementById("valueSelector" + formId);
    const inputGroup = document.getElementById("percentageInput" + formId);
    const inputField = document.getElementById("itemvalueInput" + formId);

    if (selector.value === "0") {
        inputGroup.style.display = "none";
        inputField.value = "0";
    } else {
        inputGroup.style.display = "flex";
        inputField.value = "";
    }
}

// Month restriction functionality
const yearSelects = [
    { year: document.getElementById('yearSelect1'), month: document.getElementById('monthSelect1') },
];

function updateMonths(yearSelect, monthSelect) {
    if (!yearSelect || !monthSelect) return;
    
    const selectedYear = parseInt(yearSelect.value);
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1; // Current month (1-12)

    for (let month = 1; month <= 12; month++) {
        const monthOption = monthSelect.options[month - 1];
        if (monthOption) {
            if (selectedYear < currentYear) {
                monthOption.disabled = false; // All months enabled for past years
            } else if (selectedYear === currentYear) {
                monthOption.disabled = month > currentMonth; // Disable future months for current year
            } else {
                monthOption.disabled = true; // Disable all months for future years
            }
        }
    }
}

// Initialize and set event listeners
yearSelects.forEach(({ year, month }) => {
    if (year && month) {
        // Initialize on page load
        updateMonths(year, month);
        
        // Update when year changes
        year.addEventListener('change', function() {
            updateMonths(year, month);
        });
    }
});

function submitValue(fieldName, description) {
    const form = document.getElementById('turnoverForm');
    const value = parseFloat(document.querySelector(`input[name="${fieldName}"]`).value) || 0;
    if (value < 0) {
        alert(`${description} cannot be negative`);
        return;
    }

    const formData = new FormData(form);
    formData.set('itemvalue', value); // Set the dynamic itemvalue
    formData.set('description', description); // Set the dynamic description

    const submitButton = form.querySelector('button[onclick="submitValue(\'' + fieldName + '\', \'' + description + '\')"]');
    submitButton.disabled = true;
    submitButton.innerHTML = 'Saving...';

    fetch("Controller/learningController.php", {
        method: "POST",
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(res => {
        if (res.trim() === "Success") {
            showToast("Data saved successfully!", true);
        } else {
            showToast("Error: " + res, false);
        }
    })
    .catch(error => {
        showToast("AJAX error: " + error.message, false);
    })
    .finally(() => {
        submitButton.disabled = false;
        submitButton.innerHTML = 'Submit ' + (description === 'Employees Left' ? 'Employees' : description);
    });
}
</script>
