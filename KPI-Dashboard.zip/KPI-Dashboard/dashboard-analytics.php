<?php
session_start();
include 'includes/header.php';
include 'includes/leftnav.php';

// Database connection
$con = new mysqli("localhost", "root", "", "b'kpi'");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get available years from DB
$years = [];
$yearResult = mysqli_query($con, "SELECT DISTINCT year FROM kpi_data ORDER BY year DESC");
while ($row = mysqli_fetch_assoc($yearResult)) {
    $years[] = $row['year'];
}

// Selected year from GET or default to current year
$selectedYear = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Month labels
$months = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
           'August', 'September', 'October', 'November', 'December'];

// Quarter labels for the chart
$quarters = ['Q1(Jan-Mar)', 'Q2(Apr-Jun)', 'Q3(Jul-Sep)', 'Q4(Oct-Dec)'];

// ==================== OPERATIONAL VOLUMES ====================
$totalPAX = mysqli_fetch_assoc(mysqli_query($con, "SELECT SUM(itemvalue) as total FROM kpi_data WHERE categoryId = 48"))['total'] ?? 0;
$totalAC = mysqli_fetch_assoc(mysqli_query($con, "SELECT SUM(itemvalue) as total FROM kpi_data WHERE categoryId = 49"))['total'] ?? 0;
$overflights = mysqli_fetch_assoc(mysqli_query($con, "SELECT SUM(itemvalue) as total FROM kpi_data WHERE categoryId = 50"))['total'] ?? 0;
$cargoHandled = mysqli_fetch_assoc(mysqli_query($con, "SELECT SUM(itemvalue) as total FROM kpi_data WHERE categoryId = 51"))['total'] ?? 0;

// ✅ Sum of all categories (Operational)
$totalOperational = $totalPAX + $totalAC + $overflights + $cargoHandled;

// ==================== FINANCIAL REVENUE ====================
// Aeronautical Revenue (46, 47, 32, 33)
$aeroRevenue = mysqli_fetch_assoc(mysqli_query($con, "
    SELECT SUM(itemvalue) as total 
    FROM kpi_data 
    WHERE categoryId IN (46,47,32,33)
"))['total'] ?? 0;

// Non-Aeronautical Revenue (34 → 45)
$nonAeroRevenue = mysqli_fetch_assoc(mysqli_query($con, "
    SELECT SUM(itemvalue) as total 
    FROM kpi_data 
    WHERE categoryId IN (34,35,36,37,38,39,40,41,42,43,44,45)
"))['total'] ?? 0;

// ✅ Financial Total Revenue
$totalFinancialRevenue = $aeroRevenue + $nonAeroRevenue;

// ✅ Revenue per PAX
$revenuePerPax = ($totalPAX > 0) ? ($totalFinancialRevenue / $totalPAX) : 0;

$latestYear = mysqli_fetch_assoc(mysqli_query($con, "SELECT MAX(year) as latest FROM kpi_data"))['latest'];

// ==================== TOP FIVE OPEX (Updated Query) ====================
$sqlOpex = "SELECT c.category, SUM(k.itemvalue) as total, c.categoryid 
            FROM category c
            LEFT JOIN kpi_data k ON c.categoryid = k.categoryId AND k.year = ?
            WHERE c.parentid IN (69,108,179,182,193,230)
            GROUP BY c.categoryid, c.category
            HAVING total > 0
            ORDER BY total DESC
            LIMIT 5";

$stmtOpex = mysqli_prepare($con, $sqlOpex);
$opexData = [];
$maxOpex = 0;

if ($stmtOpex) {
    mysqli_stmt_bind_param($stmtOpex, "i", $selectedYear);
    mysqli_stmt_execute($stmtOpex);
    $resultOpex = mysqli_stmt_get_result($stmtOpex);
    
    while ($row = mysqli_fetch_assoc($resultOpex)) {
        $opexData[] = [
            'category' => $row['category'],
            'total' => (float)$row['total'],
            'categoryid' => $row['categoryid']
        ];
        if ($maxOpex < $row['total']) {
            $maxOpex = $row['total'];
        }
    }
    mysqli_stmt_close($stmtOpex);
}

// ==================== TOP FIVE REVENUES (Updated Query) ====================
$sqlRevenue = "SELECT c.category, SUM(k.itemvalue) as total, c.categoryid 
               FROM category c
               LEFT JOIN kpi_data k ON c.categoryid = k.categoryId AND k.year = ?
               WHERE c.parentid IN (6,31,32,33,34,35,36,38,44,60)
               GROUP BY c.categoryid, c.category
               HAVING total > 0
               ORDER BY total DESC
               LIMIT 5";

$stmtRevenue = mysqli_prepare($con, $sqlRevenue);
$revenueData = [];
$maxRevenue = 0;

if ($stmtRevenue) {
    mysqli_stmt_bind_param($stmtRevenue, "i", $selectedYear);
    mysqli_stmt_execute($stmtRevenue);
    $resultRevenue = mysqli_stmt_get_result($stmtRevenue);
    
    while ($row = mysqli_fetch_assoc($resultRevenue)) {
        $revenueData[] = [
            'category' => $row['category'],
            'total' => (float)$row['total'],
            'categoryid' => $row['categoryid']
        ];
        if ($maxRevenue < $row['total']) {
            $maxRevenue = $row['total'];
        }
    }
    mysqli_stmt_close($stmtRevenue);
}

// ====================  BY AIRPORT ====================
$airports = [
    1 => 'BIA',
    2 => 'MRIA', 
    3 => 'BDA',
    4 => 'JIA',
    5 => 'RMA'
];

$quarterData3 = [];
// Initialize data structure for 5 airports across 4 quarters
foreach ($airports as $airportId => $airportName) {
    $quarterData3[$airportId] = array_fill(0, 4, 0);
}

// ==================== AIRCRAFT INCIDENTS (Colombo FIR) ====================
$monthlyIncidents = array_fill(0, 12, 0);

$sqlInc = "SELECT month, SUM(itemvalue) AS total
           FROM kpi_data
           WHERE categoryId = 12 AND year = {$selectedYear}
           GROUP BY month
           ORDER BY month";
$resInc = mysqli_query($con, $sqlInc);
if ($resInc) {
    while ($r = mysqli_fetch_assoc($resInc)) {
        $idx = (int)$r['month'] - 1;
        if ($idx >= 0 && $idx < 12) {
            $monthlyIncidents[$idx] = (int)$r['total'];
        }
    }
}
?>
 
 <!-- ========= css for cards ========= -->
<style>
/* Compact Progress Bars */
.compact-progress {
    height: 8px;
    border-radius: 4px;
}

/* Attractive Metric Cards */
.metric-card {
    background: linear-gradient(135deg, var(--bg-start), var(--bg-end));
    border: none;
    border-radius: 15px;
    position: relative;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.metric-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
}

.metric-card::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 100px;
    height: 100px;
    background: rgba(255,255,255,0.1);
    border-radius: 50%;
    transform: translate(30px, -30px);
}

.metric-value {
    font-size: 2.5rem;
    font-weight: 700;
    margin: 0;
    text-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.metric-label {
    font-size: 0.9rem;
    opacity: 0.9;
    margin-bottom: 0.5rem;
}

.metric-subtitle {
    font-size: 0.75rem;
    opacity: 0.8;
}

.metric-icon {
    position: absolute;
    top: 15px;
    right: 15px;
    font-size: 2rem;
    opacity: 0.3;
}

/* Color schemes */
.card-pax { --bg-start: #667eea; --bg-end: #764ba2; }
.card-revenue { --bg-start: #f093fb; --bg-end: #f5576c; }
.card-operational { --bg-start: #4facfe; --bg-end: #00f2fe; }

/* Compact list items */
.compact-item {
    padding: 8px 12px;
    margin-bottom: 6px;
    background: rgba(0,0,0,0.02);
    border-radius: 6px;
    border-left: 3px solid var(--accent-color);
}
.compact-item:last-child { margin-bottom: 0; }
</style>

<main class="content">
    <div class="container-fluid">
        <div class="header mb-3">
            <h1 class="header-title">Dashboard Analytics (<?= $selectedYear ?>)</h1>
            <form method="GET" class="d-inline-block mt-2">
                <label for="year" style="color: white;">Select Year:</label>
                <select name="year" id="year" class="form-select form-select-sm w-auto d-inline-block" onchange="this.form.submit()">
                    <?php foreach ($years as $year): ?>
                        <option value="<?= $year ?>" <?= $year == $selectedYear ? 'selected' : '' ?>><?= $year ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <!-- UPDATED PROGRESS BAR SECTION -->
        <div class="row mb-3">
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header bg-danger text-white py-2">
                <h6 class="card-title mb-0">Top Five OPEX - <?= $selectedYear ?></h6>
            </div>
            <div class="card-body py-2">
                <?php if (!empty($opexData)): ?>
                    <?php 
                    $opexColors = ['#dc3545', '#ffc107', '#17a2b8', '#6c757d', '#343a40'];
                    $opexBgColors = ['bg-danger', 'bg-warning', 'bg-info', 'bg-secondary', 'bg-dark'];
                    foreach ($opexData as $index => $opex): 
                        $percentage = $maxOpex > 0 ? ($opex['total'] / $maxOpex) * 100 : 0;
                        $accentColor = $opexColors[$index] ?? '#6c757d';
                        $bgClass = $opexBgColors[$index] ?? 'bg-secondary';
                    ?>
                    <div class="compact-item" style="--accent-color: <?= $accentColor ?>;">
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="fw-medium"><?= htmlspecialchars($opex['category']) ?></small>
                            <small class="fw-bold"><?= number_format($opex['total']) ?></small>
                        </div>
                        <div class="progress compact-progress mt-1">
                            <div class="progress-bar <?= $bgClass ?>" style="width: <?= $percentage ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted mb-0 small">No OPEX data found for <?= $selectedYear ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header bg-success text-white py-2">
                <h6 class="card-title mb-0">Top Five Revenues - <?= $selectedYear ?></h6>
            </div>
            <div class="card-body py-2">
                <?php if (!empty($revenueData)): ?>
                    <?php 
                    $revenueColors = ['#28a745', '#007bff', '#17a2b8', '#ffc107', '#6c757d'];
                    $revenueBgColors = ['bg-success', 'bg-primary', 'bg-info', 'bg-warning', 'bg-secondary'];
                    foreach ($revenueData as $index => $revenue): 
                        $percentage = $maxRevenue > 0 ? ($revenue['total'] / $maxRevenue) * 100 : 0;
                        $accentColor = $revenueColors[$index] ?? '#6c757d';
                        $bgClass = $revenueBgColors[$index] ?? 'bg-secondary';
                    ?>
                    <div class="compact-item" style="--accent-color: <?= $accentColor ?>;">
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="fw-medium"><?= htmlspecialchars($revenue['category']) ?></small>
                            <small class="fw-bold"><?= number_format($revenue['total']) ?></small>
                        </div>
                        <div class="progress compact-progress mt-1">
                            <div class="progress-bar <?= $bgClass ?>" style="width: <?= $percentage ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted mb-0 small">No Revenue data found for <?= $selectedYear ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

        
        <!-- Passenger Complaints Chart -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Number of Passenger Complaints by Airport - <?= $selectedYear ?> (Category ID: 23)</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="complaintsChart" style="width: 100%; height: 400px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Aircraft Incidents Chart -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">No of Aircraft Incidents in Colombo FIR — <?= $selectedYear ?></h5>
                    </div>
                    <div class="card-body">
                        <canvas id="incidentsChart" style="width:100%; height: 360px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Metrics Section -->
        <!-- Updated Total Passengers Card -->
<div class="row metrics-container mb-4">
    <div class="col-lg-4 mb-3">
        <div class="card metric-card card-pax text-white">
            <div class="card-body p-3 position-relative">
                <div class="metric-icon">✈️</div>
                <div class="metric-label">
                    Total Pax 
                    <?php if ($selectedYear == date('Y')): ?>
                        (Jan - <?= date('M') ?>)
                    <?php else: ?>
                        (Full Year)
                    <?php endif; ?>
                </div>
                <p class="metric-value"><?= number_format($totalPAX) ?></p>
                <div class="metric-subtitle">
                    <?php 
                    $timeframe = ($selectedYear == date('Y')) ? 
                        'Up to ' . date('F Y') : 
                        'Full year ' . $selectedYear;
                    echo $timeframe;
                    ?>
                    <br>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 mb-3">
        <div class="card metric-card card-revenue text-white">
            <div class="card-body p-3 position-relative">
                <div class="metric-icon">💰</div>
                <div class="metric-label">Total Financial Revenue</div>
                <p class="metric-value">$<?= number_format($totalFinancialRevenue / 1000000, 1) ?>M</p>
                <div class="metric-subtitle">
                    <?php 
                    echo ($selectedYear == date('Y')) ? 
                        'Up to ' . date('F Y') : 
                        'Full year ' . $selectedYear;
                    ?>
                    <br>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 mb-3">
        <div class="card metric-card card-operational text-white">
            <div class="card-body p-3 position-relative">
                <div class="metric-icon">📊</div>
                <div class="metric-label">Total Operational</div>
                <p class="metric-value"><?= number_format($totalOperational / 1000000, 1) ?>M</p>
                <div class="metric-subtitle">
                    <?php 
                    echo ($selectedYear == date('Y')) ? 
                        'Up to ' . date('F Y') : 
                        'Full year ' . $selectedYear;
                    ?>
                    <br>
                    
                </div>
            </div>
        </div>
    </div>
</div>
</main>

<!-- Chart.js and your existing JavaScript continues here... -->

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Data from PHP
const quarters = <?php echo json_encode($quarters); ?>;
const airports = <?php echo json_encode(array_values($airports)); ?>;
const airportData3 = <?php echo json_encode($quarterData3); ?>;
const monthsInc = <?= json_encode($months) ?>;
const incidentsData = <?= json_encode($monthlyIncidents) ?>;
// Prepare datasets for each airport
const datasets3 = [];
const colors = [
    'rgba(255, 99, 132, 0.8)',   // Red - BIA
    'rgba(54, 162, 235, 0.8)',   // Blue - Ratmalana 
    'rgba(255, 205, 86, 0.8)',   // Yellow - Mattala
    'rgba(75, 192, 192, 0.8)',   // Teal - Sigiriya
    'rgba(153, 102, 255, 0.8)'   // Purple - Jaffna
];

const borderColors = [
    'rgba(255, 99, 132, 1)',
    'rgba(54, 162, 235, 1)',
    'rgba(255, 205, 86, 1)',
    'rgba(75, 192, 192, 1)',
    'rgba(153, 102, 255, 1)'
];

// Create datasets for each airport
const airportNames = <?php echo json_encode($airports); ?>;
let colorIndex = 0;

for (const [airportId, airportName] of Object.entries(airportNames)) {
    datasets3.push({
        label: airportName,
        data: airportData3[airportId] || [0, 0, 0, 0],
        backgroundColor: colors[colorIndex % colors.length],
        borderColor: borderColors[colorIndex % borderColors.length],
        borderWidth: 2,
        borderRadius: 4,
        borderSkipped: false
    });
    colorIndex++;
}

// Create the complaints chart
new Chart(document.getElementById('complaintsChart').getContext('2d'), {
    type: 'bar',
    data: {
        labels: quarters, // Q1, Q2, Q3, Q4
        datasets: datasets3
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'Passenger Complaints by Airport per Quarter (<?= $selectedYear ?>)',
                font: {
                    size: 16
                }
            },
            legend: {
                display: true,
                position: 'top',
                labels: {
                    usePointStyle: true,
                    padding: 20
                }
            },
            tooltip: {
                callbacks: {
                    title: function(context) {
                        return context[0].label;
                    },
                    label: function(context) {
                        return context.dataset.label + ': ' + context.parsed.y + ' complaints';
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Number of Complaints'
                },
                ticks: {
                    stepSize: 1
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Quarter'
                }
            }
        },
        interaction: {
            mode: 'index',
            intersect: false
        }
    }
});

// Aircraft Incidents in Colombo FIR (Cat 12)
new Chart(document.getElementById('incidentsChart').getContext('2d'), {
  type: 'bar',
  data: {
    labels: monthsInc,
    datasets: [{
      label: 'Aircraft Incidents',
      data: incidentsData,
      backgroundColor: 'rgba(255, 99, 132, 0.7)',
      borderColor: 'rgba(255, 99, 132, 1)',
      borderWidth: 2
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: true, position: 'top' },
      title: { display: false }
    },
    scales: {
      y: {
        beginAtZero: true,
        title: { display: true, text: 'Incidents' }
      },
      x: { title: { display: true, text: 'Month' } }
    }
  }
});



</script>

<?php include 'includes/footer.php'; ?>