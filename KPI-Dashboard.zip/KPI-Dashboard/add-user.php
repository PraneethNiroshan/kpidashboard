<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Block unauthorized access
if (!isset($_SESSION['USER'])) {
    header("Location: ../view/login.php");
    exit;
}
?>

<?php include 'includes/header.php'; ?>
<?php include 'includes/leftnav.php'; ?>

<main class="content">
  <div class="container-fluid">

    <div class="header">
      <h1 class="header-title">Add New User</h1>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="../dashboard-analytics.php">Dashboard</a></li>
          <li class="breadcrumb-item active" aria-current="page">User Management</li>
        </ol>
      </nav>
    </div>

    <div class="card">
      <div class="card-body">
        <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          User added successfully!
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <?php echo htmlspecialchars($_GET['error']); ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <form action="controller/add_userController.php" method="POST" id="addUserForm">

          <div class="mb-3 row">
            <label class="col-form-label col-sm-2 text-sm-end">Username</label>
            <div class="col-sm-10">
              <input type="text" name="username" class="form-control" required>
            </div>
          </div>

          <div class="mb-3 row">
            <label class="col-form-label col-sm-2 text-sm-end">Password</label>
            <div class="col-sm-10">
              <div class="input-group">
                <input type="password" name="password" id="passwordField" class="form-control" required>
                <span class="input-group-text" onclick="togglePassword()" style="cursor:pointer;">
                  <i id="eyeIcon" class="fa fa-eye"></i>
                </span>
              </div>
            </div>
          </div>

          <div class="mb-3 row">
            <label class="col-form-label col-sm-2 text-sm-end">Display Name</label>
            <div class="col-sm-10">
              <input type="text" name="display_name" class="form-control" required>
            </div>
          </div>

          <div class="mb-3 row">
            <label class="col-form-label col-sm-2 text-sm-end">User Type</label>
            <div class="col-sm-10">
              <select name="user_type" id="userTypeSelect" class="form-select" required onchange="handleUserTypeChange(this)">
                <option value="">Select User Type</option>
                <option value="admin">Admin</option>
                <option value="division_user">Division User</option>
                <option value="superadmin">Super Admin</option>
              </select>
            </div>
          </div>

          <div class="mb-3 row">
            <label class="col-form-label col-sm-2 text-sm-end">Division</label>
            <div class="col-sm-10">
              <select name="division_id" id="divisionSelect" class="form-select">
                <option value="">Select Division</option>
                <?php
                require_once 'database/db.php'; 
                $conn = (new db())->getConnection();

                if ($conn) {
                    $query = "SELECT division_id, division_name FROM division ORDER BY division_name ASC";
                    $result = $conn->query($query);

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<option value="' . $row['division_id'] . '">' . htmlspecialchars($row['division_name']) . '</option>';
                        }
                    } else {
                        echo '<option disabled>No divisions found</option>';
                    }
                } else {
                    echo '<option disabled>Database connection failed</option>';
                }
                ?>
              </select>
            </div>
          </div>

          <div class="row">
            <div class="offset-sm-2 col-sm-10">
              <button type="submit" class="btn btn-primary" id="createUserBtn">Create User</button>
              <a href="dashboard-analytics.php" class="btn btn-secondary">Cancel</a>
            </div>
          </div>

        </form>
      </div>
    </div>

  </div>
</main>

<!-- Font Awesome for eye icon -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<script>
// Toggle password visibility
function togglePassword() {
  const passwordInput = document.getElementById("passwordField");
  const eyeIcon = document.getElementById("eyeIcon");
  const isPassword = passwordInput.type === "password";
  passwordInput.type = isPassword ? "text" : "password";
  eyeIcon.className = isPassword ? "fa fa-eye-slash" : "fa fa-eye";
}

function handleUserTypeChange(select) {
  const divisionSelect = document.getElementById("divisionSelect");
  if (select.value === "superadmin") {
    divisionSelect.disabled = true;
    divisionSelect.value = "";
    divisionSelect.required = false;
  } else {
    divisionSelect.disabled = false;
    divisionSelect.required = true;
  }
}

// Form validation
document.getElementById('addUserForm').addEventListener('submit', function(e) {
    const userType = document.getElementById('userTypeSelect').value;
    const divisionId = document.getElementById('divisionSelect').value;
    
    if (userType !== 'superadmin' && !divisionId) {
        alert('Please select a division for this user type.');
        e.preventDefault();
        return false;
    }
});
</script>

<?php include 'includes/footer.php'; ?>