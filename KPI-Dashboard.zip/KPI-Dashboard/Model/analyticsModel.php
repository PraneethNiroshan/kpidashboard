<?php
require_once '../database/db.php'; // Adjust path if needed

class AnalyticsModel
{
    public function getTopAnalytics($type, $year, $month)
    {
        $dbObject = new db();
        $mysqli = $dbObject->getConnection();
        $rows = [];

        // Define SQL queries mapped to analytics types
        $sqlMap = [
            'revenue_categories' => [
                'query' => "SELECT itemvalue FROM `kpi-data` WHERE categoryId = 50 AND YEAR(datetime) = ? AND MONTH(datetime) = ?",
            ],
            'customers' => [
                'query' => "SELECT itemvalue FROM `kpi-data` WHERE categoryId = 51 AND YEAR(datetime) = ? AND MONTH(datetime) = ?",
            ],
            'concessionnaires' => [
                'query' => "SELECT itemvalue FROM `kpi-data` WHERE categoryId = 52 AND YEAR(datetime) = ? AND MONTH(datetime) = ?",
            ],
            'product_categories' => [
                'query' => "SELECT itemvalue FROM `kpi-data` WHERE categoryId = 53 AND YEAR(datetime) = ? AND MONTH(datetime) = ?",
            ],
            'opex' => [
                'query' => "SELECT itemvalue FROM `kpi-data` WHERE categoryId = 54 AND YEAR(datetime) = ? AND MONTH(datetime) = ?",
            ]
        ];

        // If type not found, return empty
        if (!isset($sqlMap[$type])) {
            return [];
        }

        // Prepare and execute query
        $stmt = $mysqli->prepare($sqlMap[$type]['query']);
        if (!$stmt) {
            error_log("Prepare failed: " . $mysqli->error);
            return [];
        }

        $stmt->bind_param('ii', $year, $month);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }

        $stmt->close();
        return $rows;
    }

    public function getTotalRevenueByParentCategory($parentId = 1, $year = null, $month = null)
    {
        $dbObject = new db();
        $mysqli = $dbObject->getConnection();

        // Get all categoryIds where parentId = $parentId
        $stmtCat = $mysqli->prepare("SELECT id FROM category WHERE parentId = ?");
        $stmtCat->bind_param('i', $parentId);
        $stmtCat->execute();
        $resultCat = $stmtCat->get_result();

        $categoryIds = [];
        while ($row = $resultCat->fetch_assoc()) {
            $categoryIds[] = $row['id'];
        }
        $stmtCat->close();

        if (empty($categoryIds)) {
            return 0; // no categories found
        }

        // Build placeholders for prepared statement IN clause
        $placeholders = implode(',', array_fill(0, count($categoryIds), '?'));

        // Prepare query to sum itemvalue for those categories filtered by year/month if provided
        $query = "SELECT SUM(CAST(itemvalue AS DECIMAL(15,2))) AS totalRevenue FROM `kpi-data` WHERE categoryId IN ($placeholders)";

        $types = str_repeat('i', count($categoryIds));
        $params = $categoryIds;

        if ($year !== null && $month !== null) {
            $query .= " AND YEAR(datetime) = ? AND MONTH(datetime) = ?";
            $types .= 'ii';
            $params[] = $year;
            $params[] = $month;
        }

        $stmt = $mysqli->prepare($query);

        // Bind params dynamically
        $stmt->bind_param($types, ...$params);

        $stmt->execute();
        $result = $stmt->get_result();
        $totalRevenue = 0;
        if ($row = $result->fetch_assoc()) {
            $totalRevenue = $row['totalRevenue'] ?? 0;
        }

        $stmt->close();
        return $totalRevenue;
    }

}
