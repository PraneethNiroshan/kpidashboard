<?php
class KpiModel {
    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    /**
     * Save KPI data to the database
     *
     * NOTE:
     * - Kept your original parameter order for backward compatibility.
     * - Added $trainingType as an OPTIONAL last parameter to support Learning KPIs (Category 28).
     * - Month/Quarter should be 0 when not applicable (annual).
     */
    public function saveKpi(
        $categoryId,
        $year,
        $month,
        $quarter,
        $frequencyId,
        $itemvalue,
        $airportId,
        $travelType,
        $description,
        $divisionId,
        $trainingType = null,  // NEW OPTIONAL
        $cargo_type = null
    ) {
        try {
            // Defaults / normalization
            $month        = $month ?? 0;
            $quarter      = $quarter ?? 0;
            $travelType   = $travelType ?? 0;
            $divisionId   = $divisionId ?? 0;
            $trainingType = ($trainingType === null || $trainingType === false) ? null : (int)$trainingType;
            $description  = is_string($description) && trim($description) !== '' ? trim($description) : null;
            $cargo_type   = ($cargo_type === null || $cargo_type === false) ? null : (int)$cargo_type; // Normalize cargo_type

            // Ensure numeric types are cast correctly
            $categoryId  = (int)$categoryId;
            $year        = (int)$year;
            $month       = (int)$month;
            $quarter     = (int)$quarter;
            $frequencyId = (int)$frequencyId;
            $itemvalue   = (float)$itemvalue;
            $airportId   = (int)$airportId;
            $travelType  = (int)$travelType;
            $divisionId  = (int)$divisionId;

            // We insert training_type always (nullable). Make sure your table has this column:
            // ALTER TABLE kpi_data ADD COLUMN training_type INT NULL AFTER travel_type;
            $sql = "
                INSERT INTO kpi_data
                (categoryId, year, month, quarter, frequencyId, itemvalue, airportId, cargo_type, travel_type, training_type, description, division_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ";

            $stmt = $this->conn->prepare($sql);
            if (!$stmt) {
                throw new \Exception('Prepare failed: ' . $this->conn->error);
            }

            // Bind types:
            // categoryId(i), year(i), month(i), quarter(i), frequencyId(i),
            // itemvalue(d), airportId(i), cargo_type(i), travel_type(i), training_type(i|NULL), description(s|NULL), division_id(i)
            // Types string: iiiiidiiiisi
            $stmt->bind_param(
                "iiiiidiiiisi",
                $categoryId,
                $year,
                $month,
                $quarter,
                $frequencyId,
                $itemvalue,
                $airportId,
                $cargo_type,
                $travelType,
                $trainingType,   // int or null is acceptable with bind_param in MySQLi when using default emulation
                $description,    // string or null
                $divisionId
            );

            $ok = $stmt->execute();
            if (!$ok) {
                $err = $stmt->error;
                $stmt->close();
                return $err ?: false;
            }

            $stmt->close();
            return true;
        } catch (\Throwable $e) {
            error_log("Error saving KPI data: " . $e->getMessage());
            return $e->getMessage();
        }
    }

    /**
     * Validate KPI input data
     * (Kept and lightly corrected: percentage KPIs capped at 0..100)
     */
    public function validateInput($data) {
        $errors = [];

        // Validate categoryId (kept broad)
        if (empty($data['categoryId']) || !is_numeric($data['categoryId'])) {
            $errors[] = "Invalid category ID";
        }

        // Validate year
        $currentYear = (int)date('Y');
        if (empty($data['year']) || !is_numeric($data['year']) ||
            $data['year'] < ($currentYear - 5) || $data['year'] > ($currentYear + 2)) {
            $errors[] = "Invalid year";
        }

        // Validate frequencyId
        if (empty($data['frequencyId']) || !is_numeric($data['frequencyId']) || $data['frequencyId'] < 1) {
            $errors[] = "Invalid frequency ID (must be >= 1)";
        }

        // Optional: guard month / quarter if present
        if (isset($data['month']) && $data['month'] !== '' && (!is_numeric($data['month']) || $data['month'] < 1 || $data['month'] > 12)) {
            $errors[] = "Invalid month (1-12)";
        }
        if (isset($data['quarter']) && $data['quarter'] !== '' && (!is_numeric($data['quarter']) || $data['quarter'] < 1 || $data['quarter'] > 4)) {
            $errors[] = "Invalid quarter (1-4)";
        }

        // Percentage-based KPIs (cap between 0 and 100)
        $percentageCategories = [15, 17, 19, 20, 21, 23, 25, 27, 29];
        if (in_array(($data['categoryId'] ?? null), $percentageCategories, true)) {
            if (!isset($data['itemvalue']) || !is_numeric($data['itemvalue']) || $data['itemvalue'] < 0 || $data['itemvalue'] > 100) {
                $errors[] = "Value must be between 0 and 100 for percentage-based KPIs";
            }
        } else {
            if (!isset($data['itemvalue']) || !is_numeric($data['itemvalue']) || $data['itemvalue'] < 0) {
                $errors[] = "Invalid value (must be non-negative)";
            }
        }

        // Description validation
        if (isset($data['description']) && $data['description'] !== '' && !is_string($data['description'])) {
            $errors[] = "Description must be a string";
        }

        // training_type (optional)
        if (isset($data['trainingId']) && $data['trainingId'] !== '' && !is_numeric($data['trainingId'])) {
            $errors[] = "Invalid training type";
        }
        if (isset($data['cargo_type']) && $data['cargo_type'] !== '' && (!is_numeric($data['cargo_type']) || $data['cargo_type'] < 1)) {
            $errors[] = "Invalid cargo type (must be >= 1)";
        }

        return $errors;
    }
}
?>