<?php
class KpiModel {
    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    /**
     * Save KPI data to the database
     */
    public function saveKpi($categoryId, $year, $month, $quarter, $frequencyId, $itemvalue, $airportId, $travelType, $description, $divisionId) {
        try {
            // Set default values for null fields
            $month = $month ?? 0;
            $quarter = $quarter ?? 0;
            $travelType = $travelType ?? 0;
            $description = $description === '' ? null : $description; // Null if empty

            $stmt = $this->conn->prepare("
                INSERT INTO kpi_data 
                (categoryId, year, month, quarter, frequencyId, itemvalue, airportId, travel_type, description, division_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");

            if (!$stmt) {
                throw new Exception("Prepare failed: " . $this->conn->error);
            }

            // Bind parameters
            $stmt->bind_param(
                "iiiiidissi",
                $categoryId,
                $year,
                $month,
                $quarter,
                $frequencyId,
                $itemvalue,
                $airportId,
                $travelType,
                $description,
                $divisionId
            );

            $result = $stmt->execute();
            $stmt->close();
            return $result;
        } catch (Exception $e) {
            error_log("Error saving KPI data: " . $e->getMessage());
            return $e->getMessage();
        }
    }

    /**
     * Validate KPI input data
     */
    public function validateInput($data) {
        $errors = [];
        
        // Validate categoryId
        if (empty($data['categoryId']) || !is_numeric($data['categoryId']) || !in_array($data['categoryId'], range(12, 30))) {
            $errors[] = "Invalid category ID";
        }
        
        // Validate year
        $currentYear = date('Y');
        if (empty($data['year']) || !is_numeric($data['year']) || 
            $data['year'] < ($currentYear - 5) || $data['year'] > ($currentYear + 2)) {
            $errors[] = "Invalid year";
        }
        
        // Validate frequencyId
        if (empty($data['frequencyId']) || !is_numeric($data['frequencyId']) || $data['frequencyId'] < 1) {
            $errors[] = "Invalid frequency ID (must be greater than 0)";
        }
        
        // Quarterly KPI check
        $quarterlyCategories = [19, 20, 23, 25];
        if (in_array($data['categoryId'], $quarterlyCategories) && ($data['frequencyId'] < 1 || $data['frequencyId'] > 4)) {
            $errors[] = "Invalid quarter (must be 1-4)";
        }
        
        // Monthly KPI check
        $monthlyCategories = [12, 13, 14, 15, 16, 17, 18, 21, 22, 24, 30];
        if (in_array($data['categoryId'], $monthlyCategories) && ($data['frequencyId'] < 1 || $data['frequencyId'] > 12)) {
            $errors[] = "Invalid month (must be 1-12)";
        }
        
        // Percentage-based KPI check
        $percentageCategories = [15, 17, 19, 20, 21, 23, 25];
        if (in_array($data['categoryId'], $percentageCategories)) {
            if (!isset($data['itemvalue']) || !is_numeric($data['itemvalue']) || 
                $data['itemvalue'] < 0 || $data['itemvalue'] > 1000000000000000000000000) {
                $errors[] = "Value must be between 0 and 100 for percentage-based KPIs";
            }
        } else {
            if (!isset($data['itemvalue']) || !is_numeric($data['itemvalue']) || $data['itemvalue'] < 0) {
                $errors[] = "Invalid value (must be non-negative)";
            }
        }
        
        // Description validation
        if (isset($data['description']) && $data['description'] !== '' && !is_string($data['description'])) {
            $errors[] = "Description must be a string";
        }

        return $errors;
    }
}
?>
