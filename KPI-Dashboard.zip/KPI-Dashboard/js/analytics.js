// Fetch analytics data for a specific type and column
function fetchAnalytics(type, column) {
    const year = document.getElementById(`year${column}`).value;
    const month = document.getElementById(`month${column}`).value;
    const listElement = document.getElementById(`${type}-list-${column}`);

    // Show loading state
    listElement.innerHTML = '<li class="list-group-item">Loading...</li>';

    fetch('controller/analyticsController.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `type=${encodeURIComponent(type)}&year=${encodeURIComponent(year)}&month=${encodeURIComponent(month)}`
    })
    .then(res => res.json())
    .then(data => {
        listElement.innerHTML = '';
        if (!data || data.length === 0) {
            listElement.innerHTML = '<li class="list-group-item text-muted">No data available</li>';
        } else {
            data.forEach(item => {
                const li = document.createElement('li');
                li.className = 'list-group-item';
                li.textContent = Object.values(item).join(" - ");
                listElement.appendChild(li);
            });
        }
    })
    .catch(error => {
        listElement.innerHTML = '<li class="list-group-item text-danger">Error loading data</li>';
        console.error('Error:', error);
    });
}

// Fetch and display total revenue
function fetchTotalRevenue() {
    const year = document.getElementById('year').value;
    const month = document.getElementById('month').value;

    fetch('controller/analyticsController.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            action: 'total_revenue',
            year: year,
            month: month
        })
    })
    .then(response => response.json())
    .then(data => {
        const container = document.getElementById('total-revenue-value');
        container.textContent = data.totalRevenue
            ? Number(data.totalRevenue).toLocaleString(undefined, { minimumFractionDigits: 2 })
            : '0.00';
    })
    .catch(error => {
        console.error('Error fetching total revenue:', error);
        document.getElementById('total-revenue-value').textContent = 'Error';
    });
}


// Optional: Initialize icons and revenue on page load
document.addEventListener('DOMContentLoaded', () => {
    if (typeof feather !== 'undefined') feather.replace();
    if (document.getElementById('total-revenue-value')) fetchTotalRevenue();
});
