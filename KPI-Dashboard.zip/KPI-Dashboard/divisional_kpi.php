<?php
include 'includes/header.php';
include 'includes/leftnav.php'; // This includes the sidebar with the new link
?>
<main class="content">
    <div class="container-fluid">
        <div class="header">
            <h1 class="header-title">Divisional KPI</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard-default.html">Main</a></li>
                    <li class="breadcrumb-item"><a href="#">BSC - Data Management</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Divisional KPI</li>
                </ol>
            </nav>
        </div>
        <!-- Add your divisional KPI content here -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h1 class="card-title mb-0">Divisional KPI Overview</h1>
                    </div>
                    <div class="card-body">
                        <!-- Add forms, charts, or other content here -->
                        <p>Under Development .</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include 'includes/footer.php'; ?>