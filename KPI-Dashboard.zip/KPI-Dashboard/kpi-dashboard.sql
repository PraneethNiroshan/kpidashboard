-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2025 at 05:58 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kpi-dashboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `airports`
--

CREATE TABLE `airports` (
  `airportId` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `airport_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `airports`
--

INSERT INTO `airports` (`airportId`, `airport_name`, `created_at`, `updated_at`) VALUES
('1', 'BIA', '2025-06-07 14:29:39', '2025-06-07 14:29:39'),
('2', 'MRIA', '2025-06-07 14:29:39', '2025-06-07 14:29:39'),
('3', 'BDA', '2025-06-07 14:29:39', '2025-08-18 04:57:39'),
('4', 'JIA', '2025-06-07 14:29:39', '2025-06-07 14:29:39'),
('5', 'RMA', '2025-06-07 14:29:39', '2025-08-18 04:57:55');

-- --------------------------------------------------------

--
-- Table structure for table `cargo_type`
--

CREATE TABLE `cargo_type` (
  `cargoId` int(11) NOT NULL,
  `type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cargo_type`
--

INSERT INTO `cargo_type` (`cargoId`, `type_name`) VALUES
(1, 'Import'),
(2, 'Export');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categoryId` int(11) NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parentid` int(11) NOT NULL,
  `frequencyId` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `account` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryId`, `category`, `parentid`, `frequencyId`, `created_at`, `updated_at`, `account`) VALUES
(1, 'Financial', 0, 1, '2025-06-07 14:29:39', '2025-06-08 05:23:34', ''),
(2, 'Internal Process', 0, 1, '2025-06-07 14:29:39', '2025-06-08 05:23:43', ''),
(3, 'Customer', 0, 1, '2025-06-07 14:29:39', '2025-06-08 05:23:50', ''),
(4, 'Learning & Growth', 0, 1, '2025-06-07 14:29:39', '2025-06-08 05:23:53', ''),
(5, 'Aeronautical revenue', 1, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(6, 'Non-aeronautical revenue', 1, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(7, 'Revenue per passenger', 1, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(8, 'Operating expenses per passenger', 1, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(9, 'Return on assets (ROA)', 1, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(10, 'Debt cover ratio', 1, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(11, 'Net cash flow', 1, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(12, 'No of Aircraft Incidents in Colombo FIR', 2, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(13, 'Number of airside incidents and accidents', 2, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(14, '% of Aircraft Experiencing a Delay on Ground Due to ATC Delays (per 100,000 A/C movements)', 2, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(15, 'Security audit compliance %', 2, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(16, 'No. of incidents of security breaches', 2, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(17, 'Availability of Air Navigation, Communication, Surveillance systems services (%)', 2, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(18, 'E&ANE (Total CNS)', 2, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(19, 'Shop space ocupancy rate', 2, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(20, 'Achievement of procurement time schedule (PTS)', 3, 2, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(21, 'Passenger satisfaction level', 3, 2, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(22, 'Airline satisfaction level', 3, 2, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(23, 'Number of passenger complaints', 3, 2, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(24, 'Cleanliness of the Airport rating', 3, 2, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(25, 'Average Passenger processing time (Min) -Arrival', 3, 2, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(26, 'Average Passenger processing time (Min) - Departure', 4, 2, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(27, 'Employee job satisfaction', 4, 3, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(28, 'Number of trainings conducted (Local & Foreign)', 4, 3, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(29, 'Employee turnover (%)', 4, 3, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(30, 'No. of new products / services / process improvements introduced', 4, 3, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(31, 'Landing & Parking', 5, 1, '2025-06-07 14:29:39', '2025-08-15 10:14:14', 'ACCOUNT = \'310001\' or ACCOUNT = \'311001\''),
(32, 'Aerobridge', 5, 1, '2025-06-07 14:29:39', '2025-08-15 10:14:20', 'ACCOUNT = \'313001\''),
(33, 'Overflying', 5, 1, '2025-06-07 14:29:39', '2025-08-15 10:14:31', 'ACCOUNT = \'312001\' or ACCOUNT =\'312005\''),
(34, 'Embarkation levy', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:14:49', 'ACCOUNT = \'324001\''),
(35, 'Concession', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:15:05', 'ACCOUNT = \'321001\''),
(36, 'Rental', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:15:18', 'ACCOUNT = \'320001\''),
(37, 'Entry Permits', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:15:29', 'ACCOUNT = \'326500\''),
(38, 'Fuel Throughput Charges', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:15:42', 'ACCOUNT = \'322004\''),
(39, 'Franchise Fee on Ground Handling - SLA', 6, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(40, 'Franchise Fee - SLCS', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:16:00', 'ACCOUNT = \'327003\''),
(41, 'Entry permits - PVG', 6, 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39', ''),
(42, 'Parking Fees - Vehicles', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:16:25', 'ACCOUNT = \'326000\''),
(43, 'Domestic Ground Handling CIAR / BIA', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:16:42', 'ACCOUNT = \'323004\''),
(44, 'Other Non-Aeronautical Income', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:17:03', 'ACCOUNT = \'322001\' or ACCOUNT = \'322002\' or ACCOUNT =\'329001\' or ACCOUNT = \'329026\' or ACCOUNT = \'329027\''),
(45, 'Gross Profit from Lounges', 6, 1, '2025-06-07 14:29:39', '2025-08-15 10:17:18', 'ACCOUNT = \'325001\''),
(46, 'Landing & Parking - International', 31, 1, '2025-06-07 14:29:39', '2025-08-15 10:17:41', 'ACCOUNT =\'311001\''),
(47, 'Landing & Parking - Domestic', 31, 1, '2025-06-07 14:29:39', '2025-08-15 10:17:55', 'ACCOUNT =\'310001\''),
(48, 'Total PAX', 0, 1, '2025-07-18 06:22:20', '2025-07-18 06:22:20', ''),
(49, 'Total A/C handled', 0, 1, '2025-07-18 06:22:20', '2025-07-18 06:22:20', ''),
(50, 'Overflights', 0, 1, '2025-07-18 06:22:20', '2025-07-18 06:22:20', ''),
(51, 'Cargo handled', 0, 1, '2025-07-18 06:22:20', '2025-07-18 06:22:20', ''),
(52, 'Availability of Air Navigation', 0, 1, '2025-08-08 13:48:18', '2025-08-08 13:48:18', ''),
(53, 'Communication', 0, 1, '2025-08-08 13:48:18', '2025-08-08 13:48:18', ''),
(54, 'Surveillance systems services', 0, 1, '2025-08-08 13:48:18', '2025-08-08 13:48:18', ''),
(55, 'Revenue per passenger', 0, 1, '2025-08-15 05:41:37', '2025-08-15 05:41:37', ''),
(56, 'Operating expenses per passenger', 0, 1, '2025-08-15 05:41:37', '2025-08-15 05:41:37', ''),
(57, 'Return on assets (ROA)', 0, 1, '2025-08-15 05:41:37', '2025-08-15 05:41:37', ''),
(58, 'cleanliness of the Airport rating', 0, 1, '2025-08-15 05:41:37', '2025-08-15 05:41:37', ''),
(59, 'Net cash flow', 0, 1, '2025-08-15 05:41:37', '2025-08-15 05:41:37', '');

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

CREATE TABLE `division` (
  `division_id` int(11) NOT NULL,
  `division_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`division_id`, `division_name`) VALUES
(12, 'ANS'),
(13, 'AM'),
(14, 'Sec'),
(15, 'EANE'),
(16, 'SCM'),
(17, 'MKT'),
(18, 'HR');

-- --------------------------------------------------------

--
-- Table structure for table `history_service`
--

CREATE TABLE `history_service` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_service`
--

INSERT INTO `history_service` (`id`, `date`) VALUES
(1, '2025-08-15 15:51:26'),
(2, '2025-08-15 15:56:56'),
(3, '2025-08-15 16:03:42'),
(4, '2025-08-18 10:31:24'),
(5, '2025-08-18 10:46:46');

-- --------------------------------------------------------

--
-- Table structure for table `insert_frequency`
--

CREATE TABLE `insert_frequency` (
  `frequencyId` int(11) NOT NULL,
  `frequency_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `insert_frequency`
--

INSERT INTO `insert_frequency` (`frequencyId`, `frequency_name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'monthly', 12, '2025-06-07 14:29:39', '2025-06-07 14:29:39'),
(2, 'quaterly', 3, '2025-06-07 14:29:39', '2025-06-07 14:29:39'),
(3, 'yearly', 1, '2025-06-07 14:29:39', '2025-06-07 14:29:39');

-- --------------------------------------------------------

--
-- Table structure for table `kpi_data`
--

CREATE TABLE `kpi_data` (
  `kpiId` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `frequencyId` int(11) NOT NULL,
  `airportId` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` year(4) NOT NULL,
  `month` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `itemvalue` decimal(15,2) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `travel_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quarter` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `cargo_type` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kpi_data`
--

INSERT INTO `kpi_data` (`kpiId`, `categoryId`, `frequencyId`, `airportId`, `year`, `month`, `itemvalue`, `description`, `created_at`, `travel_type`, `quarter`, `division_id`, `training_type`, `cargo_type`) VALUES
(919, 31, 1, '1', 2025, '07', '17421457976.62', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(920, 31, 1, '5', 2025, '07', '7154956.13', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(921, 31, 1, '2', 2025, '07', '247916954.94', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(922, 31, 1, '3', 2025, '07', '147000.00', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(923, 32, 1, '2', 2025, '07', '97490.51', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(924, 33, 1, '5', 2025, '07', '2615162550.71', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(925, 35, 1, '1', 2025, '07', '1173286556.65', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(926, 36, 1, '1', 2025, '07', '768825764.67', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(927, 36, 1, '5', 2025, '07', '9040293.99', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(928, 36, 1, '2', 2025, '07', '162271.12', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(929, 37, 1, '1', 2025, '07', '87000673.76', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(930, 37, 1, '2', 2025, '07', '326459.74', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(931, 40, 1, '2', 2025, '07', '228051.67', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(932, 42, 1, '1', 2025, '07', '27124369.87', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(933, 42, 1, '2', 2025, '07', '72463.98', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(934, 43, 1, '5', 2025, '07', '272905.82', NULL, '2025-08-18 10:46:29', '1', NULL, NULL, NULL, NULL),
(935, 43, 1, '1', 2025, '07', '0.00', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(936, 44, 1, '1', 2025, '07', '3969494601.39', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(937, 44, 1, '5', 2025, '07', '176815172.96', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(938, 44, 1, '2', 2025, '07', '170002907.61', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(939, 44, 1, '3', 2025, '07', '0.00', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(940, 46, 1, '1', 2025, '07', '430101439.54', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(941, 46, 1, '5', 2025, '07', '386178.00', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(942, 46, 1, '2', 2025, '07', '750748.62', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(943, 47, 1, '1', 2025, '07', '485440.00', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(944, 47, 1, '5', 2025, '07', '965664.30', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL),
(945, 47, 1, '3', 2025, '07', '147000.00', NULL, '2025-08-18 10:46:30', '1', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `news_user`
--

CREATE TABLE `news_user` (
  `id` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `UserType` varchar(20) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news_user`
--

INSERT INTO `news_user` (`id`, `UserName`, `Password`, `UserType`, `display_name`, `division_id`) VALUES
(11, 'admin12', '1844156d4166d94387f1a4ad031ca5fa', 'admin', 'ANS', 12),
(12, 'admin13', '588e57b852a16b297af73ae818065474', 'admin', 'AM', 13),
(13, 'admin14', 'bdc8341bb7c06ca3a3e9ab7d39ecb789', 'admin', 'Sec', 14),
(14, 'admin15', 'b26c077af60ba02d12c8436110256029', 'admin', 'EANE', 15),
(15, 'admin16', '9071e0ca7e4964a5cc69201ba2743650', 'admin', 'SCM', 16),
(16, 'admin17', 'd5133c970ad3a99c2248fed76970d06c', 'admin', 'MKT', 17),
(17, 'admin18', '5007007bf0d84200644731d5d3bf9aff', 'admin', 'HR', 18),
(82, 'superadmin123', 'ac497cfaba23c4184cb03b97e8c51e0a', 'superadmin', 'superadmin', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `training_type`
--

CREATE TABLE `training_type` (
  `trainingId` int(11) NOT NULL,
  `training_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `training_type`
--

INSERT INTO `training_type` (`trainingId`, `training_name`) VALUES
(1, 'Local'),
(2, 'Foreign');

-- --------------------------------------------------------

--
-- Table structure for table `travel_type`
--

CREATE TABLE `travel_type` (
  `travelTypeId` int(11) NOT NULL,
  `travel_Type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `travel_type`
--

INSERT INTO `travel_type` (`travelTypeId`, `travel_Type`, `created_at`, `updated_at`) VALUES
(1, 'International', '2025-07-18 08:10:12', '2025-07-18 08:10:12'),
(2, 'Domestic', '2025-07-18 08:10:12', '2025-07-18 08:10:12'),
(3, 'Transit/Transfer', '2025-07-18 08:10:12', '2025-08-14 06:15:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airports`
--
ALTER TABLE `airports`
  ADD PRIMARY KEY (`airportId`);

--
-- Indexes for table `cargo_type`
--
ALTER TABLE `cargo_type`
  ADD PRIMARY KEY (`cargoId`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryId`),
  ADD KEY `frequencyId` (`frequencyId`);

--
-- Indexes for table `division`
--
ALTER TABLE `division`
  ADD PRIMARY KEY (`division_id`);

--
-- Indexes for table `history_service`
--
ALTER TABLE `history_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `insert_frequency`
--
ALTER TABLE `insert_frequency`
  ADD PRIMARY KEY (`frequencyId`);

--
-- Indexes for table `kpi_data`
--
ALTER TABLE `kpi_data`
  ADD PRIMARY KEY (`kpiId`),
  ADD KEY `fk_category` (`categoryId`),
  ADD KEY `fk_frequency` (`frequencyId`),
  ADD KEY `fk_airport` (`airportId`),
  ADD KEY `fk_division` (`division_id`);

--
-- Indexes for table `news_user`
--
ALTER TABLE `news_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `division_id` (`division_id`);

--
-- Indexes for table `training_type`
--
ALTER TABLE `training_type`
  ADD PRIMARY KEY (`trainingId`);

--
-- Indexes for table `travel_type`
--
ALTER TABLE `travel_type`
  ADD PRIMARY KEY (`travelTypeId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cargo_type`
--
ALTER TABLE `cargo_type`
  MODIFY `cargoId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `division`
--
ALTER TABLE `division`
  MODIFY `division_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `history_service`
--
ALTER TABLE `history_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `kpi_data`
--
ALTER TABLE `kpi_data`
  MODIFY `kpiId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=946;
--
-- AUTO_INCREMENT for table `news_user`
--
ALTER TABLE `news_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;
--
-- AUTO_INCREMENT for table `training_type`
--
ALTER TABLE `training_type`
  MODIFY `trainingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `travel_type`
--
ALTER TABLE `travel_type`
  MODIFY `travelTypeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `category`
--
ALTER TABLE `category`
  ADD CONSTRAINT `category_ibfk_1` FOREIGN KEY (`frequencyId`) REFERENCES `insert_frequency` (`frequencyId`);

--
-- Constraints for table `kpi_data`
--
ALTER TABLE `kpi_data`
  ADD CONSTRAINT `fk_airport` FOREIGN KEY (`airportId`) REFERENCES `airports` (`airportId`),
  ADD CONSTRAINT `fk_category` FOREIGN KEY (`categoryId`) REFERENCES `category` (`categoryId`),
  ADD CONSTRAINT `fk_division` FOREIGN KEY (`division_id`) REFERENCES `division` (`division_id`),
  ADD CONSTRAINT `fk_frequency` FOREIGN KEY (`frequencyId`) REFERENCES `insert_frequency` (`frequencyId`);

--
-- Constraints for table `news_user`
--
ALTER TABLE `news_user`
  ADD CONSTRAINT `news_user_ibfk_1` FOREIGN KEY (`division_id`) REFERENCES `division` (`division_id`) ON DELETE SET NULL ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
