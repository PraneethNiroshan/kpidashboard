<?php
include 'includes/header.php';
include 'includes/leftnav.php';

$con = mysqli_connect("localhost", "root", "", "kpi-dashboard");

// Get available years from DB
$years = [];
$yearResult = mysqli_query($con, "SELECT DISTINCT year FROM kpi_data ORDER BY year DESC");
while ($row = mysqli_fetch_assoc($yearResult)) {
    $years[] = $row['year'];
}

// Selected year from GET or default
$selectedYear = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Month labels
$months = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
           'August', 'September', 'October', 'November', 'December'];

// Chart 1 - categoryId = 12
$monthlyData1 = array_fill(0, 12, 0);
$sql1 = "SELECT month, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 12 AND year = $selectedYear GROUP BY month ORDER BY month";
$result1 = mysqli_query($con, $sql1);
if ($result1) {
    while ($row = mysqli_fetch_assoc($result1)) {
        $monthlyData1[(int)$row['month'] - 1] = (int)$row['total'];
    }
}

// Chart 2 - categoryId = 14
$monthlyData2 = array_fill(0, 12, 0);
$sql2 = "SELECT month, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 14 AND year = $selectedYear GROUP BY month ORDER BY month";
$result2 = mysqli_query($con, $sql2);
if ($result2) {
    while ($row = mysqli_fetch_assoc($result2)) {
        $monthlyData2[(int)$row['month'] - 1] = (int)$row['total'];
    }
}

// Chart 3 - categoryId = 13
$monthlyData3 = array_fill(0, 12, 0);
$sql3 = "SELECT month, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 13 AND year = $selectedYear GROUP BY month ORDER BY month";
$result3 = mysqli_query($con, $sql3);
if ($result3) {
    while ($row = mysqli_fetch_assoc($result3)) {
        $monthlyData3[(int)$row['month'] - 1] = (int)$row['total'];
    }
}

// Chart 4 - categoryId = 15
$monthlyData4 = array_fill(0, 12, 0);
$sql4 = "SELECT month, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 15 AND year = $selectedYear GROUP BY month ORDER BY month";
$result4 = mysqli_query($con, $sql4);
if ($result4) {
    while ($row = mysqli_fetch_assoc($result4)) {
        $monthlyData4[(int)$row['month'] - 1] = (int)$row['total'];
    }
}

// Chart 5 - categoryId = 16
$monthlyData5 = array_fill(0, 12, 0);
$sql5 = "SELECT month, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 16 AND year = $selectedYear GROUP BY month ORDER BY month";
$result5 = mysqli_query($con, $sql5);
if ($result5) {
    while ($row = mysqli_fetch_assoc($result5)) {
        $monthlyData5[(int)$row['month'] - 1] = (int)$row['total'];
    }
}

// Chart 6 - categoryId = 17
$monthlyData6 = array_fill(0, 12, 0);
$sql6 = "SELECT month, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 17 AND year = $selectedYear GROUP BY month ORDER BY month";
$result6 = mysqli_query($con, $sql6);
if ($result6) {
    while ($row = mysqli_fetch_assoc($result6)) {
        $monthlyData6[(int)$row['month'] - 1] = (int)$row['total'];
    }
}

// Chart 7 - categoryIds 52, 53, 54 (Average of total)
$monthlyData7 = array_fill(0, 12, 0);
$sql7 = "SELECT month, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId IN (52, 53, 54) AND year = $selectedYear GROUP BY month ORDER BY month";
$result7 = mysqli_query($con, $sql7);
if ($result7) {
    while ($row = mysqli_fetch_assoc($result7)) {
        $monthlyData7[(int)$row['month'] - 1] = (int)$row['total'] / 3;
    }
}

// Chart 8 - categoryId = 20
$monthlyData8 = array_fill(0, 12, 0);
$sql8 = "SELECT month, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 20 AND year = $selectedYear GROUP BY month ORDER BY month";
$result8 = mysqli_query($con, $sql8);
if ($result8) {
    while ($row = mysqli_fetch_assoc($result8)) {
        $monthlyData8[(int)$row['month'] - 1] = (int)$row['total'];
    }
}

// Chart 9 - categoryId = 30
$monthlyData9 = array_fill(0, 12, 0);
$sql9 = "SELECT month, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 30 AND year = $selectedYear GROUP BY month ORDER BY month";
$result9 = mysqli_query($con, $sql9);
if ($result9) {
    while ($row = mysqli_fetch_assoc($result9)) {
        $monthlyData9[(int)$row['month'] - 1] = (int)$row['total'];
    }
}
?>

<main class="content">
    <div class="container-fluid">
        <div class="header mb-3">
            <h1 class="header-title">Monthly KPI Charts (<?= $selectedYear ?>)</h1>
            <form method="GET" class="d-inline-block mt-2">
                <label for="year" style="color: white;">Select Year:</label>
                <select name="year" id="year" class="form-select form-select-sm w-auto d-inline-block" onchange="this.form.submit()">
                    <?php foreach ($years as $year): ?>
                        <option value="<?= $year ?>" <?= $year == $selectedYear ? 'selected' : '' ?>><?= $year ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <!-- Chart 1 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">No of Aircraft Incidents in Colombo FIR </h5>
            </div>
            <div class="card-body">
                <canvas id="chart1" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 2 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Aircraft Experiencing Delay on Ground (Category ID: 14)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart2" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 3 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Airside Incidents and Accidents (Category ID: 13)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart3" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 4 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Security audit compliance (Category ID: 15)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart4" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 5 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Incidents of security breaches (Category ID: 16)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart5" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

       

        <!-- Chart 7 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Average of Total (Category IDs: 52, 53, 54) Availability of Air Navigation , Communication, Surveillance systems services</h5>
            </div>
            <div class="card-body">
                <canvas id="chart7" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 8 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Achievement of procurement time schedule (PTS) (Category ID: 20)</h5>
            </div>
            <div class="card-body" style="max-width: 400px; margin: auto;">
                <canvas id="chart8" style="width: 100%; height: 300px;"></canvas>
            </div>
        </div>

        
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const months = <?php echo json_encode($months); ?>;
const data1 = <?php echo json_encode($monthlyData1); ?>;
const data2 = <?php echo json_encode($monthlyData2); ?>;
const data3 = <?php echo json_encode($monthlyData3); ?>;
const data4 = <?php echo json_encode($monthlyData4); ?>;
const data5 = <?php echo json_encode($monthlyData5); ?>;
const data7 = <?php echo json_encode($monthlyData7); ?>;
const data8 = <?php echo json_encode($monthlyData8); ?>;
const data9 = <?php echo json_encode($monthlyData9); ?>;

// Chart 1
new Chart(document.getElementById('chart1').getContext('2d'), {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: 'Aircraft Incidents',
            data: data1,
            backgroundColor: 'rgba(255, 99, 132, 0.7)',
            borderColor: 'rgba(255, 99, 132, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, ticks: { stepSize: 1000 } },
            x: { title: { display: true, text: 'Month' } }
        }
    }
});

// Chart 2
new Chart(document.getElementById('chart2').getContext('2d'), {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: 'Delays on Ground',
            data: data2,
            backgroundColor: 'rgba(54, 162, 235, 0.7)',
            borderColor: 'rgba(54, 162, 235, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, ticks: { stepSize: 1000 } },
            x: { title: { display: true, text: 'Month' } }
        }
    }
});

// Chart 3
new Chart(document.getElementById('chart3').getContext('2d'), {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: 'Airside Incidents',
            data: data3,
            backgroundColor: 'rgba(0, 0, 139, 0.7)',
            borderColor: 'rgba(0, 0, 139, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, ticks: { stepSize: 1000 } },
            x: { title: { display: true, text: 'Month' } }
        }
    }
});

// Chart 4
new Chart(document.getElementById('chart4').getContext('2d'), {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: 'Security audit compliance ',
            data: data4,
            backgroundColor: 'rgba(75, 192, 192, 0.7)',
            borderColor: 'rgba(75, 192, 192, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, ticks: { stepSize: 1000 } },
            x: { title: { display: true, text: 'Month' } }
        }
    }
});

// Chart 5
new Chart(document.getElementById('chart5').getContext('2d'), {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: 'security breaches',
            data: data5,
            backgroundColor: 'rgba(255, 159, 64, 0.7)',
            borderColor: 'rgba(255, 159, 64, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, ticks: { stepSize: 1000 } },
            x: { title: { display: true, text: 'Month' } }
        }
    }
});



// Chart 7 - Bar
new Chart(document.getElementById('chart7').getContext('2d'), {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: 'Average of Total (Cat 52, 53, 54) Availability of Air Navigation , Communication, Surveillance systems services',
            data: data7,
            backgroundColor: 'rgba(0, 0, 139, 0.7)',
            borderColor: 'rgba(0, 0, 139, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, ticks: { stepSize: 1000 } },
            x: { title: { display: true, text: 'Month' } }
        }
    }
});

// Chart 8 - Donut
new Chart(document.getElementById('chart8').getContext('2d'), {
    type: 'doughnut',
    data: {
        labels: months,
        datasets: [{
            label: ' time schedule ',
            data: data8,
            backgroundColor: months.map((_, i) =>
                `hsl(${i * 30}, 70%, 60%)` // dynamic colors
            ),
            borderColor: '#fff',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: ' time schedule'
            },
            legend: {
                position: 'right'
            }
        }
    }
});


</script>

<?php include 'includes/footer.php'; ?>