<?php
include 'includes/header.php';
include 'includes/leftnav.php';
?>

<div id="toast-success" style="
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    background-color: #28a745;
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    display: none;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
">
    Data saved successfully!
</div>

			<main class="content">
				<div class="container-fluid">

					<div class="header">
						<h1 class="header-title">
						Customer Perspective
						</h1>
						<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="dashboard-default.html">Main</a></li>
								<li class="breadcrumb-item"><a href="#">BSC - Data Management</a></li>
								<li class="breadcrumb-item active" aria-current="page">Customer</li>
							</ol>
						</nav>
                         <?php
           $division = isset($_SESSION['DIVISION']) ? $_SESSION['DIVISION'] : '';
            ?>

            <?php if ($division === 'MKT'): ?>
            <div class="mb-4 text-end">
                <a href="customer_kpi_view_MKT.php" class="btn btn-outline-primary">View Details</a>
            </div>
            <?php endif; ?>

            <?php if ($division === 'AM'): ?>
            <div class="mb-4 text-end">
                <a href="customer_kpi_view_AM.php" class="btn btn-outline-primary">View Details</a>
            </div>
            <?php endif; ?>

                        
					</div>

                <?php if ($_SESSION['DIVISION'] === 'MKT') : ?>
                    <!-- Passenger satisfaction level - MKT Division -->
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header'>
                                    <h1 class='card-title mb-0'>Passenger satisfaction level</h1>
                                    <h6>
                                        Please enter the Passenger satisfaction level at end of the quarter based on survey results (in %). 
                                        If no survey was conducted this quarter, indicate "Not Applicable"
                                    </h6>
                                </div>                             
                                <div class='card-body'>
                                    <div class="mb-3">
                                        <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                            <input type="hidden" name="categoryId" value="21">
                                            <input type="hidden" name="frequencyId" value="2">

                                            <!-- Year -->
                                            <div class="col-12">
                                                <label>Year</label>
                                                <select class="form-control" name="year" required>
                                                    <?php 
                                                    $currentYear = date('Y');
                                                    for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                        <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <!-- Quarter -->
                                            <div class="col-12">
                                                <label>Quarter</label>
                                                <select class="form-control" name="quarter" required>
                                                    <option value="1">Q1 (Jan - Mar)</option>
                                                    <option value="2">Q2 (Apr - Jun)</option>
                                                    <option value="3">Q3 (Jul - Sep)</option>
                                                    <option value="4">Q4 (Oct - Dec)</option>
                                                </select>
                                            </div>

                                            <!-- Airport -->
                                            <div class="col-12">
                                                <label>Airport</label>
                                                <select class="form-control" name="airportId" required>
                                                     <option value="1">BIA</option>
                                                <option value="2">MRIA</option>
                                                <option value="3">BTIA</option>
                                                <option value="4">JIA</option>
                                                <option value="5">CIAR</option>
                                                </select>
                                            </div>

                                            <!-- Value with Dropdown & Input -->
                                            <div class="col-12">
                                                <label>Value (%)</label>

                                                <select class="form-control mb-2" id="valueSelector1" onchange="toggleValueInput('1')">
                                                    <option value="enter">Enter Percentage</option>
                                                    <option value="0">Not Applicable</option>
                                                </select>

                                                <div class="input-group mb-2 me-sm-2" id="percentageInput1">
                                                    <div class="input-group-text">%</div>
                                                    <input type="number" 
                                                        min="0" max="100" step="0.01" 
                                                        class="form-control" 
                                                        id="itemvalueInput1"
                                                        name="itemvalue"
                                                        placeholder="0 - 100%">
                                                </div>
                                            </div>

                                            <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Airline satisfaction level - MKT Division -->
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header'>
                                    <h1 class='card-title mb-0'>Airline satisfaction level</h1>
                                    <h6>Please enter the Airline satisfaction level at the end of the quarter based on survey results (in %). If no survey was conducted this quarter, indicate "Not Applicable"</h6>
                                </div>                             
                                <div class='card-body'>
                                    <div class="mb-3">
                                        <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                            <input type="hidden" name="categoryId" value="22">
                                            <input type="hidden" name="frequencyId" value="2">

                                            <!-- Year -->
                                            <div class="col-12">
                                                <label>Year</label>
                                                <select class="form-control" name="year" required>
                                                    <?php 
                                                    for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                        <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <!-- Quarter -->
                                            <div class="col-12">
                                                <label>Quarter</label>
                                                <select class="form-control" name="quarter" required>
                                                    <option value="1">Q1 (Jan - Mar)</option>
                                                    <option value="2">Q2 (Apr - Jun)</option>
                                                    <option value="3">Q3 (Jul - Sep)</option>
                                                    <option value="4">Q4 (Oct - Dec)</option>
                                                </select>
                                            </div>

                                            <!-- Airport -->
                                            <div class="col-12">
                                                <label>Airport</label>
                                                <select class="form-control" name="airportId" required>
                                                     <option value="1">BIA</option>
                                                <option value="2">MRIA</option>
                                                <option value="3">BTIA</option>
                                                <option value="4">JIA</option>
                                                <option value="5">CIAR</option>
                                                </select>
                                            </div>

                                            <!-- Value with Dropdown & Input -->
                                            <div class="col-12">
                                                <label>Value (%)</label>

                                                <select class="form-control mb-2" id="valueSelector2" onchange="toggleValueInput('2')">
                                                    <option value="enter">Enter Percentage</option>
                                                    <option value="0">Not Applicable</option>
                                                </select>

                                                <div class="input-group mb-2 me-sm-2" id="percentageInput2">
                                                    <div class="input-group-text">%</div>
                                                    <input type="number" 
                                                        min="0" max="100" step="0.01" 
                                                        class="form-control" 
                                                        id="itemvalueInput2"
                                                        name="itemvalue"
                                                        placeholder="0 - 100%">
                                                </div>
                                            </div>

                                            <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                  
                    <?php endif; ?>


                    <?php if ($_SESSION['DIVISION'] === 'AM') : ?>
                    <!-- Number of passenger complaints - AM Division -->
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header'>
                                    <h1 class='card-title mb-0'>Number of passenger complaints</h1>
                                    
                                </div>                             
                                <div class='card-body ' id="collapseComplaints">
                                    <div class="mb-3">
                                        <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                            <input type="hidden" name="categoryId" value="23">
                                            
                                            <div class="col-12">
                                                <label>Year</label>
                                                <select class="form-control" name="year" required>
                                                    <?php 
                                                    $currentYear = date('Y');
                                                    for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                        <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <div class="col-12">
                                            <label>Quarter</label>
                                            <select class="form-control" name="quarter" required>
                                                <option value="1">Q1 (Jan - Mar)</option>
                                                <option value="2">Q2 (Apr - Jun)</option>
                                                <option value="3">Q3 (Jul - Sep)</option>
                                                <option value="4">Q4 (Oct - Dec)</option>
                                            </select>
                                            </div>


                                            <input type="hidden" name="frequencyId" value="2">
                                            <div class="col-12">
                                            <label>Airport</label>
                                            <select class="form-control" name="airportId" required>
                                                 <option value="1">BIA</option>
                                                <option value="2">MRIA</option>
                                                <option value="3">BTIA</option>
                                                <option value="4">JIA</option>
                                                <option value="5">CIAR</option>
                                            </select>
                                            </div>

                                            <div class="col-12">
                            <label>Value</label>
                            <div class="input-group mb-2 me-sm-2">
                                <div class="input-group-text">Value</div>
                                <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                            </div>
                        </div>
                                            
                                            <button type="submit" class="btn  mt-3 btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Cleanliness of the Airport rating - AM Division -->
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header' >
                                    <h1 class='card-title mb-0'>
                                        Cleanliness of the Airport rating
                                    </h1>
                                    <h6>Provide the average cleanliness rating on a scale of 1 - 10 at the end of the quarter. If no survey was conducted this quarter, indicate "Not Applicable"</h6>
                                </div>                             
                                <div class='card-body ' id="collapseCleanliness">
                                    <div class="mb-3">
                                        <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                            <input type="hidden" name="categoryId" value="24">
                                            
                                            <div class="col-12">
                                                <label>Year</label>
                                                <select class="form-control" name="year" required>
                                                    <?php 
                                                    $currentYear = date('Y');
                                                    for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                        <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <div class="col-12">
                                            <label>Quarter</label>
                                            <select class="form-control" name="quarter" required>
                                                <option value="1">Q1 (Jan - Mar)</option>
                                                <option value="2">Q2 (Apr - Jun)</option>
                                                <option value="3">Q3 (Jul - Sep)</option>
                                                <option value="4">Q4 (Oct - Dec)</option>
                                            </select>
                                            </div>

                                            <input type="hidden" name="frequencyId" value="2">
                                            <div class="col-12">
                                            <label>Airport</label>
                                            <select class="form-control" name="airportId" required>
                                                <option value="1">BIA</option>
                                                <option value="2">MRIA</option>
                                                <option value="3">BTIA</option>
                                                <option value="4">JIA</option>
                                                <option value="5">CIAR</option>
                                            </select>
                                            </div>

                                            <div class="col-12">
                                    <label>Value (1 - 10 or Not Applicable)</label>
                                    <div class="input-group mb-2 me-sm-2">
                                        <select class="form-control" name="itemvalue" onchange="toggleCustomInput(this)">
                                            <option value="">-- Rating --</option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                            <option value="6">6</option>
                                            <option value="7">7</option>
                                            <option value="8">8</option>
                                            <option value="9">9</option>
                                            <option value="10">10</option>
                                            <option value="0">Not Applicable</option>
                                        </select>
                                    </div>
                                </div>


                                            
                                            <button type="submit" class="btn  mt-3 btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Average Passenger processing time (Min) - Arrival - AM Division -->
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header' >
                                    <h1 class='card-title mb-0'>
                                        Average Passenger processing time (Min) - Arrival
                                    </h1>
                                    <h6>Enter the average time (in minutes) taken to process arriving passengers this month from disembarkation to exit</h6>
                                </div>                             
                                <div class='card-body ' id="collapseArrival">
                                    <div class="mb-3">
                                        <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/customerController.php">
                                            <input type="hidden" name="categoryId" value="25">
                                            
                                            <div class="col-12">
                                                <label>Year</label>
                                                <select class="form-control" name="year" required>
                                                    <?php 
                                                    $currentYear = date('Y');
                                                    for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                        <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <div class="col-12">
                                            <label>Quarter</label>
                                            <select class="form-control" name="quarter" required>
                                                <option value="1">Q1 (Jan - Mar)</option>
                                                <option value="2">Q2 (Apr - Jun)</option>
                                                <option value="3">Q3 (Jul - Sep)</option>
                                                <option value="4">Q4 (Oct - Dec)</option>
                                            </select>
                                            </div>

                                            <input type="hidden" name="frequencyId" value="2">
                                            <div class="col-12">
                                            <label>Airport</label>
                                            <select class="form-control" name="airportId" required>
                                                <option value="1">BIA</option>
                                                <option value="2">MRIA</option>
                                                <option value="3">BTIA</option>
                                                <option value="4">JIA</option>
                                                <option value="5">CIAR</option>
                                            </select>
                                            </div>

                                            <div class="col-12">
                            <label>Value</label>
                            <div class="input-group mb-2 me-sm-2">
                                <div class="input-group-text">Value</div>
                                <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                            </div>
                        </div>
                                            
                                            <button type="submit" class="btn  mt-3 btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Average Passenger processing time (Min) - Departure - AM Division -->
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header' >
                                    <h1 class='card-title mb-0'>
                                        Average Passenger processing time (Min) - Departure
                                    </h1>
                                    <h6>Enter the average time (in minutes) taken to process departing passengers this month from entry to boarding gate.</h6>
                                </div>                             
                                <div class='card-body ' id="collapseDeparture">
                                    <div class="mb-3">
                                        <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                            <input type="hidden" name="categoryId" value="26">
                                            
                                            <div class="col-12">
                                                <label>Year</label>
                                                <select class="form-control" name="year" required>
                                                    <?php 
                                                    $currentYear = date('Y');
                                                    for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                        <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <div class="col-12">
                                            <label>Quarter</label>
                                            <select class="form-control" name="quarter" required>
                                                <option value="1">Q1 (Jan - Mar)</option>
                                                <option value="2">Q2 (Apr - Jun)</option>
                                                <option value="3">Q3 (Jul - Sep)</option>
                                                <option value="4">Q4 (Oct - Dec)</option>
                                            </select>
                                            </div>

                                            <input type="hidden" name="frequencyId" value="2">
                                            <div class="col-12">
                                            <label>Airport</label>
                                            <select class="form-control" name="airportId" required>
                                                <option value="1">BIA</option>
                                                <option value="2">MRIA</option>
                                                <option value="3">BTIA</option>
                                                <option value="4">JIA</option>
                                                <option value="5">CIAR</option>
                                            </select>
                                            </div>

                                            <div class="col-12">
                            <label>Value</label>
                            <div class="input-group mb-2 me-sm-2">
                                <div class="input-group-text">Value</div>
                                <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                            </div>
                        </div>
                                            
                                            <button type="submit" class="btn  mt-3 btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <!-- No. of new products / services / process improvements introduced -->
       
                    <?php endif; ?>

                    <?php if (!in_array($_SESSION['DIVISION'], ['MKT', 'AM'])) : ?>
                    <div class='row'>
                        <div class='col-12'>
                            <div class='alert alert-info'>
                                <p>The Customer perspective is primarily managed by MKT, AM division.</p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

				</div>
			</main>
<?php
include 'includes/footer.php';            
?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const toast = document.getElementById('toast-success');

    document.querySelectorAll(".kpi-form").forEach(form => {
        form.addEventListener("submit", function(e) {
            e.preventDefault();

            const formData = new FormData(form);
            const submitButton = form.querySelector('button[type="submit"]');

            submitButton.disabled = true;
            submitButton.innerHTML = 'Saving...';

            fetch("Controller/customerController.php", {
                method: "POST",
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(res => {
                if (res.trim() === "Success") {
                    form.reset();
                    showToast("Data saved successfully!", true);
                } else {
                    showToast("Error: " + res, false);
                }
            })
            .catch(error => {
                showToast("AJAX error: " + error.message, false);
            })
            .finally(() => {
                submitButton.disabled = false;
                submitButton.innerHTML = 'Submit';
            });
        });
    });

    function showToast(message, isSuccess) {
        toast.textContent = message;
        toast.style.backgroundColor = isSuccess ? '#28a745' : '#dc3545'; // Green or Red
        toast.style.display = 'block';

        setTimeout(() => {
            toast.style.display = 'none';
        }, 3000);
    }
});

function toggleValueInput(formId) {
    const selector = document.getElementById("valueSelector" + formId);
    const inputGroup = document.getElementById("percentageInput" + formId);
    const inputField = document.getElementById("itemvalueInput" + formId);

    if (selector.value === "0") {
        inputGroup.style.display = "none";
        inputField.value = "0";  // Ensure 0 is sent when 'Not Applicable' is selected
    } else {
        inputGroup.style.display = "flex";
        inputField.value = "";
    }
}

</script>
