<?php
session_start();
include 'includes/header.php';
include 'includes/leftnav.php';

$con = mysqli_connect("localhost", "root", "", "kpi-dashboard");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Define training types
$trainingNames = [
    1 => 'Local',
    2 => 'Foreign',
];

// Correct category mapping
$categoryNames = [
    27 => "Employee job satisfaction",
    28 => "Number of trainings conducted (Local & Foreign)",
    29 => "Employee turnover (%)",
    30 => "New products/services/process improvements",
];

// Capture and sanitize filters
$selectedYear = isset($_GET['year']) ? filter_var($_GET['year'], FILTER_VALIDATE_INT) : '';
$selectedCategory = isset($_GET['categoryId']) ? filter_var($_GET['categoryId'], FILTER_VALIDATE_INT) : '';

// Prepare SQL query
$sql = "SELECT categoryId, year, month, training_type, description, itemvalue, created_at
        FROM kpi_data 
        WHERE categoryId IN (27, 28, 29, 30)";
$params = [];
$types = "";

if ($selectedYear !== '' && $selectedYear !== false) {
    $sql .= " AND year = ?";
    $params[] = $selectedYear;
    $types .= "i";
}
if ($selectedCategory !== '' && $selectedCategory !== false) {
    $sql .= " AND categoryId = ?";
    $params[] = $selectedCategory;
    $types .= "i";
}
$sql .= " ORDER BY year DESC, created_at DESC";

// Prepare and execute query
$stmt = $con->prepare($sql);
if (!$stmt) {
    die("Prepare failed: " . $con->error);
}
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<main class="content" style="padding-top: 80px;">
    <div class="container-fluid">
        <div class="header mb-3">
            <h1 class="header-title">Learning KPI View – HR Division</h1>
        </div>

        <!-- Filter Form -->
        <form method="GET" class="row g-3 mb-4">
            <div class="col-md-4">
                <label for="year" class="form-label">Year</label>
                <select name="year" id="year" class="form-select">
                    <option value="">All Years</option>
                    <?php
                    $currentYear = date('Y');
                    for ($y = $currentYear - 5; $y <= $currentYear + 1; $y++): ?>
                        <option value="<?= $y ?>" <?= ($selectedYear == $y) ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="col-md-4">
                <label for="categoryId" class="form-label">Category</label>
                <select name="categoryId" id="categoryId" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($categoryNames as $id => $name): ?>
                        <option value="<?= $id ?>" <?= ($selectedCategory == $id) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($name) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-4 d-flex align-items-end">
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="learning_kpi_view_HR.php" class="btn btn-secondary ms-2">Reset</a>
            </div>
        </form>

        <!-- KPI Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Category</th>
                        <th>Year</th>
                        <th>Training Type</th>
                        <th>Description</th>
                        <th>Value</th>
                        <th>Submitted At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['categoryId']) ?></td>
                                <td><?= htmlspecialchars($categoryNames[$row['categoryId']] ?? '-') ?></td>
                                <td><?= htmlspecialchars($row['year']) ?></td>
                                <td>
                                    <?php
                                    if ($row['categoryId'] == 28 && isset($trainingNames[$row['training_type']])) {
                                        echo htmlspecialchars($trainingNames[$row['training_type']]);
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td><?= htmlspecialchars($row['description'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($row['itemvalue']) ?></td>
                                <td><?= htmlspecialchars($row['created_at']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center">No data available</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<?php
$stmt->close();
$con->close();
include 'includes/footer.php';
?>