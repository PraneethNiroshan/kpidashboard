<?php
session_start();
include 'includes/header.php';
include 'includes/leftnav.php';
?>

<div id="toast-success" style="
    position: fixed;
    top: 60px;
    right: 20px;
    z-index: 9999;
    background-color: #28a745;
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    display: none;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
">
    Data saved successfully!
</div>

<?php
if (isset($_GET['success']) && $_GET['success'] == 'true') {
    echo "<script>
        document.getElementById('toast-success').style.display = 'block';
        setTimeout(function() {
            document.getElementById('toast-success').style.display = 'none';
        }, 3000);
    </script>";
}
?>

<main class="content">
    <div class="container-fluid">
        <div class="header">
            <h1 class="header-title">Internal Process</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard-default.html">Main</a></li>
                    <li class="breadcrumb-item"><a href="#">BSC - Data Management</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Internal Process</li>
                </ol>
            </nav>

            <?php
           $division = isset($_SESSION['DIVISION']) ? $_SESSION['DIVISION'] : '';
            ?>

            <?php if ($division === 'ANS'): ?>
                <div class="mb-4 text-end">
                    <a href="internal_kpi_view_ANS.php" class="btn btn-outline-primary">View Details</a>
                </div>
            <?php endif; ?>

            <?php if ($division === 'AM'): ?>
                <div class="mb-4 text-end">
                    <a href="Internal_kpi_view_AM.php" class="btn btn-outline-primary">View Details</a>
                </div>
            <?php endif; ?>

            <?php if ($division === 'Sec'): ?>
                <div class="mb-4 text-end">
                    <a href="Internal_kpi_view_Sec.php" class="btn btn-outline-primary">View Details</a>
                </div>
            <?php endif; ?>

            <?php if ($division === 'EANE'): ?>
                <div class="mb-4 text-end">
                    <a href="Internal_kpi_view_EANE.php" class="btn btn-outline-primary">View Details</a>
                </div>
            <?php endif; ?>

            <?php if ($division === 'SCM'): ?>
                <div class="mb-4 text-end">
                    <a href="Internal_kpi_view_SCM.php" class="btn btn-outline-primary">View Details</a>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if ($_SESSION['DIVISION'] === 'ANS'): ?>
            <!-- Aircraft Incidents in Colombo FIR -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse1" aria-expanded="true" aria-controls="collapse1">
                            <h1 class='card-title mb-0'>Aircraft Incidents in Colombo FIR - </h1>
                            <h6>Enter the total number of aircraft incidents reported within the Colombo FIR during the month.</h6>
                        </div>                              
                        <div class='card-body collapse' id="collapse1">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                    <input type="hidden" name="categoryId" value="12">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect1" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect1" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
            <!-- Aircraft Experiencing a Delay on Ground -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="true" aria-controls="collapse2">
                            <h1 class='card-title mb-0'>Aircraft Experiencing a Delay on Ground - </h1>
                            <h6>Enter the total number of Aircraft Experiencing a Delay on Ground Due to ATC Delays during the month.</h6>
                        </div>                              
                        <div class='card-body collapse' id="collapse2">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                    <input type="hidden" name="categoryId" value="14">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect2" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect2" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($_SESSION['DIVISION'] === 'AM'): ?>
            <!-- Airside incidents and accidents -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse3" aria-expanded="true" aria-controls="collapse3">
                            <h1 class='card-title mb-0'>Airside incidents and accidents</h1>
                            <h6>Enter the total number of incidents and accidents that occurred in the airside area during the month.</h6>
                        </div>                              
                        <div class='card-body collapse' id="collapse3">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                    <input type="hidden" name="categoryId" value="13">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect3" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect3" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if ($_SESSION['DIVISION'] === 'Sec'): ?>
            <!-- Security audit compliance % -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse5" aria-expanded="true" aria-controls="collapse5">
                            <h1 class='card-title mb-0'>Security audit compliance </h1>
                            <h6>Enter the latest aviation security audit score (ICAO).</h6>
                        </div>                              
                        <div class='card-body collapse' id="collapse5">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                    <input type="hidden" name="categoryId" value="15">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect4" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect4" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
            <!-- Incidents of security breaches -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse6" aria-expanded="true" aria-controls="collapse6">
                            <h1 class='card-title mb-0'>Incidents of security breaches</h1>
                            <h6>Provide the number of confirmed security breach incidents (unauthorized access, prohibited items, etc.) recorded at airport premises during the month.</h6>
                        </div>                              
                        <div class='card-body collapse' id="collapse6">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                    <input type="hidden" name="categoryId" value="16">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect5" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect5" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if ($_SESSION['DIVISION'] === 'EANE'): ?>
            <!-- Availability of  Surveillance systems services -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse7" aria-expanded="true" aria-controls="collapse7">
                            <h1 class='card-title mb-0'>Availability of Air Navigation</h1>
                        </div>                              
                        <div class='card-body collapse' id="collapse7">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                    <input type="hidden" name="categoryId" value="52">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect6" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect6" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Availability of Communication,  -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse7" aria-expanded="true" aria-controls="collapse7">
                            <h1 class='card-title mb-0'>Availability of Communication</h1>
                        </div>                              
                        <div class='card-body collapse' id="collapse7">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                    <input type="hidden" name="categoryId" value="53">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect6" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect6" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Availability of  Surveillance systems services -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse7" aria-expanded="true" aria-controls="collapse7">
                            <h1 class='card-title mb-0'>Availability of Surveillance systems services</h1>
                        </div>                              
                        <div class='card-body collapse' id="collapse7">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                    <input type="hidden" name="categoryId" value="54">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect6" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect6" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
            
        <?php endif; ?>
        
        <?php if ($_SESSION['DIVISION'] === 'SCM'): ?>
            <!-- Achievement of procurement time schedule (PTS) -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse9" aria-expanded="true" aria-controls="collapse9">
                            <h1 class='card-title mb-0'>Achievement of procurement time schedule (PTS)</h1>
                            <h6>Enter the percentage of procurement activities completed within the planned time schedule (PTS) during the month of reporting.</h6>
                        </div>                              
                        <div class='card-body collapse' id="collapse9">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/kpiController.php">
                                    <input type="hidden" name="categoryId" value="20">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect8" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect8" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!in_array($_SESSION['DIVISION'], ['ANS', 'AM', 'Sec', 'EANE', 'SCM'])): ?>
            <div class='row'>
                <div class='col-12'>
                    <div class='alert alert-info'>
                        <!-- <h4>No Learning & Growth metrics available for your division.</h4> -->
                        <p>The Internal Process perspective is primarily managed by ANS, AM, Sec, E&ANE and SCM division.</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php include 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const toast = document.getElementById('toast-success');

    document.querySelectorAll(".kpi-form").forEach(form => {
        form.addEventListener("submit", function(e) {
            e.preventDefault();

            const formData = new FormData(form);
            const submitButton = form.querySelector('button[type="submit"]');

            submitButton.disabled = true;
            submitButton.innerHTML = 'Saving...';

            fetch("Controller/kpiController.php", {
                method: "POST",
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(res => {
                if (res.trim() === "Success") {
                    form.reset();
                    showToast("Data saved successfully!", true);
                } else {
                    showToast("Error: " + res, false);
                }
            })
            .catch(error => {
                showToast("AJAX error: " + error.message, false);
            })
            .finally(() => {
                submitButton.disabled = false;
                submitButton.innerHTML = 'Submit';
            });
        });
    });

    function showToast(message, isSuccess) {
        toast.textContent = message;
        toast.style.backgroundColor = isSuccess ? '#28a745' : '#dc3545'; // Green or Red
        toast.style.display = 'block';

        setTimeout(() => {
            toast.style.display = 'none';
        }, 3000);
    }

    // Month restriction functionality
    const yearSelects = [
        { year: document.getElementById('yearSelect1'), month: document.getElementById('monthSelect1') },
        { year: document.getElementById('yearSelect2'), month: document.getElementById('monthSelect2') },
        { year: document.getElementById('yearSelect3'), month: document.getElementById('monthSelect3') },
        { year: document.getElementById('yearSelect4'), month: document.getElementById('monthSelect4') },
        { year: document.getElementById('yearSelect5'), month: document.getElementById('monthSelect5') },
        { year: document.getElementById('yearSelect6'), month: document.getElementById('monthSelect6') },
        { year: document.getElementById('yearSelect7'), month: document.getElementById('monthSelect7') },
        { year: document.getElementById('yearSelect8'), month: document.getElementById('monthSelect8') }
    ];

    function updateMonths(yearSelect, monthSelect) {
        if (!yearSelect || !monthSelect) return;
        
        const selectedYear = parseInt(yearSelect.value);
        const currentYear = new Date().getFullYear();
        const currentMonth = new Date().getMonth() + 1; // Current month (1-12)

        for (let month = 1; month <= 12; month++) {
            const monthOption = monthSelect.options[month - 1];
            if (monthOption) {
                if (selectedYear < currentYear) {
                    monthOption.disabled = false; // All months enabled for past years
                } else if (selectedYear === currentYear) {
                    monthOption.disabled = month > currentMonth; // Disable future months for current year
                } else {
                    monthOption.disabled = true; // Disable all months for future years
                }
            }
        }
    }

    // Initialize and set event listeners
    yearSelects.forEach(({ year, month }) => {
        if (year && month) {
            // Initialize on page load
            updateMonths(year, month);
            
            // Update when year changes
            year.addEventListener('change', function() {
                updateMonths(year, month);
            });
        }
    });
});
</script>