<?php
session_start();
include 'includes/header.php';
include 'includes/leftnav.php';

// Database connection
$con = mysqli_connect("localhost", "root", "", "kpi-dashboard");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get distinct years
$years = [];
$yearResult = mysqli_query($con, "SELECT DISTINCT year FROM kpi_data ORDER BY year DESC");
while ($row = mysqli_fetch_assoc($yearResult)) {
    $years[] = $row['year'];
}
$selectedYear = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Month map
$months = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
];
$selectedMonth = isset($_GET['month']) ? intval($_GET['month']) : 0;

// Airport labels
$airportMap = [
    1 => 'BIA',
    2 => 'MRIA',
    3 => 'BTA',
    4 => 'JIA',
    5 => 'RMA'
];
$airportLabels = array_values($airportMap);

// Travel type map
$travelTypeMap = [
    1 => 'International',
    2 => 'Domestic',
    3 => 'Transit/Transfer' // Ensure this exists
];
$travelColors = [
    'International' => 'rgba(255, 99, 132, 0.6)',
    'Domestic' => 'rgba(54, 162, 235, 0.6)',
    'Transit/Transfer' => 'rgba(255, 206, 86, 0.6)'
];

// Cargo type map for category 51
$cargoTypes = [
    1 => 'Import',
    2 => 'Export'
];
$cargoColors = [
    'Import' => 'rgba(75, 192, 192, 0.6)',
    'Export' => 'rgba(153, 102, 255, 0.6)'
];

// Category map
$categoryMap = [
    48 => 'Total PAX',
    49 => 'Total A/C Handled',
    50 => 'Overflights',
    51 => 'Cargo Handled'
];

// Prepare chart data structures
$chartData = [];
$chartJSData = [];

foreach ($categoryMap as $catId => $catName) {
    if ($catId == 50) {
        // Chart 3 - Overflights: Month vs Total
        $query = "
            SELECT month, SUM(itemvalue) AS total
            FROM kpi_data
            WHERE categoryId = 50 AND year = $selectedYear
        ";

        if ($selectedMonth > 0) {
            $query .= " AND month = $selectedMonth GROUP BY month";
        } else {
            $query .= " GROUP BY month ORDER BY month";
        }

        $result = mysqli_query($con, $query);
        $monthlyTotals = array_fill(1, 12, 0);
        while ($row = mysqli_fetch_assoc($result)) {
            $monthNum = (int)$row['month'];
            $monthlyTotals[$monthNum] = (float)$row['total'];
        }

        $chartJSData[$catId] = [[
            'label' => 'Overflights',
            'data' => $selectedMonth > 0
                ? [$monthlyTotals[$selectedMonth]]
                : array_values($monthlyTotals),
            'backgroundColor' => 'rgba(0, 0, 139, 0.7)',
            'borderColor' => 'rgba(0, 0, 139, 0.7)',
            'borderWidth' => 1
        ]];
    } else {
        // All other charts: Airport x Travel Type (except 51 uses cargo_type)
        if ($catId == 51) {
            // For Cargo Handled, use cargo_type (Import, Export)
            foreach ($cargoTypes as $cLabel) {
                foreach ($airportMap as $aLabel) {
                    $chartData[$catId][$cLabel][$aLabel] = 0;
                }
            }

            $query = "
                SELECT airportId, cargo_type, SUM(itemvalue) AS total
                FROM kpi_data
                WHERE categoryId = $catId AND year = $selectedYear AND cargo_type IS NOT NULL
            ";
            if ($selectedMonth > 0) {
                $query .= " AND month = $selectedMonth";
            }
            $query .= " GROUP BY airportId, cargo_type";

            $result = mysqli_query($con, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                $airportId = $row['airportId'];
                $typeId = $row['cargo_type'];
                $total = (float)$row['total'];

                if (isset($airportMap[$airportId]) && isset($cargoTypes[$typeId])) {
                    $airportName = $airportMap[$airportId];
                    $typeLabel = $cargoTypes[$typeId];
                    $chartData[$catId][$typeLabel][$airportName] = $total;
                }
            }

            // Calculate total for each airport: Import + Export
            $datasets = [];
            foreach ($chartData[$catId] as $typeLabel => $airportValues) {
                $datasets[] = [
                    'label' => $typeLabel,
                    'data' => array_values($airportValues),
                    'backgroundColor' => $cargoColors[$typeLabel],
                    'borderColor' => str_replace('0.6', '1', $cargoColors[$typeLabel]),
                    'borderWidth' => 1
                ];
            }

            // Add the "Total" bar for each airport: Import + Export
            $totalData = [];
            foreach ($airportMap as $airportName) {
               // $totalData[] = ($chartData[$catId]['Import'][$airportName] ?? 0) + ($chartData[$catId]['Export'][$airportName] ?? 0);
                $totalData[] = (isset($chartData[$catId]['Import'][$airportName]) ? $chartData[$catId]['Import'][$airportName] : 0) +(isset($chartData[$catId]['Export'][$airportName]) ? $chartData[$catId]['Export'][$airportName] : 0);

            }

            $datasets[] = [
                'label' => 'Total',
                'data' => $totalData,
                'backgroundColor' => 'rgba(0, 255, 0, 0.6)', // Green color for the total bar
                'borderColor' => 'rgba(0, 255, 0, 0.6)',
                'borderWidth' => 1
            ];

            $chartJSData[$catId] = $datasets;
        } else {
            // For categories 48 and 49, use travel_type (International, Domestic)
            foreach ($travelTypeMap as $tLabel) {
                foreach ($airportMap as $aLabel) {
                    $chartData[$catId][$tLabel][$aLabel] = 0;
                }
            }

            $query = "
                SELECT airportId, travel_type, SUM(itemvalue) AS total
                FROM kpi_data
                WHERE categoryId = $catId AND year = $selectedYear AND travel_type IS NOT NULL
            ";
            if ($selectedMonth > 0) {
                $query .= " AND month = $selectedMonth";
            }
            $query .= " GROUP BY airportId, travel_type";

            $result = mysqli_query($con, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                $airportId = $row['airportId'];
                $typeId = $row['travel_type'];
                $total = (float)$row['total'];

                if (isset($airportMap[$airportId]) && isset($travelTypeMap[$typeId])) {
                    $airportName = $airportMap[$airportId];
                    $typeLabel = $travelTypeMap[$typeId];
                    $chartData[$catId][$typeLabel][$airportName] = $total;
                }
            }

            // Calculate total for each airport: International + Domestic
            $datasets = [];
            foreach ($chartData[$catId] as $typeLabel => $airportValues) {
                $datasets[] = [
                    'label' => $typeLabel,
                    'data' => array_values($airportValues),
                    'backgroundColor' => $travelColors[$typeLabel],
                    'borderColor' => str_replace('0.6', '1', $travelColors[$typeLabel]),
                    'borderWidth' => 1
                ];
            }

            // Add the "Total" bar for each airport: International + Domestic
            $totalData = [];
            foreach ($airportMap as $airportName) {
                //$totalData[] = ($chartData[$catId]['International'][$airportName] ?? 0) + ($chartData[$catId]['Domestic'][$airportName] ?? 0);
                $totalData[] =
    (isset($chartData[$catId]['International'][$airportName]) ? $chartData[$catId]['International'][$airportName] : 0) +
    (isset($chartData[$catId]['Domestic'][$airportName]) ? $chartData[$catId]['Domestic'][$airportName] : 0);
            }

            $datasets[] = [
                'label' => 'Total',
                'data' => $totalData,
                'backgroundColor' => 'rgba(0, 255, 0, 0.6)', // Green color for the total bar
                'borderColor' => 'rgba(0, 255, 0, 0.6)',
                'borderWidth' => 1
            ];

            $chartJSData[$catId] = $datasets;
        }
    }
}
?>

<main class="content">
    <div class="container-fluid">
        <div class="header mb-3">
            <h1 class="header-title">Grouped KPI Charts (<?= $selectedYear ?><?= $selectedMonth ? " - " . $months[$selectedMonth] : "" ?>)</h1>
            <form method="GET" class="d-flex flex-wrap align-items-center gap-2 mt-2">
                <label for="year" style="color: white;">Select Year:</label>
                <select name="year" id="year" class="form-select form-select-sm w-auto" onchange="this.form.submit()">
                    <?php foreach ($years as $year): ?>
                        <option value="<?= $year ?>" <?= $year == $selectedYear ? 'selected' : '' ?>><?= $year ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="month" style="color: white;">Select Month:</label>
                <select name="month" id="month" class="form-select form-select-sm w-auto" onchange="this.form.submit()">
                    <option value="0" <?= $selectedMonth == 0 ? 'selected' : '' ?>>All</option>
                    <?php foreach ($months as $num => $name): ?>
                        <option value="<?= $num ?>" <?= $selectedMonth == $num ? 'selected' : '' ?>><?= $name ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <?php foreach ($categoryMap as $catId => $catName): ?>
            <div class="card mb-4">
                <div class="card-header"><h5><?= $catName ?> (Category ID: <?= $catId ?>)</h5></div>
                <div class="card-body"><canvas id="chart<?= $catId ?>"></canvas></div>
            </div>
        <?php endforeach; ?>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const labels = <?= json_encode($airportLabels); ?>;
const fullMonthLabels = <?= json_encode(array_values($months)); ?>;
const selectedMonth = <?= $selectedMonth ?>;
const chartJSData = <?= json_encode($chartJSData); ?>;

for (const catId in chartJSData) {
    const ctx = document.getElementById('chart' + catId);
    const isOverflight = parseInt(catId) === 50;

    new Chart(ctx, {
    type: 'bar',
    data: {
        labels: isOverflight
            ? (selectedMonth > 0 ? [fullMonthLabels[selectedMonth - 1]] : fullMonthLabels)
            : labels,
        datasets: chartJSData[catId]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' },
            title: {
                display: true,
                text: isOverflight
                    ? 'Overflights (Monthly View)'
                    : 'Airport-wise Breakdown by Travel Type'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Item Value' }
            },
            x: {
                title: {
                    display: true,
                    text: isOverflight ? 'Month' : 'Airport'
                }
            }
        },
        barPercentage: 0.8,
        categoryPercentage: 0.6
    }
});
}
</script>

<?php include 'includes/footer.php'; ?>