<?php
session_start();
require_once '../model/kpiModel.php';

class CustomerController {
    private $model;
    private $dbConnection;

    public function __construct($dbConnection) {
        $this->dbConnection = $dbConnection;
        $this->model = new KpiModel($dbConnection);
    }

    public function handleFormSubmission() {
        // Check if user is logged in and has a valid division
        if (!isset($_SESSION['DIVISION']) || !in_array($_SESSION['DIVISION'], ['MKT', 'AM'])) {
            echo "Unauthorized access";
            exit;
        }

        // Validate required fields
        $requiredFields = ['categoryId', 'year', 'frequencyId', 'itemvalue', 'airportId'];
        foreach ($requiredFields as $field) {
            if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
                echo "Missing or empty required field: $field";
                exit;
            }
        }

        // Sanitize inputs
        $categoryId  = filter_var($_POST['categoryId'], FILTER_VALIDATE_INT);
        $year        = filter_var($_POST['year'], FILTER_VALIDATE_INT);
        $frequencyId = filter_var($_POST['frequencyId'], FILTER_VALIDATE_INT);
        $itemvalue   = filter_var($_POST['itemvalue'], FILTER_VALIDATE_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $airportId   = filter_var($_POST['airportId'], FILTER_VALIDATE_INT);

        // Handle quarter and month (either one can be used based on KPI type)
        $quarter = isset($_POST['quarter']) && $_POST['quarter'] !== '' 
            ? filter_var($_POST['quarter'], FILTER_VALIDATE_INT) 
            : null;

        $month = isset($_POST['month']) && $_POST['month'] !== '' 
            ? filter_var($_POST['month'], FILTER_VALIDATE_INT) 
            : null;

        // Handle travel type
        $travelType = isset($_POST['travel_type']) 
            ? filter_var($_POST['travel_type'], FILTER_VALIDATE_INT) 
            : 0;

        // Handle optional description
        $description = isset($_POST['description']) && !empty(trim($_POST['description'])) 
            ? htmlspecialchars($_POST['description'], ENT_QUOTES, 'UTF-8') 
            : null;

        // Fallback values
        if ($quarter === false || $quarter === null) $quarter = 0;
        if ($month === false || $month === null) $month = 0;
        if ($travelType === false) $travelType = 0;

        // Validation
        $errors = [];
        if ($categoryId === false) $errors[] = "Invalid category ID";
        if ($year === false || $year < 2000 || $year > (int)date('Y') + 1) $errors[] = "Invalid year";
        if ($quarter !== null && ($quarter < 0 || $quarter > 4)) $errors[] = "Invalid quarter";
        if ($month !== null && ($month < 0 || $month > 12)) $errors[] = "Invalid month";
        if ($frequencyId === false) $errors[] = "Invalid frequency ID";
        if ($itemvalue === false || $itemvalue < 0) $errors[] = "Invalid item value (must be non-negative)";
        if ($airportId === false) $errors[] = "Invalid airport ID";

        if (!empty($errors)) {
            echo implode(", ", $errors);
            exit;
        }

        // Check if data already exists for the same year, month, quarter, and category
        if ($this->isDataExists($categoryId, $year, $month, $quarter, $airportId)) {
            echo " Data for this quarter already exists.";
            exit;
        }

        // Map division name to division_id
        $divisionMap = ['MKT' => 17, 'AM' => 13]; // Adjust based on your database
        $divisionId = $divisionMap[$_SESSION['DIVISION']] ?? 0;

        // Save to database
        $result = $this->model->saveKpi(
            $categoryId,
            $year,
            $month,
            $quarter,
            $frequencyId,
            $itemvalue,
            $airportId,
            $travelType,
            $description, // Added description parameter
            $divisionId
        );

        if ($result === true) {
            echo "Success";
        } else {
            echo "Error saving data: " . ($result ?: $this->dbConnection->error);
            $this->dbConnection->close(); // Ensure connection is closed on error
            exit;
        }
    }

    // Check if data already exists for the same year, month, quarter, and airport
    private function isDataExists($categoryId, $year, $month, $quarter, $airportId) {
        // Use the $dbConnection property to prepare and execute the query
        if ($quarter !== null) {
            // Check for data based on quarter
            $checkQuery = "SELECT * FROM kpi_data WHERE categoryId = ? AND year = ? AND quarter = ? AND airportId = ?";
            $stmt = $this->dbConnection->prepare($checkQuery);
            $stmt->bind_param("iiii", $categoryId, $year, $quarter, $airportId);
        } else {
            // Check for data based on month
            $checkQuery = "SELECT * FROM kpi_data WHERE categoryId = ? AND year = ? AND month = ? AND airportId = ?";
            $stmt = $this->dbConnection->prepare($checkQuery);
            $stmt->bind_param("iiii", $categoryId, $year, $month, $airportId);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        return $result->num_rows > 0; // Returns true if data exists, false otherwise
    }
}

// Initialize controller
$dbConnection = new mysqli('localhost', 'root', '', 'kpi-dashboard');
if ($dbConnection->connect_error) {
    die("Database connection failed: " . $dbConnection->connect_error);
}

$controller = new CustomerController($dbConnection);
$controller->handleFormSubmission();

// Close database connection
$dbConnection->close();
?>
