<?php
session_start();
include 'includes/header.php';
include 'includes/leftnav.php';

// Database connection
$con = mysqli_connect("localhost", "root", "", "kpi-dashboard");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Chart 1: categoryId = 27 (Employee Job Satisfaction)
$yearLabels1 = [];
$yearValues1 = [];
$sql1 = "SELECT year, SUM(itemvalue) AS total 
         FROM kpi_data 
         WHERE categoryId = 27 
         GROUP BY year 
         ORDER BY year";
$result1 = mysqli_query($con, $sql1);
if ($result1) {
    while ($row = mysqli_fetch_assoc($result1)) {
        $yearLabels1[] = $row['year'];
        $yearValues1[] = (int)$row['total'];
    }
}

// Chart 2: categoryId = 28 (Trainings Conducted)
$yearLabels2 = [];
$yearValues2 = [];
$sql2 = "SELECT year, SUM(itemvalue) AS total 
         FROM kpi_data 
         WHERE categoryId = 28 
         GROUP BY year 
         ORDER BY year";
$result2 = mysqli_query($con, $sql2);
if ($result2) {
    while ($row = mysqli_fetch_assoc($result2)) {
        $yearLabels2[] = $row['year'];
        $yearValues2[] = (int)$row['total'];
    }
}

// Chart 3: categoryId = 29 (Employee Turnover) - Calculate turnover rate
$yearLabels3 = [];
$yearValues3 = [];
$sql3 = "SELECT 
            k1.year,
            k1.itemvalue AS employees_left,
            k2.itemvalue AS average_employees
         FROM kpi_data k1
         INNER JOIN kpi_data k2 ON k1.year = k2.year
         WHERE k1.categoryId = 29 
         AND k2.categoryId = 29
         AND k1.description = 'Employees Left'
         AND k2.description = 'Average Employees'";
$result3 = mysqli_query($con, $sql3);
if ($result3) {
    $turnoverData = [];
    while ($row = mysqli_fetch_assoc($result3)) {
        $year = $row['year'];
        $employeesLeft = (float)$row['employees_left'];
        $averageEmployees = (float)$row['average_employees'];
        if ($averageEmployees > 0) {
            $turnoverRate = ($employeesLeft / $averageEmployees) * 100;
            $turnoverData[$year] = isset($turnoverData[$year]) ? $turnoverData[$year] : 0;
            $turnoverData[$year] = $turnoverRate; // Overwrite or average if multiple entries
        }
    }
    // Sort and prepare for chart
    ksort($turnoverData);
    foreach ($turnoverData as $year => $value) {
        $yearLabels3[] = $year;
        $yearValues3[] = round($value, 2); // Round to 2 decimal places for percentage
    }
}

// Correct category mapping
$categoryNames = [
    30 => "No. of new products / services / process improvements"
];

// Capture filters
$selectedYear = isset($_GET['year']) ? $_GET['year'] : '';
$selectedCategory = isset($_GET['categoryId']) ? $_GET['categoryId'] : '';

// Prepare SQL query without the division filter to get all divisions
$sql = "SELECT categoryId, year, itemvalue, description, created_at, division_id
        FROM kpi_data 
        WHERE categoryId = 30";

if ($selectedYear !== '') {
    $sql .= " AND year = ?";
}
if ($selectedCategory !== '') {
    $sql .= " AND categoryId = ?";
}
$sql .= " ORDER BY year DESC, month DESC, created_at DESC";

$stmt = mysqli_prepare($con, $sql);
if ($stmt) {
    // Build parameter types and values
    $types = '';
    $params = [];

    if ($selectedYear !== '') {
        $types .= 'i';
        $params[] = (int)$selectedYear;
    }
    if ($selectedCategory !== '') {
        $types .= 'i';
        $params[] = (int)$selectedCategory;
    }

    // Bind parameters using references for PHP compatibility
    if (!empty($types)) {
        $bindParams = [$types];
        foreach ($params as $key => $value) {
            $bindParams[] = &$params[$key];
        }
        call_user_func_array([$stmt, 'bind_param'], $bindParams);
    }

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    die("Prepare failed: " . mysqli_error($con));
}
?>

<main class="content">
    <div class="container-fluid">
        <div class="header mb-3">
            <h1 class="header-title">KPI Charts by Year</h1>
        </div>

        <!-- Chart 1 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Employee Job Satisfaction (Category ID: 27)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart1" style="width: 90%; height: 280px;"></canvas>
            </div>
        </div>

        <!-- Chart 2 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Trainings Conducted (Local & Foreign) (Category ID: 28)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart2" style="width: 100%; height: 300px;"></canvas>
            </div>
        </div>

        <!-- Chart 3 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Employee Turnover (%) (Category ID: 29)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart3" style="width: 100%; height: 300px;"></canvas>
            </div>
        </div>

        <!-- KPI Table -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">No. of Products / Services / Process Improvements (Category ID: 30)</h5>
            </div>
            <div class="card-body">
                <!-- Year Filter Dropdown -->
                <div class="mb-3">
                    <form method="GET" action="">
                        <div class="row g-2 align-items-center">
                            <div class="col-auto">
                                <label for="yearFilter" class="form-label">Filter by Year:</label>
                            </div>
                            <div class="col-auto">
                                <select name="year" id="yearFilter" class="form-select" onchange="this.form.submit()">
                                    <option value="">All Years</option>
                                    <?php
                                    // Fetch distinct years for categoryId = 30
                                    $yearQuery = "SELECT DISTINCT year FROM kpi_data WHERE categoryId = 30 ORDER BY year DESC";
                                    $yearResult = mysqli_query($con, $yearQuery);
                                    if ($yearResult) {
                                        while ($yearRow = mysqli_fetch_assoc($yearResult)) {
                                            $year = $yearRow['year'];
                                            $selected = ($year == $selectedYear) ? 'selected' : '';
                                            echo "<option value='$year' $selected>$year</option>";
                                        }
                                        mysqli_free_result($yearResult);
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>Division ID</th>
                                <th>Category</th>
                                <th>Year</th>
                                <!-- <th>Month</th> -->
                                <th>Description</th>
                                <th>Value</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['division_id']); ?></td>
                                       <td><?php echo htmlspecialchars(isset($categoryNames[$row['categoryId']]) ? $categoryNames[$row['categoryId']] : 'Unknown'); ?></td>
                                        <td><?php echo htmlspecialchars($row['year']); ?></td>
                                       <td><?php echo htmlspecialchars(isset($row['description']) ? $row['description'] : '-'); ?></td>
                                        <td><?php echo htmlspecialchars($row['itemvalue']); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="7" class="text-center">No data available</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Chart 1 Data (Employee Job Satisfaction)
const yearLabels1 = <?php echo json_encode($yearLabels1); ?>;
const yearValues1 = <?php echo json_encode($yearValues1); ?>;

// Chart 2 Data (Trainings Conducted)
const yearLabels2 = <?php echo json_encode($yearLabels2); ?>;
const yearValues2 = <?php echo json_encode($yearValues2); ?>;

// Chart 3 Data (Employee Turnover)
const yearLabels3 = <?php echo json_encode($yearLabels3); ?>;
const yearValues3 = <?php echo json_encode($yearValues3); ?>;

// Chart 1: Employee Job Satisfaction
new Chart(document.getElementById('chart1').getContext('2d'), {
    type: 'bar',
    data: {
        labels: yearLabels1,
        datasets: [{
            label: 'Employee Job Satisfaction',
            data: yearValues1,
            backgroundColor: 'rgba(0, 0, 139, 0.7)',
            borderColor: 'rgba(0, 0, 139, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: { display: true, text: 'Employee Job Satisfaction per Year' },
            legend: { display: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Item Value (%)' }
            },
            x: {
                title: { display: true, text: 'Year' }
            }
        }
    }
});

// Chart 2: Trainings Conducted
new Chart(document.getElementById('chart2').getContext('2d'), {
    type: 'bar',
    data: {
        labels: yearLabels2,
        datasets: [{
            label: 'Trainings Conducted',
            data: yearValues2,
            backgroundColor: 'rgba(0, 0, 139, 0.7)',
            borderColor: 'rgba(0, 0, 139, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: { display: true, text: 'Trainings Conducted per Year' },
            legend: { display: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Item Value' }
            },
            x: {
                title: { display: true, text: 'Year' }
            }
        }
    }
});

// Chart 3: Employee Turnover
new Chart(document.getElementById('chart3').getContext('2d'), {
    type: 'bar',
    data: {
        labels: yearLabels3,
        datasets: [{
            label: 'Employee Turnover (%)',
            data: yearValues3,
            backgroundColor: 'rgba(0, 0, 139, 0.7)',
            borderColor: 'rgba(0, 0, 139, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: { display: true, text: 'Employee Turnover per Year' },
            legend: { display: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Turnover Rate ' },
                ticks: { callback: function(value) { return value ; } }
            },
            x: {
                title: { display: true, text: 'Year' }
            }
        }
    }
});
</script>

<?php 
mysqli_stmt_close($stmt);
mysqli_close($con);
include 'includes/footer.php'; 
?>