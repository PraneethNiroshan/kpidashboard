<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include 'includes/header.php';
include 'includes/leftnav.php';

// Database connection
$con = mysqli_connect("localhost", "root", "", "kpi-dashboard");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Correct category mapping
$categoryNames = [
    58 => 'cleanliness of the Airport rating',
   
];

// Capture filters
$selectedYear = $_GET['year'] ?? '';
$selectedCategory = $_GET['categoryId'] ?? '';

// Prepare SQL query
$sql = "SELECT categoryId, year, month, itemvalue, created_at
        FROM kpi_data 
        WHERE categoryId IN (58)"; // Add other relevant category IDs if needed

$params = [];
$types = "";

if ($selectedYear !== '') {
    $sql .= " AND year = ?";
    $params[] = (int)$selectedYear;
    $types .= "i";
}

if ($selectedCategory !== '') {
    $sql .= " AND categoryId = ?";
    $params[] = (int)$selectedCategory;
    $types .= "i";
}

$sql .= " ORDER BY year DESC, month DESC, created_at DESC";

$stmt = mysqli_prepare($con, $sql);
if (!$stmt) {
    die("Prepare failed: " . mysqli_error($con));
}

if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}

if (!mysqli_stmt_execute($stmt)) {
    die("Execute failed: " . mysqli_stmt_error($stmt));
}

$result = mysqli_stmt_get_result($stmt);
if (!$result) {
    die("Result failed: " . mysqli_error($con));
}
?>

<main class="content" style="padding-top: 80px;">
  <div class="container-fluid">
    <div class="header mb-3">
      <h1 class="header-title">Financial KPI View – cleanliness of the Airport rating</h1>
    </div>

    <!-- Filter Form -->
    <form method="GET" class="row g-3 mb-4">
      <div class="col-md-4">
        <label for="year" class="form-label">Year</label>
        <select name="year" id="year" class="form-select">
          <option value="">All Years</option>
          <?php
            $currentYear = date('Y');
            for ($y = $currentYear - 5; $y <= $currentYear + 1; $y++): ?>
              <option value="<?= $y ?>" <?= ($selectedYear == $y) ? 'selected' : '' ?>><?= $y ?></option>
          <?php endfor; ?>
        </select>
      </div>

      <div class="col-md-4">
        <label for="categoryId" class="form-label">Category</label>
        <select name="categoryId" id="categoryId" class="form-select">
          <option value="">All Categories</option>
          <?php foreach ($categoryNames as $id => $name): ?>
            <option value="<?= $id ?>" <?= ($selectedCategory == $id) ? 'selected' : '' ?>>
              <?= htmlspecialchars($name) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4 d-flex align-items-end">
        <button type="submit" class="btn btn-primary">Filter</button>
        <a href="financial_analytics_Aero.php" class="btn btn-secondary ms-2">Reset</a>
      </div>
    </form>

    <!-- KPI Table -->
    <div class="table-responsive">
      <table class="table table-bordered table-striped">
        <thead class="table-dark">
          <tr>
           
            <th>Category</th>
            <th>Year</th>
            <th>Month</th>
            <th>Value</th>
           
          </tr>
        </thead>
        <tbody>
          <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
              <tr>
                
                <td><?= htmlspecialchars($categoryNames[$row['categoryId']] ?? 'Unknown Category') ?></td>
                <td><?= htmlspecialchars($row['year']) ?></td>
                <td>
                  <?php 
                    $monthNum = (int)$row['month'];
                    echo ($monthNum > 0 && $monthNum <= 12) ? 
                         htmlspecialchars(date('F', mktime(0, 0, 0, $monthNum, 1))) : 
                         'N/A';
                  ?>
                </td>
                <td><?= htmlspecialchars(number_format($row['itemvalue'], 2)) ?></td>
                
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="6" class="text-center">No data available for the selected criteria</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<?php
mysqli_stmt_close($stmt);
mysqli_close($con);
include 'includes/footer.php';
?>
