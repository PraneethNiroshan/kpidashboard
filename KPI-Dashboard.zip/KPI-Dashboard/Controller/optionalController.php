<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once '../model/kpiModel.php';

class OptionalController {
    private $model;
    private $dbConnection;

    public function __construct($dbConnection) {
        $this->dbConnection = $dbConnection;
        $this->model = new KpiModel($dbConnection);
    }

    public function handleOptionalSubmission() {
        // Check if user is logged in and has a valid division
        if (!isset($_SESSION['DIVISION']) || !in_array($_SESSION['DIVISION'], ['ANS', 'AM'])) {
            echo "Unauthorized access";
            exit;
        }

        // Required fields (cargo_type is optional for PAX categories)
        $requiredFields = ['categoryId', 'year', 'month', 'frequencyId', 'itemvalue'];
        foreach ($requiredFields as $field) {
            if (!isset($_POST[$field])) {
                echo "Missing required field: $field";
                exit;
            }
        }

        // Sanitize inputs
        $categoryId = filter_var($_POST['categoryId'], FILTER_VALIDATE_INT);
        $year = filter_var($_POST['year'], FILTER_VALIDATE_INT);
        $month = filter_var($_POST['month'], FILTER_VALIDATE_INT);
        $frequencyId = filter_var($_POST['frequencyId'], FILTER_VALIDATE_INT);
        $itemvalue = filter_var($_POST['itemvalue'], FILTER_VALIDATE_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $airportId = isset($_POST['airportId']) ? filter_var($_POST['airportId'], FILTER_VALIDATE_INT) : 1;
        $travelType = isset($_POST['travel_type']) ? filter_var($_POST['travel_type'], FILTER_VALIDATE_INT) : 0;
        $cargo_type = isset($_POST['cargo_type']) ? filter_var($_POST['cargo_type'], FILTER_VALIDATE_INT) : null;
        
        // Handle optional description
        $description = isset($_POST['description']) && !empty(trim($_POST['description'])) 
            ? htmlspecialchars($_POST['description'], ENT_QUOTES, 'UTF-8')
            : null;

        // Validation
        $errors = [];
        if ($categoryId === false) $errors[] = "Invalid category ID";
        if ($year === false || $year < 2000 || $year > (int)date('Y') + 1) $errors[] = "Invalid year";
        if ($month === false || $month < 1 || $month > 12) $errors[] = "Invalid month";
        if ($frequencyId === false) $errors[] = "Invalid frequency ID";
        if ($itemvalue === false) $errors[] = "Invalid item value";
        if ($airportId === false) $airportId = 1;
        if ($travelType === false) $travelType = 0;
        if ($cargo_type === false) $cargo_type = null; // Allow null for PAX categories

        if (!empty($errors)) {
            echo implode(", ", $errors);
            exit;
        }

        // Map division name to division_id
        $divisionMap = ['ANS' => 12, 'AM' => 13]; // Adjust based on your database
        $divisionId = $divisionMap[$_SESSION['DIVISION']] ?? 0;

        // Check if data already exists for this year, month, and category
        $checkQuery = "SELECT * FROM kpi_data WHERE categoryId = ? AND year = ? AND month = ? AND airportId = ?";
        $stmt = $this->dbConnection->prepare($checkQuery);
        $stmt->bind_param("iiii", $categoryId, $year, $month, $airportId);
        $stmt->execute();
        $result = $stmt->get_result();

        // if ($result->num_rows > 0) {
        //     // Data already exists for this year, month, and category, return an error message
        //     echo " Data for this month already exists.";
        //     exit;
        // }

        // Proceed with saving data since it doesn't exist yet
        $quarter = 0; // Default for monthly data (adjust if quarterly)

        $result = $this->model->saveKpi(
            $categoryId,
            $year,
            $month,
            $quarter,
            $frequencyId,
            $itemvalue,
            $airportId,
            $travelType,
            $description, // Added description parameter
            $divisionId,
            null, // trainingType parameter (added to match model signature)
            $cargo_type // Using cargo_type
        );

        if ($result === true) {
            echo "Success";
        } else {
            echo "Error saving data: " . ($result ?: $this->dbConnection->error);
        }
    }
}

// DB connection
$dbConnection = new mysqli('localhost', 'root', '', 'kpi-dashboard');
if ($dbConnection->connect_error) {
    die("Database connection failed: " . $dbConnection->connect_error);
}

$controller = new OptionalController($dbConnection);
$controller->handleOptionalSubmission();
?>