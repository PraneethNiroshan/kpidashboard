<?php
include 'includes/header.php';
include 'includes/leftnav.php';
?>
<main class="content">
    <div class="container-fluid">
        <div class="header">
            <h1 class="header-title">Financial Perspective</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard-default.html">Main</a></li>
                    <li class="breadcrumb-item"><a href="#">BSC - Data Management</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Finance</li>
                </ol>
            </nav>
        </div>
        <div id="cardList"></div>
        <div class='row'>
            <div class='col-12'>
                <div class='card'> 
                    <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        <h1 class='card-title mb-0'>Aeronautical revenue</h1>                         
                    </div>
                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                        <div class='card-body'>
                            <div class="col-12">
                                <div class="tab tab-vertical tab-default">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item"><a class="nav-link active" href="#primary-tab-1" data-bs-toggle="tab" role="tab">Landing & Parking</a></li>
                                        <li class="nav-item"><a class="nav-link catId" href="#primary-tab-2" data-bs-toggle="tab" role="tab" id="32">Aerobridge</a></li>
                                        <li class="nav-item"><a class="nav-link catId" href="#primary-tab-3" data-bs-toggle="tab" role="tab" id="33">Overflying</a></li>
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="primary-tab-1" role="tabpanel">
                                            <div class='row'>
                                                <div class="col-12">
                                                    <div class="tab tab-primary">
                                                        <ul class="nav nav-tabs" role="tablist">
                                                            <li class="nav-item"><a class="nav-link active catId" href="#tab-1" data-bs-toggle="tab" role="tab" id="46">International</a></li>
                                                            <li class="nav-item"><a class="nav-link catId" href="#tab-2" data-bs-toggle="tab" role="tab" id="47">Domestic</a></li>
                                                        </ul>
                                                        <div class="tab-content">
                                                            <div class="tab-pane active" id="tab-1" role="tabpanel">
                                                                <div class="mb-3">
                                                                    <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                                        <input type="hidden" name="categoryId" value="46">
                                                                        <div class="col-12">
                                                                            <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect6" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                                                            
                                                                        </div>
                                                                         <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>
                                                                        <button type="submit" class="btn mt-3 btn-primary">Submit</button> 
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane" id="tab-2" role="tabpanel">                                                       
                                                                <div class="mb-3">
                                                                    <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                                        <input type="hidden" name="categoryId" value="47">
                                                                        <div class="col-12">
                                                                            <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                                            <div class="input-group date" id="datetimepicker-date2" data-target-input="nearest">
                                                                                <input type="text" class="form-control datetimepicker-input" id="areoDomDate" name="areoDomDate" data-target="#datetimepicker-date2" />
                                                                                <div class="input-group-text" data-target="#datetimepicker-date2" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-12">
                                                                            <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                                            <div class="input-group mb-2 me-sm-2">
                                                                                <div class="input-group-text">Value</div>
                                                                                <input type="text" class="form-control" id="areoDomValue" name="areoDomValue" placeholder="Value">
                                                                            </div>
                                                                        </div>
                                                                        <button type="submit" id="btnAreoDom" class="btn btn-default" name="areoDom">Submit</button> 
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="primary-tab-2" role="tabpanel">
                                            <h4 class="tab-title">Aerobridge</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="32">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date3" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="AerobridgetDate" name="AerobridgetDate" data-target="#datetimepicker-date3" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date3" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="AerobridgeValue" name="AerobridgeValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnAerobridge" class="btn btn-default" name="areobridgeId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="primary-tab-3" role="tabpanel">
                                            <h4 class="tab-title">Overflying</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="33">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date4" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="overflyIntDate" name="overflyIntDate" data-target="#datetimepicker-date4" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date4" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="overflyValue" name="overflyValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnAoverfly" class="btn btn-default" name="overflyId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <table id="datatables-reponsive" class="table table-striped" style="width:100%">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody id="tbAreoInt"></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='row'>
            <div class='col-12'>
                <div class='card'>                             
                    <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                        <h1 class='card-title mb-0'>Non-aeronautical revenue</h1>
                    </div>
                    <div id="collapseTwo" class="collapse show" aria-labelledby="collapseTwo" data-parent="#accordion">
                        <div class='card-body'>
                            <div class="col-12">
                                <div class="tab tab-vertical tab-primary">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item"><a class="nav-link active" href="#Embarkation-levy" data-bs-toggle="tab" role="tab">Embarkation levy</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#Concession" data-bs-toggle="tab" role="tab">Concession</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#Rental" data-bs-toggle="tab" role="tab">Rental</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#Entry-Permits" data-bs-toggle="tab" role="tab">Entry Permits</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#Fuel-Throughput-Charges" data-bs-toggle="tab" role="tab">Fuel Throughput Charges</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#FF-Ground-Handling" data-bs-toggle="tab" role="tab">Franchise Fee on Ground Handling - SLA</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#FF-SLCS" data-bs-toggle="tab" role="tab">Franchise Fee - SLCS</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#Entry-permits" data-bs-toggle="tab" role="tab">Entry permits</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#Parking-Fees" data-bs-toggle="tab" role="tab">Parking Fees - Vehicles</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#Domestic-Ground-Handling" data-bs-toggle="tab" role="tab">Domestic Ground Handling CIAR / BIA</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#other-non-areo" data-bs-toggle="tab" role="tab">Other Non-Aeronautical Income</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#lounges" data-bs-toggle="tab" role="tab">Lounges</a></li>
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="Embarkation-levy" role="tabpanel">
                                            <h4 class="tab-title">Embarkation levy</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="34">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date16" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="embarkLevyDate" name="embarkLevyDate" data-target="#datetimepicker-date16" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date16" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="embarkLevyValue" name="embarkLevyValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnembarkLevy" class="btn btn-default" name="embarkId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="Concession" role="tabpanel">
                                            <h4 class="tab-title">Concession</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="35">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date15" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="ConcessionDate" name="ConcessionDate" data-target="#datetimepicker-date15" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date15" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="ConcessionValue" name="ConcessionValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="ConcessionInt" class="btn btn-default" name="concessionId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="Rental" role="tabpanel">
                                            <h4 class="tab-title">Rental</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="36">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date14" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="rentalDate" name="rentalDate" data-target="#datetimepicker-date14" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date14" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="rentalValue" name="rentalValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnrental" class="btn btn-default" name="rentalId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="Entry-Permits" role="tabpanel">
                                            <h4 class="tab-title">Entry Permits</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="37">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date13" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="EntryPermitDate" name="EntryPermitDate" data-target="#datetimepicker-date13" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date13" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="EntryPermitValue" name="EntryPermitValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnEntryPermit" class="btn btn-default" name="entrypermitId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="Fuel-Throughput-Charges" role="tabpanel">
                                            <h4 class="tab-title">Fuel Throughput Charges</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="38">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date12" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="FuelChargeDate" name="FuelChargeDate" data-target="#datetimepicker-date12" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date12" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="FuelChargeValue" name="FuelChargeValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnFuelCharge" class="btn btn-default" name="fuelChargeId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="FF-Ground-Handling" role="tabpanel">
                                            <h4 class="tab-title">Franchise Fee on Ground Handling - SLA</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="39">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date11" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="FranGroundDate" name="FranGroundDate" data-target="#datetimepicker-date11" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date11" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="FranGroundValue" name="FranGroundValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnFranGround" class="btn btn-default" name="fragroundId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="FF-SLCS" role="tabpanel">
                                            <h4 class="tab-title">Franchise Fee - SLCS</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="40">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date10" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="FranSLCStDate" name="FranSLCStDate" data-target="#datetimepicker-date10" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date10" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="FranSLCSValue" name="FranSLCSValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnFranSLCS" class="btn btn-default" name="fraslcsId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="Entry-permits" role="tabpanel">
                                            <h4 class="tab-title">Entry permits PVG</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="41">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date9" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="entrypermitDatepvg" name="entrypermitDatepvg" data-target="#datetimepicker-date9" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date9" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="entrypermitValuepvg" name="entrypermitValuepvg" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnentrypermitpvg" class="btn btn-default" name="entrypermitIdpvg">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="Parking-Fees" role="tabpanel">
                                            <h4 class="tab-title">Parking Fees - Vehicles</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="42">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date8" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="parkingfeetDate" name="parkingfeetDate" data-target="#datetimepicker-date8" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date8" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="parkingfeeValue" name="parkingfeeValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnparkingfee" class="btn btn-default" name="parkingfeeId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="Domestic-Ground-Handling" role="tabpanel">
                                            <h4 class="tab-title">Domestic Ground Handling CIAR / BIA</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="43">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date7" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="domGroundHandletDate" name="domGroundHandletDate" data-target="#datetimepicker-date7" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date7" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="adomGroundHandleValue" name="adomGroundHandleValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btndomGroundHandle" class="btn btn-default" name="domGroundId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="other-non-areo" role="tabpanel">
                                            <h4 class="tab-title">Other Non-Aeronautical Income</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="44">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date6" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="othernonareoDate" name="othernonareoDate" data-target="#datetimepicker-date6" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date6" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="othernonareoValue" name="othernonareoValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnothernonareo" class="btn btn-default" name="othernonId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="lounges" role="tabpanel">
                                            <h4 class="tab-title">Lounges</h4>
                                            <div class="mb-3">
                                                <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                                    <input type="hidden" name="categoryId" value="45">
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                                        <div class="input-group date" id="datetimepicker-date5" data-target-input="nearest">
                                                            <input type="text" class="form-control datetimepicker-input" id="loungeDate" name="loungeDate" data-target="#datetimepicker-date5" />
                                                            <div class="input-group-text" data-target="#datetimepicker-date5" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                                        <div class="input-group mb-2 me-sm-2">
                                                            <div class="input-group-text">Value</div>
                                                            <input type="text" class="form-control" id="loungeValue" name="loungeValue" placeholder="Value">
                                                        </div>
                                                    </div>
                                                    <button type="submit" id="btnlounge" class="btn btn-default" name="loungeId">Submit</button> 
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='row'>
            <div class='col-12'>
                <div class='card'>
                    <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapseThree2" aria-expanded="true" aria-controls="collapseThree2">
                        <h1 class='card-title mb-0'>Revenue per passenger</h1>                               
                    </div>
                    <div class='card-body' id="collapseThree2" class="collapse">   
                        <div class="mb-3">
                            <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                <input type="hidden" name="categoryId" value="46">
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                    <div class="input-group date" id="datetimepicker-date17" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" id="revperpaxDate" name="revperpaxDate" data-target="#datetimepicker-date17" />
                                        <div class="input-group-text" data-target="#datetimepicker-date17" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                    <div class="input-group mb-2 me-sm-2">
                                        <div class="input-group-text">Value</div>
                                        <input type="text" class="form-control" id="revperpaxvalue" name="revperpaxvalue" placeholder="Value">
                                    </div>
                                </div>
                                <button type="submit" id="btnrevperpax" class="btn btn-default" name="revperpaxId">Submit</button> 
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='row'>
            <div class='col-12'>
                <div class='card'>
                    <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                        <h1 class='card-title mb-0'>Operating expenses per passenger</h1>
                    </div>                              
                    <div class='card-body' id="collapseFour" class="collapse">
                        <div class="mb-3">
                            <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                <input type="hidden" name="categoryId" value="47">
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                    <div class="input-group date" id="datetimepicker-date18" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" id="opperpaxDate" name="opperpaxDate" data-target="#datetimepicker-date18" />
                                        <div class="input-group-text" data-target="#datetimepicker-date18" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                    <div class="input-group mb-2 me-sm-2">
                                        <div class="input-group-text">Value</div>
                                        <input type="text" class="form-control" id="opperpaxValue" name="opperpaxValue" placeholder="Value">
                                    </div>
                                </div>
                                <button type="submit" id="btnopperpax" class="btn btn-default" name="opperpaxId">Submit</button> 
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='row'>
            <div class='col-12'>
                <div class='card'>
                    <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
                        <h1 class='card-title mb-0'>Return on assets (ROA)</h1>
                    </div>                             
                    <div class='card-body' id="collapseFive" class="collapse">
                        <div class="mb-3">
                            <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                <input type="hidden" name="categoryId" value="48">
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                    <div class="input-group date" id="datetimepicker-date19" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" id="roaDate" name="roaDate" data-target="#datetimepicker-date19" />
                                        <div class="input-group-text" data-target="#datetimepicker-date19" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                    <div class="input-group mb-2 me-sm-2">
                                        <div class="input-group-text">Value</div>
                                        <input type="text" class="form-control" id="roavalue" name="roavalue" placeholder="Value">
                                    </div>
                                </div>
                                <button type="submit" id="btnaoa" class="btn btn-default" name="roaId">Submit</button> 
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='row'>
            <div class='col-12'>
                <div class='card'>
                    <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
                        <h1 class='card-title mb-0'>Debt cover ratio</h1>
                    </div>                               
                    <div class='card-body' id="collapseSix" class="collapse">
                        <div class="mb-3">
                            <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                <input type="hidden" name="categoryId" value="49">
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                    <div class="input-group date" id="datetimepicker-date20" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" id="dcrDate" name="dcrDate" data-target="#datetimepicker-date20" />
                                        <div class="input-group-text" data-target="#datetimepicker-date20" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                    <div class="input-group mb-2 me-sm-2">
                                        <div class="input-group-text">Value</div>
                                        <input type="text" class="form-control" id="dcrvalue" name="dcrvalue" placeholder="Value">
                                    </div>
                                </div>
                                <button type="submit" id="btndcr" class="btn btn-default" name="dcrId">Submit</button> 
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='row'>
            <div class='col-12'>
                <div class='card'>
                    <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven">
                        <h1 class='card-title mb-0'>Net cash flow</h1>
                    </div>                               
                    <div class='card-body' id="collapseSeven" class="collapse">
                        <div class="mb-3">
                            <form class="row row-cols-md-auto align-items-center" action="" method="post">
                                <input type="hidden" name="categoryId" value="50">
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Month</label>
                                    <div class="input-group date" id="datetimepicker-date21" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" id="ncfDate" name="ncfDate" data-target="#datetimepicker-date21" />
                                        <div class="input-group-text" data-target="#datetimepicker-date21" data-toggle="datetimepicker"><i class="fa fa-calendar"></i></div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <label class="visually-hidden" for="inlineFormInputGroupUsername2">Value</label>
                                    <div class="input-group mb-2 me-sm-2">
                                        <div class="input-group-text">Value</div>
                                        <input type="text" class="form-control" id="ncfvalue" name="ncfvalue" placeholder="Value">
                                    </div>
                                </div>
                                <button type="submit" id="btnncf" class="btn btn-default" name="ncfId">Submit</button> 
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
include 'includes/footer.php';            
?>