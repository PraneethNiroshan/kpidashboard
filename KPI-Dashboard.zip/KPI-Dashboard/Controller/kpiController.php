<?php
session_start();
require_once '../model/kpiModel.php';

class kpiController {
    private $model;
    private $dbConnection; // Declare $dbConnection as a class property

    public function __construct($dbConnection) {
        // Assign the database connection to the class property
        $this->dbConnection = $dbConnection;
        $this->model = new KpiModel($dbConnection);
    }

    public function handleFormSubmission() {
        // Security check
        if (!isset($_SESSION['DIVISION']) || !in_array($_SESSION['DIVISION'], ['ANS', 'AM', 'Sec', 'EANE', 'SCM'])) {
            echo "Unauthorized access";
            exit;
        }

        // Required fields
        if (!isset($_POST['categoryId'], $_POST['year'], $_POST['frequencyId'], $_POST['itemvalue'], $_POST['month'])) {
            echo "Missing required fields";
            exit;
        }

        // Prepare data for validation
        $data = [
            'categoryId'  => $_POST['categoryId'],
            'year'        => $_POST['year'],
            'frequencyId' => $_POST['frequencyId'],
            'itemvalue'   => $_POST['itemvalue'],
            'description' => $_POST['description'] ?? null
        ];

        // Validate input
        $errors = $this->model->validateInput($data);
        if (!empty($errors)) {
            echo implode(", ", $errors);
            exit;
        }

        // Sanitize inputs
        $categoryId  = filter_var($data['categoryId'], FILTER_SANITIZE_NUMBER_INT);
        $year        = filter_var($data['year'], FILTER_SANITIZE_NUMBER_INT);
        $month       = filter_var($_POST['month'], FILTER_SANITIZE_NUMBER_INT);
        $frequencyId = filter_var($data['frequencyId'], FILTER_SANITIZE_NUMBER_INT);
        $itemvalue   = filter_var($data['itemvalue'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

        // Set description to null or 0 if empty
        $description = empty(trim((string)$data['description'])) ? null : filter_var($data['description'], FILTER_SANITIZE_STRING);

        $airportId   = intval($_POST['airportId'] ?? 1);
        $travelType  = isset($_POST['travel_type']) ? filter_var($_POST['travel_type'], FILTER_SANITIZE_NUMBER_INT) : 0;
        $quarter     = 0; // Default to 0 unless quarterly KPI

        // Division mapping
        $divisionMap = ['ANS' => 12, 'AM' => 13, 'Sec' => 14, 'EANE' => 15, 'SCM' => 16];
        $divisionId  = $divisionMap[$_SESSION['DIVISION']] ?? 0;

        // Category access check
        $allowedCategories = $this->getAllowedCategories($_SESSION['DIVISION']);
        if (!in_array($categoryId, $allowedCategories)) {
            echo "Unauthorized category access";
            exit;
        }

        // **Check if data already exists for this month and year**
        if ($this->isDataExists($categoryId, $year, $month, $airportId)) {
            echo " Data for this month already exists.";
            exit;
        }

        // Save KPI
        $result = $this->model->saveKpi($categoryId, $year, $month, $quarter, $frequencyId, $itemvalue, $airportId, $travelType, $description, $divisionId);

        echo $result === true ? "Success" : "Error saving data: " . ($result ?: 'Unknown error');
    }

    // Check if data already exists for the same year, month, and category
    private function isDataExists($categoryId, $year, $month, $airportId) {
        // Use the $dbConnection property to prepare and execute the query
        $checkQuery = "SELECT * FROM kpi_data WHERE categoryId = ? AND year = ? AND month = ? AND airportId = ?";
        $stmt = $this->dbConnection->prepare($checkQuery);
        $stmt->bind_param("iiii", $categoryId, $year, $month, $airportId);
        $stmt->execute();
        $result = $stmt->get_result();

        return $result->num_rows > 0; // Returns true if data exists, false otherwise
    }

    private function getAllowedCategories($division) {
        $categories = [
            'ANS' => [12, 14, 30],
            'AM'  => [13, 19, 30],
            'Sec' => [15, 16, 30],
            'EANE'=> [52,53,54],
            'SCM' => [20, 30]
        ];
        return $categories[$division] ?? [];
    }
}

// DB connection
$dbConnection = new mysqli('localhost', 'root', '', 'kpi-dashboard');
if ($dbConnection->connect_error) {
    die("Connection failed: " . $dbConnection->connect_error);
}

$controller = new kpiController($dbConnection);
$controller->handleFormSubmission();
?>
