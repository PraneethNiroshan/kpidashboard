<?php
session_start();
include '../model/financialModel.php';

class financialModel {
    private $conn;
    private $kpiModel;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        $this->kpiModel = new KpiModel($dbConnection); // Initialize KpiModel with the same connection
    }

    /**
     * Get financial list based on category ID
     */
    public function getFinancialList($id) {
        $rows = array();    
        // Add your SQL query to fetch financial data based on $id
        $sql = "SELECT * FROM kpi_data WHERE categoryId = ? ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $stmt->close();
        return $rows;
    }

    /**
     * Set aeronautical value (reused for various financial categories)
     */
    public function setAreonauticalValue($categoryId, $date, $value) {
        $rows = array();    
        // Parse date to extract year, month, and assume frequencyId = 6 (monthly based on your data)
        $dateObj = new DateTime($date);
        $year = $dateObj->format('Y');
        $month = $dateObj->format('m');
        $frequencyId = 6; // Assuming monthly frequency (adjust if needed)
        $airportId = 1; // Default airport ID, adjust as per your system
        $travelType = 0; // Default travel type, adjust if needed
        $description = null; // Optional description
        $divisionId = 0; // Default division ID, adjust if needed

        // Validate input data
        $data = [
            'categoryId' => $categoryId,
            'year' => $year,
            'month' => $month,
            'frequencyId' => $frequencyId,
            'itemvalue' => $value,
            'airportId' => $airportId,
            'travelType' => $travelType,
            'description' => $description,
            'divisionId' => $divisionId
        ];
        $errors = $this->kpiModel->validateInput($data);
        if (!empty($errors)) {
            return ['error' => implode(', ', $errors)];
        }

        // Save the data using KpiModel's saveKpi method
        $result = $this->kpiModel->saveKpi(
            $categoryId,
            $year,
            $month,
            0, // Quarter (0 for monthly)
            $frequencyId,
            $value,
            $airportId,
            $travelType,
            $description,
            $divisionId
        );

        if ($result === true) {
            $rows['success'] = true;
        } else {
            $rows['error'] = $result;
        }

        return $rows;
    }

    /**
     * Map financial categories to category IDs
     * This method provides a way to get categoryId based on financial category name
     */
    private function getCategoryId($categoryName) {
        $categoryMap = [
            'Landing & Parking - International' => 46,
            'Landing & Parking - Domestic' => 47,
            'Aerobridge' => 32,
            'Overflying' => 33,
            'Embarkation levy' => 34,
            'Concession' => 35,
            'Rental' => 36,
            'Entry Permits' => 37,
            'Fuel Throughput Charges' => 38,
            'Franchise Fee on Ground Handling - SLA' => 39,
            'Franchise Fee - SLCS' => 40,
            'Entry permits - PVG' => 41,
            'Parking Fees - Vehicles' => 42,
            'Domestic Ground Handling CIAR / BIA' => 43,
            'Other Non-Aeronautical Income' => 44,
            'Gross Profit from Lounges' => 45,
            'Revenue per passenger' => 46, // Adjust if different
        //     'Operating expenses per passenger' => 47, // Adjust if different
        //     'Return on assets (ROA)' => 48, // Adjust if different
        //     'Debt cover ratio' => 49, // Adjust if different
        //     'Net cash flow' => 50 // Adjust if different
        ];
        return $categoryMap[strtolower(trim($categoryName))] ?? null;
    }
}

// Example usage in your existing POST handling
if(isset($_POST['financialList'])) {
    $id = $_POST["financialList"];
    $rows = array();    
    $financialModelObj = new financialModel($conn); // $conn should be defined or passed
    $rows = $financialModelObj->getFinancialList($id);    
    echo json_encode($rows);   
}

if(isset($_POST['areoInt'])) {
    $categoryId = $_POST["areoInt"];
    $areoIntDate = $_POST["areoIntDate"];
    $areoIntValue = $_POST["areoIntValue"];
    $rows = array();    
    $financialModelObj = new financialModel($conn); // $conn should be defined or passed
    $rows = $financialModelObj->setAreonauticalValue($categoryId, $areoIntDate, $areoIntValue);    
    echo json_encode($rows);   
}

// Add similar blocks for other POST requests (areoDom, areobridgeId, etc.) using setAreonauticalValue
// Example for areoDom
if(isset($_POST['areoDom'])) {
    $categoryId = $_POST["areoDom"];
    $areoDomDate = $_POST["areoDomDate"];
    $areoDomValue = $_POST["areoDomValue"];
    $rows = array();    
    $financialModelObj = new financialModel($conn); // $conn should be defined or passed
    $rows = $financialModelObj->setAreonauticalValue($categoryId, $areoDomDate, $areoDomValue);    
    echo json_encode($rows);   
}

// Repeat for other categories (Aerobridge, Overflying, etc.) with their respective POST keys
?>