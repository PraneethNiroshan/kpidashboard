<?php
require_once '../database/db.php';

class customerModel
{
    // Category mapping array
    private $categoryMapping = [
        21 => 'Passenger satisfaction level',
        22 => 'Airline satisfaction level',
        23 => 'Number of passenger complaints',
        24 => 'Cleanliness of the Airport rating',
        25 => 'Average Passenger processing time (Min) - Arrival',
        26 => 'Average Passenger processing time (Min) - Departure'
    ];

    public function getAllCategories()
    {
        $dbObject = new db();
        $conn = $dbObject->getConnection();

        $sql = "SELECT categoryId, category FROM category ORDER BY categoryId ASC";
        $result = $conn->query($sql);

        if (!$result) {
            throw new Exception("Category query failed: " . $conn->error);
        }

        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function createCategoryIfNotExists($categoryId)
    {
        $dbObject = new db();
        $conn = $dbObject->getConnection();

        // Check if category exists
        $checkStmt = $conn->prepare("SELECT categoryId FROM category WHERE categoryId = ?");
        if (!$checkStmt) {
            throw new Exception("Prepare failed for category check: " . $conn->error);
        }
        
        $checkStmt->bind_param("i", $categoryId);
        $checkStmt->execute();
        $result = $checkStmt->get_result();
        
        if ($result->num_rows == 0) {
            // Category doesn't exist, create it
            if (!isset($this->categoryMapping[$categoryId])) {
                $checkStmt->close();
                throw new Exception("Unknown category ID: " . $categoryId);
            }
            
            $categoryName = $this->categoryMapping[$categoryId];
            $insertStmt = $conn->prepare("INSERT INTO category (categoryId, category) VALUES (?, ?)");
            if (!$insertStmt) {
                $checkStmt->close();
                throw new Exception("Prepare failed for category insert: " . $conn->error);
            }
            
            $insertStmt->bind_param("is", $categoryId, $categoryName);
            $success = $insertStmt->execute();
            
            if (!$success) {
                $error = $insertStmt->error;
                $insertStmt->close();
                $checkStmt->close();
                throw new Exception("Category insert failed: " . $error);
            }
            
            $insertStmt->close();
        }
        
        $checkStmt->close();
        return true;
    }

    public function insertKpiData($categoryId, $datetime, $itemvalue)
    {
        $dbObject = new db();
        $conn = $dbObject->getConnection();

        // Create category if it doesn't exist
        $this->createCategoryIfNotExists($categoryId);

        // Insert the KPI data
        $stmt = $conn->prepare("INSERT INTO kpi_data (categoryId, datetime, itemvalue) VALUES (?, ?, ?)");
        if (!$stmt) {
            throw new Exception("Prepare failed for insert: " . $conn->error);
        }

        $stmt->bind_param("isd", $categoryId, $datetime, $itemvalue);
        $success = $stmt->execute();

        if (!$success) {
            $error = $stmt->error;
            $stmt->close();
            throw new Exception("Insert failed: " . $error);
        }

        $stmt->close();
        return true;
    }

    public function getAllKpiWithCategory()
    {
        $dbObject = new db();
        $conn = $dbObject->getConnection();

        $sql = "
            SELECT 
                k.id AS record_id,
                k.categoryId,
                c.category AS category_name,
                k.datetime,
                k.itemvalue,
                k.created_at
            FROM 
                kpi_data k
            JOIN 
                category c ON k.categoryId = c.categoryId
            ORDER BY 
                k.datetime DESC
        ";

        $result = $conn->query($sql);

        if (!$result) {
            throw new Exception("Query failed: " . $conn->error);
        }

        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getKpiDataByCategory($categoryId)
    {
        $dbObject = new db();
        $conn = $dbObject->getConnection();

        $stmt = $conn->prepare("
            SELECT 
                k.id AS record_id,
                k.categoryId,
                c.category AS category_name,
                k.datetime,
                k.itemvalue,
                k.created_at
            FROM 
                kpi_data k
            JOIN 
                category c ON k.categoryId = c.categoryId
            WHERE k.categoryId = ?
            ORDER BY 
                k.datetime DESC
        ");

        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("i", $categoryId);
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result) {
            throw new Exception("Query execution failed: " . $stmt->error);
        }

        $data = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        return $data;
    }

    public function initializeAllCategories()
    {
        foreach ($this->categoryMapping as $categoryId => $categoryName) {
            $this->createCategoryIfNotExists($categoryId);
        }
        return true;
    }
}
?>