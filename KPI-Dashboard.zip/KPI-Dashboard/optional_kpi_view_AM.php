<?php
session_start();
include 'includes/header.php';
include 'includes/leftnav.php';

// Database connection
$con = mysqli_connect("localhost", "root", "", "kpi-dashboard");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$categoryNames = [
    48 => "Total PAX",
    49 => "Total A/C Handled",
    51 => "Cargo Handled",
];

$airportNames = [
    1 => 'BIA',
    2 => 'MRIA',
    3 => 'BDA',
    4 => 'JIA',
    5 => 'RMA'
];

$travelTypes = [
    1 => "International",
    2 => "Domestic",
    3 => "Transit/Transfer"
];

$cargoTypes = [
    1 => "Import",
    2 => "Export"
];

// Capture filters from GET
$selectedYear = $_GET['year'] ?? '';
$selectedCategory = $_GET['categoryId'] ?? '';
$selectedAirport = $_GET['airportId'] ?? '';

// Prepare SQL query with prepared statement
$sql = "
    SELECT categoryId, airportId, year, month, itemvalue, cargo_type, created_at, travel_type
    FROM kpi_data
    WHERE categoryId IN (48, 49, 51)  -- Updated to exclude 50
    AND division_id = ?"; // Restrict to AM division (division_id = 13)

if ($selectedYear !== '') {
    $sql .= " AND year = ?";
}
if ($selectedCategory !== '') {
    $sql .= " AND categoryId = ?";
}
if ($selectedAirport !== '') {
    $sql .= " AND airportId = ?";
}

$sql .= " ORDER BY year DESC, month DESC, created_at DESC";

$stmt = mysqli_prepare($con, $sql);
if ($stmt) {
    $bindParams = [];
    $types = 'i'; // Start with division_id as integer
    $params = [&$divisionId]; // division_id = 13 for AM
    $divisionId = 13; // Hardcoded based on your divisionMap ['AM' => 13]

    if ($selectedYear !== '') {
        $types .= 'i';
        $params[] = &$selectedYear;
    }
    if ($selectedCategory !== '') {
        $types .= 'i';
        $params[] = &$selectedCategory;
    }
    if ($selectedAirport !== '') {
        $types .= 'i';
        $params[] = &$selectedAirport;
    }

    // Bind parameters
    array_unshift($params, $types); // Add types as the first parameter
    call_user_func_array([$stmt, 'bind_param'], $params);

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    die("Prepare failed: " . mysqli_error($con));
}
?>

<main class="content" style="padding-top: 80px;">
  <div class="container-fluid">
    <div class="header mb-3">
      <h1 class="header-title">Optional KPI View – AM Division</h1>
    </div>

    <!-- Filter Form -->
    <form method="GET" class="row g-3 mb-4">
      <div class="col-md-3">
        <label for="year" class="form-label">Year</label>
        <select name="year" id="year" class="form-select">
          <option value="">All Years</option>
          <?php
            $currentYear = date('Y');
            for ($y = $currentYear - 5; $y <= $currentYear + 1; $y++): ?>
            <option value="<?= $y ?>" <?= ($selectedYear == $y) ? 'selected' : '' ?>><?= $y ?></option>
          <?php endfor; ?>
        </select>
      </div>

      <div class="col-md-3">
        <label for="categoryId" class="form-label">Category</label>
        <select name="categoryId" id="categoryId" class="form-select">
          <option value="">All Categories</option>
          <?php foreach ($categoryNames as $id => $name): ?>
            <option value="<?= $id ?>" <?= ($selectedCategory == $id) ? 'selected' : '' ?>><?= $name ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-3">
        <label for="airportId" class="form-label">Airport</label>
        <select name="airportId" id="airportId" class="form-select">
          <option value="">All Airports</option>
          <?php foreach ($airportNames as $id => $name): ?>
            <option value="<?= $id ?>" <?= ($selectedAirport == $id) ? 'selected' : '' ?>><?= $name ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-3 d-flex align-items-end">
        <button type="submit" class="btn btn-primary">Filter</button>
        <a href="optional_kpi_view_AM.php" class="btn btn-secondary ms-2">Reset</a>
      </div>
    </form>

    <!-- Data Table -->
    <div class="table-responsive">
      <table class="table table-bordered table-striped">
        <thead class="table-dark">
          <tr>
            <th>ID</th>
            <th>Category</th>
            <th>Year</th>
            <th>Month</th>
            <th>Airport</th>
            <th>Travel Type</th>
            <th>Cargo Type</th>
            
            <th>Value</th>
            <th>Submitted At</th>
          </tr>
        </thead>
        <tbody>
          <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
              <tr>
                <td><?= htmlspecialchars($row['categoryId']) ?></td>
                <td><?= htmlspecialchars($categoryNames[$row['categoryId']] ?? 'Unknown') ?></td>
                <td><?= htmlspecialchars($row['year']) ?></td>
                <td><?= ($row['month'] > 0 && $row['month'] <= 12) ? date('F', mktime(0, 0, 0, $row['month'], 1)) : 'N/A' ?></td>
                <td><?= htmlspecialchars($airportNames[$row['airportId']] ?? 'Unknown') ?></td>
                <td><?= htmlspecialchars($travelTypes[$row['travel_type']] ?? '-') ?></td>
                <td><?= htmlspecialchars($cargoTypes[$row['cargo_type']] ?? '-') ?></td>
                <td>
                  <?php if ($row['categoryId'] == 51): // Only for Cargo Handled (categoryId = 51) ?>
                    <?= htmlspecialchars($row['itemvalue']) . ' MT' ?>
                  <?php else: ?>
                    <?= htmlspecialchars($row['itemvalue'] ?? 'N/A') ?>
                  <?php endif; ?>
                </td>

              
                
                <td><?= htmlspecialchars($row['created_at']) ?></td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="10" class="text-center">No data available</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<?php
mysqli_stmt_close($stmt);
mysqli_close($con);
include 'includes/footer.php';
?>