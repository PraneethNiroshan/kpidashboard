<?php
session_start();
include '../model/financialModel.php';
if(isset($_POST['financialList'])) {
    $id = $_POST["financialList"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->getFinancialList($id);    

    echo json_encode($rows);   
}

if(isset($_POST['areoInt'])) {
    $categoryId= $_POST["areoInt"];
    $areoIntDate = $_POST["areoIntDate"];
    $areoIntValue= $_POST["areoIntValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['areoDom'])) {
    $categoryId= $_POST["areoDom"];
    $areoIntDate = $_POST["areoDomDate"];
    $areoIntValue= $_POST["areoDomValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}


if(isset($_POST['areobridgeId'])) {
    $categoryId= $_POST["areobridgeId"];
    $areoIntDate = $_POST["AerobridgetDate"];
    $areoIntValue= $_POST["AerobridgeValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['domGroundId'])) {
    $categoryId= $_POST["domGroundId"];
    $areoIntDate = $_POST["domGroundHandletDate"];
    $areoIntValue= $_POST["adomGroundHandleValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['othernonId'])) {
    $categoryId= $_POST["othernonId"];
    $areoIntDate = $_POST["othernonareoDate"];
    $areoIntValue= $_POST["othernonareoValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['loungeId'])) {
    $categoryId= $_POST["loungeId"];
    $areoIntDate = $_POST["loungeDate"];
    $areoIntValue= $_POST["loungeValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}


if(isset($_POST['parkingfeeId'])) {
    $categoryId= $_POST["parkingfeeId"];
    $areoIntDate = $_POST["parkingfeetDate"];
    $areoIntValue= $_POST["parkingfeeValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['entrypermitId'])) {
    $categoryId= $_POST["entrypermitId"];
    $areoIntDate = $_POST["entrypermitDate"];
    $areoIntValue= $_POST["entrypermitValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['fraslcsId'])) {
    $categoryId= $_POST["fraslcsId"];
    $areoIntDate = $_POST["FranSLCStDate"];
    $areoIntValue= $_POST["FranSLCSValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['fragroundId'])) {
    $categoryId= $_POST["fragroundId"];
    $areoIntDate = $_POST["FranGroundDate"];
    $areoIntValue= $_POST["FranGroundValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}


if(isset($_POST['fuelChargeId'])) {
    $categoryId= $_POST["fuelChargeId"];
    $areoIntDate = $_POST["FuelChargeDate"];
    $areoIntValue= $_POST["FuelChargeValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['entrypermitIdpvg'])) {
    $categoryId= $_POST["entrypermitIdpvg"];
    $areoIntDate = $_POST["EntryPermitDatepvg"];
    $areoIntValue= $_POST["EntryPermitValuepvg"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['rentalId'])) {
    $categoryId= $_POST["rentalId"];
    $areoIntDate = $_POST["rentalDate"];
    $areoIntValue= $_POST["rentalValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['concessionId'])) {
    $categoryId= $_POST["concessionId"];
    $areoIntDate = $_POST["ConcessionDate"];
    $areoIntValue= $_POST["ConcessionValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}


if(isset($_POST['embarkId'])) {
    $categoryId= $_POST["embarkId"];
    $areoIntDate = $_POST["embarkLevyDate"];
    $areoIntValue= $_POST["embarkLevyValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['revperpaxId'])) {
    $categoryId= $_POST["revperpaxId"];
    $areoIntDate = $_POST["revperpaxDate"];
    $areoIntValue= $_POST["revperpaxvalue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['opperpaxId'])) {
    $categoryId= $_POST["opperpaxId"];
    $areoIntDate = $_POST["opperpaxDate"];
    $areoIntValue= $_POST["opperpaxValue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['roaId'])) {
    $categoryId= $_POST["roaId"];
    $areoIntDate = $_POST["roaDate"];
    $areoIntValue= $_POST["roavalue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

if(isset($_POST['dcrId'])) {
    $categoryId= $_POST["dcrId"];
    $areoIntDate = $_POST["dcrDate"];
    $areoIntValue= $_POST["dcrvalue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}


if(isset($_POST['ncfId'])) {
    $categoryId= $_POST["ncfId"];
    $areoIntDate = $_POST["ncfDate"];
    $areoIntValue= $_POST["ncfvalue"];
    $rows = array();    
    $financialModelObj = new financialModel();  
    $rows = $financialModelObj->setAreonauticalValue($categoryId,$areoIntDate,$areoIntValue);    

    echo json_encode($rows);   
}

?>