<?php
include 'includes/header.php';
include 'includes/leftnav.php';

$con = mysqli_connect("localhost", "root", "", "b'kpi'");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get available years from DB
$years = [];
$yearResult = mysqli_query($con, "SELECT DISTINCT year FROM kpi_data ORDER BY year DESC");
while ($row = mysqli_fetch_assoc($yearResult)) {
    $years[] = $row['year'];
}

// Selected year from GET or default to current year
$selectedYear = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Quarter labels for X-axis (or Y-axis for Chart 4)
$quarters = ['Q1(Jan-Mar)', 'Q2(Apr-Jun)', 'Q3(Jul-Sep)', 'Q4(Oct-Dec)'];

// Initialize arrays to hold totals for each quarter
// Chart 1: categoryId = 21 (Aircraft Incidents)
$quarterData1 = array_fill(0, 4, 0);
$sql1 = "SELECT quarter, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 21 AND year = ? GROUP BY quarter ORDER BY quarter";
$stmt1 = mysqli_prepare($con, $sql1);
if ($stmt1) {
    mysqli_stmt_bind_param($stmt1, "i", $selectedYear);
    mysqli_stmt_execute($stmt1);
    $result1 = mysqli_stmt_get_result($stmt1);
    while ($row = mysqli_fetch_assoc($result1)) {
        $quarterIndex = (int)$row['quarter'] - 1;
        if ($quarterIndex >= 0 && $quarterIndex < 4) {
            $quarterData1[$quarterIndex] = (int)$row['total'];
        }
    }
    mysqli_stmt_close($stmt1);
}

// Chart 2: categoryId = 22 (Airline Satisfaction Level)
$quarterData2 = array_fill(0, 4, 0);
$sql2 = "SELECT quarter, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 22 AND year = ? GROUP BY quarter ORDER BY quarter";
$stmt2 = mysqli_prepare($con, $sql2);
if ($stmt2) {
    mysqli_stmt_bind_param($stmt2, "i", $selectedYear);
    mysqli_stmt_execute($stmt2);
    $result2 = mysqli_stmt_get_result($stmt2);
    while ($row = mysqli_fetch_assoc($result2)) {
        $quarterIndex = (int)$row['quarter'] - 1;
        if ($quarterIndex >= 0 && $quarterIndex < 4) {
            $quarterData2[$quarterIndex] = (int)$row['total'];
        }
    }
    mysqli_stmt_close($stmt2);
}

// Chart 3: categoryId = 23 (Number of Passenger Complaints)
$quarterData3 = array_fill(0, 4, 0);
$sql3 = "SELECT quarter, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 23 AND year = ? GROUP BY quarter ORDER BY quarter";
$stmt3 = mysqli_prepare($con, $sql3);
if ($stmt3) {
    mysqli_stmt_bind_param($stmt3, "i", $selectedYear);
    mysqli_stmt_execute($stmt3);
    $result3 = mysqli_stmt_get_result($stmt3);
    while ($row = mysqli_fetch_assoc($result3)) {
        $quarterIndex = (int)$row['quarter'] - 1;
        if ($quarterIndex >= 0 && $quarterIndex < 4) {
            $quarterData3[$quarterIndex] = (int)$row['total'];
        }
    }
    mysqli_stmt_close($stmt3);
}

// Chart 4: categoryId = 24 (Cleanliness of the Airport Rating)
$quarterData4 = array_fill(0, 4, 0);
$sql4 = "SELECT quarter, SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = 24 AND year = ? GROUP BY quarter ORDER BY quarter";
$stmt4 = mysqli_prepare($con, $sql4);
if ($stmt4) {
    mysqli_stmt_bind_param($stmt4, "i", $selectedYear);
    mysqli_stmt_execute($stmt4);
    $result4 = mysqli_stmt_get_result($stmt4);
    while ($row = mysqli_fetch_assoc($result4)) {
        $quarterIndex = (int)$row['quarter'] - 1;
        if ($quarterIndex >= 0 && $quarterIndex < 4) {
            $quarterData4[$quarterIndex] = (int)$row['total'];
        }
    }
    mysqli_stmt_close($stmt4);
}

// Chart 5: categoryId = 25 (Average Passenger Processing Time - Arrival)
$quarterData5 = array_fill(0, 4, 0);
$sql5 = "SELECT quarter, AVG(itemvalue) AS average_time FROM kpi_data WHERE categoryId = 25 AND year = ? GROUP BY quarter ORDER BY quarter";
$stmt5 = mysqli_prepare($con, $sql5);
if ($stmt5) {
    mysqli_stmt_bind_param($stmt5, "i", $selectedYear);
    mysqli_stmt_execute($stmt5);
    $result5 = mysqli_stmt_get_result($stmt5);
    while ($row = mysqli_fetch_assoc($result5)) {
        $quarterIndex = (int)$row['quarter'] - 1;
        if ($quarterIndex >= 0 && $quarterIndex < 4) {
            $quarterData5[$quarterIndex] = round((float)$row['average_time'], 2); // Round to 2 decimal places
        }
    }
    mysqli_stmt_close($stmt5);
}

// Chart 6: categoryId = 26 (Average Passenger Processing Time - Departure)
$quarterData6 = array_fill(0, 4, 0);
$sql6 = "SELECT quarter, AVG(itemvalue) AS average_time FROM kpi_data WHERE categoryId = 26 AND year = ? GROUP BY quarter ORDER BY quarter";
$stmt6 = mysqli_prepare($con, $sql6);
if ($stmt6) {
    mysqli_stmt_bind_param($stmt6, "i", $selectedYear);
    mysqli_stmt_execute($stmt6);
    $result6 = mysqli_stmt_get_result($stmt6);
    while ($row = mysqli_fetch_assoc($result6)) {
        $quarterIndex = (int)$row['quarter'] - 1;
        if ($quarterIndex >= 0 && $quarterIndex < 4) {
            $quarterData6[$quarterIndex] = round((float)$row['average_time'], 2); // Round to 2 decimal places
        }
    }
    mysqli_stmt_close($stmt6);
}
?>

<main class="content">
    <div class="container-fluid">
        <div class="header mb-3">
            <h1 class="header-title">Quarterly KPI Charts (<?= $selectedYear ?>)</h1>
            <form method="GET" class="d-inline-block mt-2">
                <label for="year" style="color: white;">Select Year:</label>
                <select name="year" id="year" class="form-select form-select-sm w-auto d-inline-block" onchange="this.form.submit()">
                    <?php foreach ($years as $year): ?>
                        <option value="<?= $year ?>" <?= $year == $selectedYear ? 'selected' : '' ?>><?= $year ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <!-- Chart 1 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Passenger satisfaction level(Category ID: 21)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart1" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 2 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Airline Satisfaction Level (Category ID: 22)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart2" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 3 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Number of Passenger Complaints (Category ID: 23)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart3" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 4 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Cleanliness of the Airport Rating (Category ID: 24)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart4" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Combined Chart -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Average Passenger Processing Time (Min)</h5>
            </div>
            <div class="card-body">
                <canvas id="chart5and6" style="width:100%; height:400px;"></canvas>
            </div>
        </div>
    </div>
</main>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const quarters = <?php echo json_encode($quarters); ?>;
const data1 = <?php echo json_encode($quarterData1); ?>;
const data2 = <?php echo json_encode($quarterData2); ?>;
const data3 = <?php echo json_encode($quarterData3); ?>;
const data4 = <?php echo json_encode($quarterData4); ?>;
const data5 = <?php echo json_encode($quarterData5); ?>;
const data6 = <?php echo json_encode($quarterData6); ?>;

// Chart 1: Bar chart for quarterly data
new Chart(document.getElementById('chart1').getContext('2d'), {
    type: 'bar',
    data: {
        labels: quarters,
        datasets: [{
            label: 'Passenger satisfaction level',
            data: data1,
            backgroundColor: 'rgba(0, 0, 139, 0.7)',
            borderColor: 'rgba(0, 0, 139, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: ''
            },
            legend: {
                display: true,
                position: 'bottom'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Item Value'
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Quarter'
                }
            }
        }
    }
});

// Chart 2: Bar chart for quarterly data
new Chart(document.getElementById('chart2').getContext('2d'), {
    type: 'bar',
    data: {
        labels: quarters,
        datasets: [{
            label: 'Airline Satisfaction Level',
            data: data2,
            backgroundColor: 'rgba(0, 0, 139, 0.7)',
            borderColor: 'rgba(0, 0, 139, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: ''
            },
            legend: {
                display: true,
                position: 'bottom'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Item Value'
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Quarter'
                }
            }
        }
    }
});

// Chart 3: Bar chart for quarterly data
new Chart(document.getElementById('chart3').getContext('2d'), {
    type: 'bar',
    data: {
        labels: quarters,
        datasets: [{
            label: 'Number of Passenger Complaints',
            data: data3,
            backgroundColor: 'rgba(0, 0, 139, 0.7)',
            borderColor: 'rgba(0, 0, 139, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: ''
            },
            legend: {
                display: true,
                position: 'bottom'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Item Value'
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Quarter'
                }
            }
        }
    }
});

// Chart 4: Horizontal bar chart for Cleanliness of the Airport Rating
new Chart(document.getElementById('chart4').getContext('2d'), {
    type: 'bar',
    data: {
        labels: quarters, // Y-axis: Quarters
        datasets: [{
            label: 'Cleanliness of the Airport Rating',
            data: data4, // X-axis: Ratings (itemvalue, 1-10)
            backgroundColor: 'rgba(0, 0, 139, 0.7)',
            borderColor: 'rgba(0, 0, 139, 0.7)',
            borderWidth: 2
        }]
    },
    options: {
        indexAxis: 'y', // Makes the bar chart horizontal
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: 'Cleanliness of the Airport Rating'
            },
            legend: {
                display: true,
                position: 'bottom'
            }
        },
        scales: {
            x: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Rating (1-10)'
                },
                max: 10 // Assuming ratings are 1-10
            },
            y: {
                title: {
                    display: true,
                    text: 'Quarter'
                }
            }
        }
    }
});

// Chart 5 and 6: Line chart with markers for Average Passenger Processing Time - UPDATED WITH REAL DATA
new Chart(document.getElementById('chart5and6').getContext('2d'), {
    type: 'line',
    data: {
        labels: quarters, // X-axis: Using quarter labels from PHP
        datasets: [
            {
                label: 'Arrival Processing Time',
                data: data5, // Using real data from database (categoryId 25)
                borderColor: '#daff35ff',
                backgroundColor: '#daff35ff',
                tension: 0.2, // slight curve for smooth lines
                fill: false,
                pointRadius: 8,
                pointHoverRadius: 10,
                pointBackgroundColor: '#daff35ff',
                pointBorderColor: '#FFFFFF',
                pointBorderWidth: 3,
                borderWidth: 4
            },
            {
                label: 'Departure Processing Time',
                data: data6, // Using real data from database (categoryId 26)
                borderColor: '#1b30e4ff',
                backgroundColor: '#1b30e4ff',
                tension: 0.2,
                fill: false,
                pointRadius: 8,
                pointHoverRadius: 10,
                pointBackgroundColor: '#1b30e4ff',
                pointBorderColor: '#FFFFFF',
                pointBorderWidth: 3,
                borderWidth: 4
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { 
                position: 'bottom',
                labels: {
                    usePointStyle: true,
                    padding: 20,
                    font: {
                        size: 14
                    }
                }
            },
            title: {
                display: true,
                text: 'Average Passenger Processing Time (Minutes) - <?= $selectedYear ?>',
                font: {
                    size: 18,
                    weight: 'bold'
                },
                padding: 20
            },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: 'rgba(0,0,0,0.8)',
                titleColor: '#FFFFFF',
                bodyColor: '#FFFFFF',
                borderColor: '#FFFFFF',
                borderWidth: 1,
                callbacks: {
                    label: function(context) {
                        return context.dataset.label + ': ' + context.parsed.y + ' minutes';
                    },
                    title: function(context) {
                        return quarters[context[0].dataIndex] + ' - <?= $selectedYear ?>';
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Processing Time (Minutes)',
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                },
                grid: {
                    color: 'rgba(0,0,0,0.1)',
                    borderDash: [5, 5]
                },
                ticks: {
                    stepSize: 5,
                    font: {
                        size: 12
                    }
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Quarter',
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                },
                grid: {
                    color: 'rgba(0,0,0,0.1)',
                    borderDash: [5, 5]
                },
                ticks: {
                    font: {
                        size: 12
                    }
                }
            }
        },
        interaction: {
            mode: 'nearest',
            axis: 'x',
            intersect: false
        },
        hover: {
            mode: 'nearest',
            intersect: false
        },
        elements: {
            point: {
                hoverBackgroundColor: '#FFFFFF',
                hoverBorderWidth: 4
            }
        }
    }
});

// Optional: Add cursor pointer on hover for processing time chart
document.getElementById('chart5and6').addEventListener('mousemove', function(e) {
    const chart = Chart.getChart('chart5and6');
    const points = chart.getElementsAtEventForMode(e, 'nearest', { intersect: true }, true);
    
    if (points.length) {
        e.target.style.cursor = 'pointer';
    } else {
        e.target.style.cursor = 'default';
    }
});
</script>

<?php include 'includes/footer.php'; ?>