<?php
class optionalModel {
    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    /**
     * Save KPI data to the database
     */
    public function saveKpi($categoryId, $year, $month, $frequencyId, $itemvalue, $airportId, $travelType) {
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO kpi_data (categoryId, year, month, frequencyId, itemvalue, airportId, travel_type, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->bind_param("iiiidii", $categoryId, $year, $month, $frequencyId, $itemvalue, $airportId, $travelType);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log("Error saving KPI data: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Validate KPI input data
     */
    public function validateInput($data) {
        $errors = [];

        // Define category groups
        $allCategories = [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 30];
        $quarterlyCategories = [19, 20, 23, 25];
        $monthlyCategories = [12, 13, 14, 15, 16, 17, 18, 21, 22, 24, 30]; // added 30
        $percentageCategories = [15, 17, 19, 20, 21, 23, 25];

        // Validate categoryId
        if (empty($data['categoryId']) || !is_numeric($data['categoryId']) || !in_array($data['categoryId'], $allCategories)) {
            $errors[] = "Invalid category ID";
        }

        // Validate year
        $currentYear = date('Y');
        if (empty($data['year']) || !is_numeric($data['year']) || 
            $data['year'] < ($currentYear - 5) || $data['year'] > ($currentYear + 2)) {
            $errors[] = "Invalid year";
        }

        // Validate frequencyId
        if (empty($data['frequencyId']) || !is_numeric($data['frequencyId'])) {
            $errors[] = "Invalid frequency ID";
        }

        // Validate frequency based on category type
        if (in_array($data['categoryId'], $quarterlyCategories)) {
            if ($data['frequencyId'] < 1 || $data['frequencyId'] > 4) {
                $errors[] = "Invalid quarter";
            }
        }

        if (in_array($data['categoryId'], $monthlyCategories)) {
            if ($data['frequencyId'] < 1 || $data['frequencyId'] > 12) {
                $errors[] = "Invalid month";
            }
        }

        // Validate item value
        if (!isset($data['itemvalue']) || !is_numeric($data['itemvalue'])) {
            $errors[] = "Invalid value";
        } else {
            if (in_array($data['categoryId'], $percentageCategories)) {
                if ($data['itemvalue'] < 0 || $data['itemvalue'] > 100) {
                    $errors[] = "Value must be between 0 and 100 for percentage-based KPIs";
                }
            } else {
                if ($data['itemvalue'] < 0) {
                    $errors[] = "Value must be a positive number";
                }
            }
        }

        return $errors;
    }
}
