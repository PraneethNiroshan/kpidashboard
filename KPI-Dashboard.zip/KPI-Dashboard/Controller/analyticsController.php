<?php
require_once '../Model/analyticsModel.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';
    $year = intval($_POST['year'] ?? date('Y'));
    $month = intval($_POST['month'] ?? date('m'));

    $model = new analyticsModel();
    $data = $model->getTopAnalytics($type, $year, $month);

    echo json_encode($data);
    exit;
}

if ($action === 'total_revenue') {
    $year = intval($_POST['year'] ?? date('Y'));
    $month = intval($_POST['month'] ?? date('m'));

    $totalRevenue = $model->getTotalRevenueByParentCategory(1, $year, $month);

    header('Content-Type: application/json');
    echo json_encode(['totalRevenue' => $totalRevenue]);
    exit;
}

// If not POST, return a JSON error message
echo json_encode(['error' => 'Invalid request method']);
exit;
