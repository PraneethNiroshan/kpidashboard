<?php
session_start();
include 'includes/header.php';
include 'includes/leftnav.php';
?>

<div id="toast-success" style="
    position: fixed;
    top: 60px;
    right: 20px;
    z-index: 9999;
    background-color: #28a745;
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    display: none;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
">
    Data saved successfully!
</div>

<main class="content">
    <div class="container-fluid">
        <div class="header">
            <h1 class="header-title">Optional KPI Submission</h1>

            <?php
            $division = isset($_SESSION['DIVISION']) ? $_SESSION['DIVISION'] : '';
            ?>

            <?php if ($division === 'ANS'): ?>
                <div class="mb-4 text-end">
                    <a href="optional_kpi_view_ANS.php" class="btn btn-outline-primary">View Details</a>
                </div>
            <?php endif; ?>

            <?php if ($division === 'AM'): ?>
                <div class="mb-4 text-end">
                    <a href="optional_kpi_view_AM.php" class="btn btn-outline-primary">View Details</a>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($_SESSION['DIVISION'] === 'AM'): ?>
            <!-- Total PAX -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse15" aria-expanded="true" aria-controls="collapse15">
                            <h1 class='card-title mb-0'>Total PAX</h1>
                        </div>                              
                        <div class='card-body collapse' id="collapse15">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/optionalController.php">
                                    <input type="hidden" name="categoryId" value="48">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect1" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect1" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label for="airportId">Select Airport</label>
                                        <select class="form-control" name="airportId" id="airportId" required>
                                            <option value="1">BIA</option>
                                            <option value="2">MRIA</option>
                                            <option value="3">BDA/BTIA</option>
                                            <option value="4">JIA</option>
                                            <option value="5">RMA/CIAR</option>
                                            
                                        </select>

                                    </div>

                                    <div class="col-12">
                                        <label>Type</label>
                                        <select class="form-control" name="travel_type" required>
                                            <option value="1">International</option>
                                            <option value="2">Domestic</option>
                                            <option value="3">Transit/Tranfer</option>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Total A/C handled -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse16" aria-expanded="true" aria-controls="collapse16">
                            <h1 class='card-title mb-0'>Total A/C handled</h1>
                        </div>                              
                        <div class='card-body collapse' id="collapse16">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/optionalController.php">
                                    <input type="hidden" name="categoryId" value="49">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect2" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect2" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label for="airportId">Select Airport</label>
                                        <select class="form-control" name="airportId" id="airportId" required>
                                           <option value="1">BIA</option>
                                            <option value="2">MRIA</option>
                                            <option value="3">BDA/BTIA</option>
                                            <option value="4">JIA</option>
                                            <option value="5">RMA/CIAR</option>
                                        </select>

                                    </div>

                                    <div class="col-12">
                                        <label>Type</label>
                                        <select class="form-control" name="travel_type" required>
                                            <option value="1">International</option>
                                            <option value="2">Domestic</option>
                                            <option value="3">Transit/Tranfer</option>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cargo handled -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse17" aria-expanded="true" aria-controls="collapse17">
                            <h1 class='card-title mb-0'>Cargo handled</h1>
                        </div>                              
                        <div class='card-body collapse' id="collapse17">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/optionalController.php">
                                    <input type="hidden" name="categoryId" value="51">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->

                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect3" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect3" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Airport</label>
                                        <select class="form-control" name="airportId" required>
                                           <option value="1">BIA</option>
                                            <option value="2">MRIA</option>
                                            <option value="3">BDA/BTIA</option>
                                            <option value="4">JIA</option>
                                            <option value="5">RMA/CIAR</option>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Type</label>
                                        <select class="form-control" name="cargo_type" required>
                                            <option value="1">Import</option>
                                            <option value="2">Export</option>
                                            
                                        </select>
                                    </div>

                                    <div class="col-12">
                            <label>Value (in Metric Tons)</label> <!-- Updated label -->
                            <div class="input-group mb-2 me-sm-2">
                                <div class="input-group-text">Value (MT)</div>
                                <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Enter value in Metric Tons" required min="0">
                            </div>
                        </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($_SESSION['DIVISION'] === 'ANS'): ?>
            <!-- Overflight -->
            <div class='row'>
                <div class='col-12'>
                    <div class='card'>
                        <div class='card-header' data-bs-toggle="collapse" data-bs-target="#collapse18" aria-expanded="true" aria-controls="collapse18">
                            <h1 class='card-title mb-0'>Overflight</h1>
                        </div>                              
                        <div class='card-body collapse' id="collapse18">
                            <div class="mb-3">
                                <form class="row row-cols-md-auto align-items-center kpi-form" method="POST" action="Controller/optionalController.php">
                                    <input type="hidden" name="categoryId" value="50">
                                    <input type="hidden" name="frequencyId" value="1"><!-- Always Monthly for now -->
                                    <input type="hidden" name="airportId" value="1">
                                    <input type="hidden" name="travel_type" value="0">

                                    <!-- Year Selection -->
                                    <div class="col-12">
                                        <label>Year</label>
                                        <select class="form-control" name="year" id="yearSelect4" required>
                                            <?php 
                                            $currentYear = date('Y');
                                            for ($i = $currentYear - 5; $i <= $currentYear + 2; $i++): ?>
                                                <option value="<?= $i ?>" <?= ($i == $currentYear) ? 'selected' : '' ?>><?= $i ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <!-- Month Selection -->
                                    <div class="col-12">
                                        <label>Month</label>
                                        <select class="form-control" name="month" id="monthSelect4" required>
                                            <?php
                                            $currentMonth = date('n');  // Current month as a number (1-12)
                                            for ($month = 1; $month <= 12; $month++) {
                                                $monthName = date('F', mktime(0, 0, 0, $month, 1)); // Get full month name
                                                $selected = ($month == $currentMonth) ? 'selected' : '';
                                                echo "<option value=\"$month\" $selected>$monthName</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label>Value</label>
                                        <div class="input-group mb-2 me-sm-2">
                                            <div class="input-group-text">Value</div>
                                            <input type="number" step="0.01" class="form-control" name="itemvalue" placeholder="Value" required min="0">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn mt-3 btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php include 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const toast = document.getElementById('toast-success');

    document.querySelectorAll(".kpi-form").forEach(form => {
        form.addEventListener("submit", function(e) {
            e.preventDefault();

            const formData = new FormData(form);
            const submitButton = form.querySelector('button[type="submit"]');

            submitButton.disabled = true;
            submitButton.innerHTML = 'Saving...';

            fetch("Controller/optionalController.php", {
                method: "POST",
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(res => {
                if (res.trim() === "Success") {
                    form.reset();
                    showToast("Data saved successfully!", true);
                } else {
                    showToast("Error: " + res, false);
                }
            })
            .catch(error => {
                showToast("AJAX error: " + error.message, false);
            })
            .finally(() => {
                submitButton.disabled = false;
                submitButton.innerHTML = 'Submit';
            });
        });
    });

    function showToast(message, isSuccess) {
        toast.textContent = message;
        toast.style.backgroundColor = isSuccess ? '#28a745' : '#dc3545'; // Green or Red
        toast.style.display = 'block';

        setTimeout(() => {
            toast.style.display = 'none';
        }, 3000);
    }

    // Month restriction functionality
    const yearSelects = [
        { year: document.getElementById('yearSelect1'), month: document.getElementById('monthSelect1') },
        { year: document.getElementById('yearSelect2'), month: document.getElementById('monthSelect2') },
        { year: document.getElementById('yearSelect3'), month: document.getElementById('monthSelect3') },
        { year: document.getElementById('yearSelect4'), month: document.getElementById('monthSelect4') }
    ];

    function updateMonths(yearSelect, monthSelect) {
        if (!yearSelect || !monthSelect) return;
        
        const selectedYear = parseInt(yearSelect.value);
        const currentYear = new Date().getFullYear();
        const currentMonth = new Date().getMonth() + 1; // Current month (1-12)

        for (let month = 1; month <= 12; month++) {
            const monthOption = monthSelect.options[month - 1];
            if (monthOption) {
                if (selectedYear < currentYear) {
                    monthOption.disabled = false; // All months enabled for past years
                } else if (selectedYear === currentYear) {
                    monthOption.disabled = month > currentMonth; // Disable future months for current year
                } else {
                    monthOption.disabled = true; // Disable all months for future years
                }
            }
        }
    }

    // Initialize and set event listeners
    yearSelects.forEach(({ year, month }) => {
        if (year && month) {
            // Initialize on page load
            updateMonths(year, month);
            
            // Update when year changes
            year.addEventListener('change', function() {
                updateMonths(year, month);
            });
        }
    });
});
</script>