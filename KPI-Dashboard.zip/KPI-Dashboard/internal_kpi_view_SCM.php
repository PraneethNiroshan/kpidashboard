<?php
session_start();
include 'includes/header.php';
include 'includes/leftnav.php';

// Database connection
$con = mysqli_connect("localhost", "root", "", "kpi-dashboard");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Correct category mapping
$categoryNames = [
    20 => "Achievement of procurement time schedule (PTS)",
   
];

// Capture filters
$selectedYear = $_GET['year'] ?? '';
$selectedCategory = $_GET['categoryId'] ?? '';

// Prepare SQL query with prepared statement
$sql = "SELECT categoryId, year, month, itemvalue, created_at
        FROM kpi_data 
        WHERE categoryId IN (20)
        AND division_id = ?"; // Restrict to SCM division (division_id = 16)

if ($selectedYear !== '') {
    $sql .= " AND year = ?";
}
if ($selectedCategory !== '') {
    $sql .= " AND categoryId = ?";
}
$sql .= " ORDER BY year DESC, month DESC, created_at DESC";

$stmt = mysqli_prepare($con, $sql);
if ($stmt) {
    $bindParams = [];
    $types = 'i'; // Start with division_id as integer
    $params = [&$divisionId]; // division_id = 16 for SCM
    $divisionId = 16; // Hardcoded based on your divisionMap ['SCM' => 16]

    if ($selectedYear !== '') {
        $types .= 'i';
        $params[] = &$selectedYear;
    }
    if ($selectedCategory !== '') {
        $types .= 'i';
        $params[] = &$selectedCategory;
    }

    // Bind parameters
    array_unshift($params, $types); // Add types as the first parameter
    call_user_func_array([$stmt, 'bind_param'], $params);

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    die("Prepare failed: " . mysqli_error($con));
}
?>

<main class="content" style="padding-top: 80px;">
  <div class="container-fluid">
    <div class="header mb-3">
      <h1 class="header-title">Internal KPI View – SCM Division</h1>
    </div>

    <!-- Filter Form -->
    <form method="GET" class="row g-3 mb-4">
      <div class="col-md-4">
        <label for="year" class="form-label">Year</label>
        <select name="year" id="year" class="form-select">
          <option value="">All Years</option>
          <?php
            $currentYear = date('Y');
            for ($y = $currentYear - 5; $y <= $currentYear + 1; $y++): ?>
              <option value="<?= $y ?>" <?= ($selectedYear == $y) ? 'selected' : '' ?>><?= $y ?></option>
          <?php endfor; ?>
        </select>
      </div>

      <div class="col-md-4">
        <label for="categoryId" class="form-label">Category</label>
        <select name="categoryId" id="categoryId" class="form-select">
          <option value="">All Categories</option>
          <?php foreach ($categoryNames as $id => $name): ?>
            <option value="<?= $id ?>" <?= ($selectedCategory == $id) ? 'selected' : '' ?>>
              <?= $name ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4 d-flex align-items-end">
        <button type="submit" class="btn btn-primary">Filter</button>
        <a href="Internal_kpi_view_SCM.php" class="btn btn-secondary ms-2">Reset</a>
      </div>
    </form>

    <!-- KPI Table -->
    <div class="table-responsive">
      <table class="table table-bordered table-striped">
        <thead class="table-dark">
          <tr>
            <th>ID</th>
            <th>Category</th>
            <th>Year</th>
            <th>Month</th>
          
            <th>Value</th>
            <th>Submitted At</th>
          </tr>
        </thead>
        <tbody>
          <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
              <tr>
                <td><?= htmlspecialchars($row['categoryId']) ?></td>
                <td><?= htmlspecialchars($categoryNames[$row['categoryId']] ?? 'Unknown') ?></td>
                <td><?= htmlspecialchars($row['year']) ?></td>
                <td><?= ($row['month'] > 0 && $row['month'] <= 12) ? date('F', mktime(0, 0, 0, $row['month'], 1)) : 'N/A' ?></td>
               
                <td><?= htmlspecialchars($row['itemvalue']) ?></td>
                <td><?= htmlspecialchars($row['created_at']) ?></td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="7" class="text-center">No data available</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<?php
mysqli_stmt_close($stmt);
mysqli_close($con);
include 'includes/footer.php';
?>