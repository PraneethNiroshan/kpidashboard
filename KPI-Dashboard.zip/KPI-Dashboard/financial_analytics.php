<?php
include 'includes/header.php';
include 'includes/leftnav.php';

$con = mysqli_connect("localhost", "root", "", "kpi-dashboard");

// Get available years from DB
$years = [];
$yearResult = mysqli_query($con, "SELECT DISTINCT year FROM kpi_data ORDER BY year DESC");
while ($row = mysqli_fetch_assoc($yearResult)) {
    $years[] = $row['year'];
}

// Get available airports from DB
$airports = [];
$airportResult = mysqli_query($con, "SELECT DISTINCT airportId FROM kpi_data ORDER BY airportId");
while ($row = mysqli_fetch_assoc($airportResult)) {
    $airports[] = $row['airportId'];
}
$airportMap = [
    1 => 'BIA',
    2 => 'MRIA',
    3 => 'BTA',
    4 => 'JIA',
    5 => 'RMA',
];

// Month labels
$months = [
    0 => 'All',
    1 => 'January',
    2 => 'February',
    3 => 'March',
    4 => 'April',
    5 => 'May',
    6 => 'June',
    7 => 'July',
    8 => 'August',
    9 => 'September',
    10 => 'October',
    11 => 'November',
    12 => 'December'
];

$monthLabels = array_keys(array_filter($months, function($k) {
    return $k > 0;
}, ARRAY_FILTER_USE_KEY));

$filteredMonths = array_filter($months, function($k) {
    return $k > 0;
}, ARRAY_FILTER_USE_KEY);

// Chart 1: Aeronautical Revenue (32, 33, 46, 47)
$selectedYear1 = isset($_GET['year1']) ? intval($_GET['year1']) : date('Y');
$selectedMonth1 = isset($_GET['month1']) ? intval($_GET['month1']) : 0;
$selectedAirport1 = isset($_GET['airport1']) ? intval($_GET['airport1']) : 0;

$chartData1 = [];
$categories1 = [
    46 => 'Landing & Parking - International',
    47 => 'Landing & Parking - Domestic',
    32 => 'Aerobridge',
    33 => 'Overflying'
];

foreach ($categories1 as $catId => $catName) {
    $sql = "SELECT SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = $catId AND year = $selectedYear1";
    if ($selectedMonth1 > 0) {
        $sql .= " AND month = $selectedMonth1";
    }
    if ($selectedAirport1 > 0) {
        $sql .= " AND airportId = $selectedAirport1";
    }
    $result = mysqli_query($con, $sql);
    if ($result && $row = mysqli_fetch_assoc($result)) {
        $chartData1[$catName] = (int)(isset($row['total']) ? $row['total'] : 0);
    } else {
        $chartData1[$catName] = 0;
    }
}

// Chart 2: Non-Aeronautical Revenue (34-45)
$selectedYear2 = isset($_GET['year2']) ? intval($_GET['year2']) : date('Y');
$selectedMonth2 = isset($_GET['month2']) ? intval($_GET['month2']) : 0;
$selectedAirport2 = isset($_GET['airport2']) ? intval($_GET['airport2']) : 0;

$chartData2 = [];
$categories2 = [
    34 => 'Embarkation levy',
    35 => 'Concession',
    36 => 'Rental',
    37 => 'Entry Permits',
    38 => 'Fuel Throughput Charges',
    39 => 'Franchise Fee on Ground Handling - SLA',
    40 => 'Franchise Fee - SLCS',
    41 => 'Entry permits - PVG',
    42 => 'Parking Fees - Vehicles',
    43 => 'Domestic Ground Handling CIAR / BIA',
    44 => 'Other Non-Aeronautical Income',
    45 => 'Gross Profit from Lounges'
];

foreach ($categories2 as $catId => $catName) {
    $sql = "SELECT SUM(itemvalue) AS total FROM kpi_data WHERE categoryId = $catId AND year = $selectedYear2";
    if ($selectedMonth2 > 0) {
        $sql .= " AND month = $selectedMonth2";
    }
    if ($selectedAirport2 > 0) {
        $sql .= " AND airportId = $selectedAirport2";
    }
    $result = mysqli_query($con, $sql);
    if ($result && $row = mysqli_fetch_assoc($result)) {
        $chartData2[$catName] = (int)(isset($row['total']) ? $row['total'] : 0);
    } else {
        $chartData2[$catName] = 0;
    }
}

// Chart 3: Revenue per passenger (55)
$selectedYear3 = isset($_GET['year3']) ? intval($_GET['year3']) : date('Y');
$selectedMonth3 = isset($_GET['month3']) ? intval($_GET['month3']) : 0;
$selectedAirport3 = isset($_GET['airport3']) ? intval($_GET['airport3']) : 0;

$revPerPassData = array_fill_keys($monthLabels, 0);

$sql = "SELECT month, SUM(itemvalue) AS total 
        FROM kpi_data 
        WHERE year = ? AND categoryId = 55 AND frequencyId = 1";
$params = [$selectedYear3];
if ($selectedMonth3 > 0) {
    $sql .= " AND month = ?";
    $params[] = $selectedMonth3;
}
if ($selectedAirport3 > 0) {
    $sql .= " AND airportId = ?";
    $params[] = $selectedAirport3;
}
$sql .= " GROUP BY month ORDER BY month";

$stmt = mysqli_prepare($con, $sql);
if ($stmt) {
    $types = str_repeat('i', count($params));
    $bindParams = [$types];
    foreach ($params as $key => $value) {
        $bindParams[] = &$params[$key];
    }
    call_user_func_array([$stmt, 'bind_param'], $bindParams);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $month = $row['month'];
            $revPerPassData[$month] = (float)(isset($row['total']) ? $row['total'] : 0);
        }
    }
    mysqli_stmt_close($stmt);
}

// Chart 4: Operating expenses per passenger (56)
$selectedYear4 = isset($_GET['year4']) ? intval($_GET['year4']) : date('Y');
$selectedMonth4 = isset($_GET['month4']) ? intval($_GET['month4']) : 0;
$selectedAirport4 = isset($_GET['airport4']) ? intval($_GET['airport4']) : 0;

$opExpPerPassData = array_fill_keys($monthLabels, 0);

$sql = "SELECT month, SUM(itemvalue) AS total 
        FROM kpi_data 
        WHERE year = ? AND categoryId = 56 AND frequencyId = 1";
$params = [$selectedYear4];
if ($selectedMonth4 > 0) {
    $sql .= " AND month = ?";
    $params[] = $selectedMonth4;
}
if ($selectedAirport4 > 0) {
    $sql .= " AND airportId = ?";
    $params[] = $selectedAirport4;
}
$sql .= " GROUP BY month ORDER BY month";

$stmt = mysqli_prepare($con, $sql);
if ($stmt) {
    $types = str_repeat('i', count($params));
    $bindParams = [$types];
    foreach ($params as $key => $value) {
        $bindParams[] = &$params[$key];
    }
    call_user_func_array([$stmt, 'bind_param'], $bindParams);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $month = $row['month'];
            $opExpPerPassData[$month] = (float)(isset($row['total']) ? $row['total'] : 0);
        }
    }
    mysqli_stmt_close($stmt);
}

// Chart 5: Return on assets (ROA) (57)
$selectedYear5 = isset($_GET['year5']) ? intval($_GET['year5']) : date('Y');
$selectedMonth5 = isset($_GET['month5']) ? intval($_GET['month5']) : 0;
$selectedAirport5 = isset($_GET['airport5']) ? intval($_GET['airport5']) : 0;

$roaData = array_fill_keys($monthLabels, 0);

$sql = "SELECT month, SUM(itemvalue) AS total 
        FROM kpi_data 
        WHERE year = ? AND categoryId = 57 AND frequencyId = 1";
$params = [$selectedYear5];
if ($selectedMonth5 > 0) {
    $sql .= " AND month = ?";
    $params[] = $selectedMonth5;
}
if ($selectedAirport5 > 0) {
    $sql .= " AND airportId = ?";
    $params[] = $selectedAirport5;
}
$sql .= " GROUP BY month ORDER BY month";

$stmt = mysqli_prepare($con, $sql);
if ($stmt) {
    $types = str_repeat('i', count($params));
    $bindParams = [$types];
    foreach ($params as $key => $value) {
        $bindParams[] = &$params[$key];
    }
    call_user_func_array([$stmt, 'bind_param'], $bindParams);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $month = $row['month'];
            $roaData[$month] = (float)(isset($row['total']) ? $row['total'] : 0);
        }
    }
    mysqli_stmt_close($stmt);
}

// Chart 6: Cleanliness of the Airport rating (58)
$selectedYear6 = isset($_GET['year6']) ? intval($_GET['year6']) : date('Y');
$selectedMonth6 = isset($_GET['month6']) ? intval($_GET['month6']) : 0;
$selectedAirport6 = isset($_GET['airport6']) ? intval($_GET['airport6']) : 0;

$cleanRatingData = array_fill_keys($monthLabels, 0);

$sql = "SELECT month, SUM(itemvalue) AS total 
        FROM kpi_data 
        WHERE year = ? AND categoryId = 58 AND frequencyId = 1";
$params = [$selectedYear6];
if ($selectedMonth6 > 0) {
    $sql .= " AND month = ?";
    $params[] = $selectedMonth6;
}
if ($selectedAirport6 > 0) {
    $sql .= " AND airportId = ?";
    $params[] = $selectedAirport6;
}
$sql .= " GROUP BY month ORDER BY month";

$stmt = mysqli_prepare($con, $sql);
if ($stmt) {
    $types = str_repeat('i', count($params));
    $bindParams = [$types];
    foreach ($params as $key => $value) {
        $bindParams[] = &$params[$key];
    }
    call_user_func_array([$stmt, 'bind_param'], $bindParams);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $month = $row['month'];
            $cleanRatingData[$month] = (float)(isset($row['total']) ? $row['total'] : 0);
        }
    }
    mysqli_stmt_close($stmt);
}

// Chart 7: Net cash flow (59)
$selectedYear7 = isset($_GET['year7']) ? intval($_GET['year7']) : date('Y');
$selectedMonth7 = isset($_GET['month7']) ? intval($_GET['month7']) : 0;
$selectedAirport7 = isset($_GET['airport7']) ? intval($_GET['airport7']) : 0;

$netCashFlowData = array_fill_keys($monthLabels, 0);

$sql = "SELECT month, SUM(itemvalue) AS total 
        FROM kpi_data 
        WHERE year = ? AND categoryId = 59 AND frequencyId = 1";
$params = [$selectedYear7];
if ($selectedMonth7 > 0) {
    $sql .= " AND month = ?";
    $params[] = $selectedMonth7;
}
if ($selectedAirport7 > 0) {
    $sql .= " AND airportId = ?";
    $params[] = $selectedAirport7;
}
$sql .= " GROUP BY month ORDER BY month";

$stmt = mysqli_prepare($con, $sql);
if ($stmt) {
    $types = str_repeat('i', count($params));
    $bindParams = [$types];
    foreach ($params as $key => $value) {
        $bindParams[] = &$params[$key];
    }
    call_user_func_array([$stmt, 'bind_param'], $bindParams);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $month = $row['month'];
            $netCashFlowData[$month] = (float)(isset($row['total']) ? $row['total'] : 0);
        }
    }
    mysqli_stmt_close($stmt);
}
?>

<style>
/* Scroll position fix styles */
html {
    scroll-behavior: smooth;
}

body {
    scroll-behavior: auto;
}
</style>

<main class="content">
    <div class="container-fluid">
        <div class="header mb-3">
            <h1 class="header-title">Monthly Financial Charts</h1>

            
        </div>

        <!-- Combined Chart for 32, 33, 46, 47 (Aeronautical Revenue) -->
        <div class="card mb-4" id="chart1">
            <div class="card-header">
                <h5 class="card-title">Aeronautical Revenue (Categories 32, 33, 46, 47)</h5>
                <form method="GET" class="d-inline-block mt-2" id="form1">
                    <label for="year1" style="color: black;">Select Year:</label>
                    <select name="year1" id="year1" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart1')">
                        <?php foreach ($years as $year): ?>
                            <option value="<?= $year ?>" <?= $year == $selectedYear1 ? 'selected' : '' ?>><?= $year ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="month1" style="color: black; margin-left: 10px;">Select Month:</label>
                    <select name="month1" id="month1" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart1')">
                        <?php foreach ($months as $monthNum => $monthName): ?>
                            <option value="<?= $monthNum ?>" <?= $monthNum == $selectedMonth1 ? 'selected' : '' ?>><?= $monthName ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="airport1" style="color: black; margin-left: 10px;">Select Airport:</label>
                    <select name="airport1" id="airport1" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart1')">
                        <option value="0" <?= $selectedAirport1 == 0 ? 'selected' : '' ?>>All</option>
                        <?php foreach ($airportMap as $airportId => $airportName): ?>
                            <option value="<?= $airportId ?>" <?= $airportId == $selectedAirport1 ? 'selected' : '' ?>><?= $airportName ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>

                <div class="mb-4 text-end">
                    <a href="financial_analytics_Aero.php" class="btn btn-outline-primary">View Details</a>
                </div>
            </div>
            <div class="card-body" style="max-width: 400px; margin: auto;">
                <canvas id="combinedChart1" style="width: 100%; height: 300px;"></canvas>
            </div>
        </div>

        <!-- Combined Chart for 34 to 45 (Non-Aeronautical Revenue) -->
        <div class="card mb-4" id="chart2">
            <div class="card-header">
                <h5 class="card-title">Non-Aeronautical Revenue (Categories 34 to 45)</h5>
                <form method="GET" class="d-inline-block mt-2" id="form2">
                    <label for="year2" style="color: black;">Select Year:</label>
                    <select name="year2" id="year2" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart2')">
                        <?php foreach ($years as $year): ?>
                            <option value="<?= $year ?>" <?= $year == $selectedYear2 ? 'selected' : '' ?>><?= $year ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="month2" style="color: black; margin-left: 10px;">Select Month:</label>
                    <select name="month2" id="month2" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart2')">
                        <?php foreach ($months as $monthNum => $monthName): ?>
                            <option value="<?= $monthNum ?>" <?= $monthNum == $selectedMonth2 ? 'selected' : '' ?>><?= $monthName ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="airport2" style="color: black; margin-left: 10px;">Select Airport:</label>
                    <select name="airport2" id="airport2" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart2')">
                        <option value="0" <?= $selectedAirport2 == 0 ? 'selected' : '' ?>>All</option>
                        <?php foreach ($airportMap as $airportId => $airportName): ?>
                            <option value="<?= $airportId ?>" <?= $airportId == $selectedAirport2 ? 'selected' : '' ?>><?= $airportName ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>


                <div class="mb-4 text-end">
                    <a href="financial_analytics_NonAero.php" class="btn btn-outline-primary">View Details</a>
            </div>
            <div class="card-body" style="max-width: 400px; margin: auto;">
                <canvas id="combinedChart2" style="width: 100%; height: 300px;"></canvas>
            </div>
        </div>

        <!-- Chart 3: Revenue per passenger -->
        <div class="card mb-4" id="chart3">
            <div class="card-header">
                <h5 class="card-title">Revenue per passenger (Category 55)</h5>
                <form method="GET" class="d-inline-block mt-2" id="form3">
                    <label for="year3" style="color: black;">Select Year:</label>
                    <select name="year3" id="year3" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart3')">
                        <?php foreach ($years as $year): ?>
                            <option value="<?= $year ?>" <?= $year == $selectedYear3 ? 'selected' : '' ?>><?= $year ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="month3" style="color: black; margin-left: 10px;">Select Month:</label>
                    <select name="month3" id="month3" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart3')">
                        <?php foreach ($months as $monthNum => $monthName): ?>
                            <option value="<?= $monthNum ?>" <?= $monthNum == $selectedMonth3 ? 'selected' : '' ?>><?= $monthName ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="airport3" style="color: black; margin-left: 10px;">Select Airport:</label>
                    <select name="airport3" id="airport3" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart3')">
                        <option value="0" <?= $selectedAirport3 == 0 ? 'selected' : '' ?>>All</option>
                        <?php foreach ($airportMap as $airportId => $airportName): ?>
                            <option value="<?= $airportId ?>" <?= $airportId == $selectedAirport3 ? 'selected' : '' ?>><?= $airportName ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>

                <div class="mb-4 text-end">
                    <a href="financial_analytics_Revenue_per.php" class="btn btn-outline-primary">View Details</a>
                </div>
            </div>
            <div class="card-body">
                <canvas id="chart48" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 4: Operating expenses per passenger -->
        <div class="card mb-4" id="chart4">
            <div class="card-header">
                <h5 class="card-title">Operating expenses per passenger (Category 56)</h5>
                <form method="GET" class="d-inline-block mt-2" id="form4">
                    <label for="year4" style="color: black;">Select Year:</label>
                    <select name="year4" id="year4" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart4')">
                        <?php foreach ($years as $year): ?>
                            <option value="<?= $year ?>" <?= $year == $selectedYear4 ? 'selected' : '' ?>><?= $year ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="month4" style="color: black; margin-left: 10px;">Select Month:</label>
                    <select name="month4" id="month4" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart4')">
                        <?php foreach ($months as $monthNum => $monthName): ?>
                            <option value="<?= $monthNum ?>" <?= $monthNum == $selectedMonth4 ? 'selected' : '' ?>><?= $monthName ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="airport4" style="color: black; margin-left: 10px;">Select Airport:</label>
                    <select name="airport4" id="airport4" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart4')">
                        <option value="0" <?= $selectedAirport4 == 0 ? 'selected' : '' ?>>All</option>
                        <?php foreach ($airportMap as $airportId => $airportName): ?>
                            <option value="<?= $airportId ?>" <?= $airportId == $selectedAirport4 ? 'selected' : '' ?>><?= $airportName ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>

                <div class="mb-4 text-end">
                    <a href="financial_Operating expenses per.php" class="btn btn-outline-primary">View Details</a>
                </div>
            </div>
            <div class="card-body">
                <canvas id="chart49" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 5: Return on assets (ROA) -->
        <div class="card mb-4" id="chart5">
            <div class="card-header">
                <h5 class="card-title">Return on assets (ROA) (Category 57)</h5>
                <form method="GET" class="d-inline-block mt-2" id="form5">
                    <label for="year5" style="color: black;">Select Year:</label>
                    <select name="year5" id="year5" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart5')">
                        <?php foreach ($years as $year): ?>
                            <option value="<?= $year ?>" <?= $year == $selectedYear5 ? 'selected' : '' ?>><?= $year ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="month5" style="color: black; margin-left: 10px;">Select Month:</label>
                    <select name="month5" id="month5" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart5')">
                        <?php foreach ($months as $monthNum => $monthName): ?>
                            <option value="<?= $monthNum ?>" <?= $monthNum == $selectedMonth5 ? 'selected' : '' ?>><?= $monthName ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="airport5" style="color: black; margin-left: 10px;">Select Airport:</label>
                    <select name="airport5" id="airport5" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart5')">
                        <option value="0" <?= $selectedAirport5 == 0 ? 'selected' : '' ?>>All</option>
                        <?php foreach ($airportMap as $airportId => $airportName): ?>
                            <option value="<?= $airportId ?>" <?= $airportId == $selectedAirport5 ? 'selected' : '' ?>><?= $airportName ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>

                <div class="mb-4 text-end">
                    <a href="financial_return_on_assets.php" class="btn btn-outline-primary">View Details</a>
                </div>
            </div>
            <div class="card-body">
                <canvas id="chart50" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 6: Cleanliness of the Airport rating -->
        <div class="card mb-4" id="chart6">
            <div class="card-header">
                <h5 class="card-title">Cleanliness of the Airport rating (Category 58)</h5>
                <form method="GET" class="d-inline-block mt-2" id="form6">
                    <label for="year6" style="color: black;">Select Year:</label>
                    <select name="year6" id="year6" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart6')">
                        <?php foreach ($years as $year): ?>
                            <option value="<?= $year ?>" <?= $year == $selectedYear6 ? 'selected' : '' ?>><?= $year ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="month6" style="color: black; margin-left: 10px;">Select Month:</label>
                    <select name="month6" id="month6" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart6')">
                        <?php foreach ($months as $monthNum => $monthName): ?>
                            <option value="<?= $monthNum ?>" <?= $monthNum == $selectedMonth6 ? 'selected' : '' ?>><?= $monthName ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="airport6" style="color: black; margin-left: 10px;">Select Airport:</label>
                    <select name="airport6" id="airport6" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart6')">
                        <option value="0" <?= $selectedAirport6 == 0 ? 'selected' : '' ?>>All</option>
                        <?php foreach ($airportMap as $airportId => $airportName): ?>
                            <option value="<?= $airportId ?>" <?= $airportId == $selectedAirport6 ? 'selected' : '' ?>><?= $airportName ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>

                <div class="mb-4 text-end">
                    <a href="financial_airport_cleanliness.php" class="btn btn-outline-primary">View Details</a>
                </div>
            </div>
            <div class="card-body">
                <canvas id="chart51" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>

        <!-- Chart 7: Net cash flow -->
        <div class="card mb-4" id="chart7">
            <div class="card-header">
                <h5 class="card-title">Net cash flow (Category 59)</h5>
                <form method="GET" class="d-inline-block mt-2" id="form7">
                    <label for="year7" style="color: black;">Select Year:</label>
                    <select name="year7" id="year7" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart7')">
                        <?php foreach ($years as $year): ?>
                            <option value="<?= $year ?>" <?= $year == $selectedYear7 ? 'selected' : '' ?>><?= $year ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="month7" style="color: black; margin-left: 10px;">Select Month:</label>
                    <select name="month7" id="month7" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart7')">
                        <?php foreach ($months as $monthNum => $monthName): ?>
                            <option value="<?= $monthNum ?>" <?= $monthNum == $selectedMonth7 ? 'selected' : '' ?>><?= $monthName ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label for="airport7" style="color: black; margin-left: 10px;">Select Airport:</label>
                    <select name="airport7" id="airport7" class="form-select form-select-sm w-auto d-inline-block" onchange="submitFormWithScroll(this.form, 'chart7')">
                        <option value="0" <?= $selectedAirport7 == 0 ? 'selected' : '' ?>>All</option>
                        <?php foreach ($airportMap as $airportId => $airportName): ?>
                            <option value="<?= $airportId ?>" <?= $airportId == $selectedAirport7 ? 'selected' : '' ?>><?= $airportName ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>

                <div class="mb-4 text-end">
                    <a href="financial_net_cash_flow.php" class="btn btn-outline-primary">View Details</a>
                </div>
            </div>
            <div class="card-body">
                <canvas id="chart52" style="width: 20%; height: 40px;"></canvas>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Scroll position management functions
function submitFormWithScroll(form, chartId) {
    // Collect ALL current GET parameters
    const currentParams = new URLSearchParams(window.location.search);
    
    // Get the form data
    const formData = new FormData(form);
    
    // Create new URL with all parameters
    const newParams = new URLSearchParams();
    
    // First add all existing parameters
    currentParams.forEach((value, key) => {
        newParams.set(key, value);
    });
    
    // Then override with form parameters
    formData.forEach((value, key) => {
        newParams.set(key, value);
    });
    
    // Store scroll position
    sessionStorage.setItem('scrollPosition', window.pageYOffset || document.documentElement.scrollTop);
    sessionStorage.setItem('targetChart', chartId);
    
    // Redirect with all parameters preserved
    window.location.href = window.location.pathname + '?' + newParams.toString();
}

// Restore scroll position after page load
window.addEventListener('load', function() {
    const scrollPosition = sessionStorage.getItem('scrollPosition');
    const targetChart = sessionStorage.getItem('targetChart');
    
    if (scrollPosition !== null && targetChart) {
        // Wait for page to fully render
        setTimeout(function() {
            const chartElement = document.getElementById(targetChart);
            if (chartElement) {
                // Smooth scroll to chart with offset
                const rect = chartElement.getBoundingClientRect();
                const offsetTop = window.pageYOffset + rect.top - 20;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
            // Clean up
            sessionStorage.removeItem('scrollPosition');
            sessionStorage.removeItem('targetChart');
        }, 300);
    }
});

const data1 = <?php echo json_encode(array_values($chartData1)); ?>;
const labels1 = <?php echo json_encode(array_keys($chartData1)); ?>;

const data2 = <?php echo json_encode(array_values($chartData2)); ?>;
const labels2 = <?php echo json_encode(array_keys($chartData2)); ?>;

const monthLabels = <?php echo json_encode(array_values($filteredMonths)); ?>;

// Function to generate dynamic colors
function getDynamicColors(count) {
    const colors = [];
    for (let i = 0; i < count; i++) {
        const hue = (i * 360) / count;
        colors.push(`hsla(${hue}, 70%, 50%, 0.6)`);
    }
    return colors;
}

// Combined Doughnut Chart 1 (Aeronautical Revenue)
new Chart(document.getElementById('combinedChart1').getContext('2d'), {
    type: 'doughnut',
    data: {
        labels: labels1,
        datasets: [{
            label: 'Category Totals',
            data: data1,
            backgroundColor: [
                "rgba(75, 192, 192, 0.7)",   // teal
                "rgba(153, 102, 255, 0.7)",  // purple
                "rgba(255, 159, 64, 0.7)",   // orange
                "rgba(255, 205, 86, 0.7)",   // yellow
                "rgba(54, 162, 235, 0.7)",   // blue
                "rgba(201, 203, 207, 0.7)"   // gray
            ],
            borderColor: "#fff",
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: `Aeronautical Revenue (32, 33, 46, 47) - <?= $selectedYear1 ?><?= $selectedMonth1 > 0 ? ' - ' . $months[$selectedMonth1] : '' ?><?= $selectedAirport1 > 0 ? ' - ' . $airportMap[$selectedAirport1] : '' ?>`
            },
            legend: {
                position: "right"
            }
        }
    }
});

// Combined Doughnut Chart 2 (Non-Aeronautical Revenue)
new Chart(document.getElementById('combinedChart2').getContext('2d'), {
    type: 'doughnut',
    data: {
        labels: labels2,
        datasets: [{
            label: 'Category Totals',
            data: data2,
            backgroundColor: getDynamicColors(<?php echo count($categories2); ?>),
            borderColor: '#fff',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: `Non-Aeronautical Revenue (34 to 45) - <?= $selectedYear2 ?><?= $selectedMonth2 > 0 ? ' - ' . $months[$selectedMonth2] : '' ?><?= $selectedAirport2 > 0 ? ' - ' . $airportMap[$selectedAirport2] : '' ?>`
            },
            legend: {
                position: 'right'
            }
        }
    }
});

// Chart 3: Revenue per passenger
new Chart(document.getElementById('chart48').getContext('2d'), {
    type: 'bar',
    data: {
        labels: monthLabels,
        datasets: [{
            label: 'Revenue per passenger',
            data: <?php echo json_encode(array_values($revPerPassData)); ?>,
            backgroundColor: 'rgba(255, 99, 132, 0.6)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: `Revenue per passenger - <?= $selectedYear3 ?><?= $selectedMonth3 > 0 ? ' - ' . $months[$selectedMonth3] : '' ?><?= $selectedAirport3 > 0 ? ' - ' . $airportMap[$selectedAirport3] : '' ?>`
            },
            legend: {
                position: 'top'
            }
        },
        scales: {
            x: {
                title: { display: true, text: 'Month' }
            },
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Value' }
            }
        }
    }
});

// Chart 4: Operating expenses per passenger
new Chart(document.getElementById('chart49').getContext('2d'), {
    type: 'bar',
    data: {
        labels: monthLabels,
        datasets: [{
            label: 'Operating expenses per passenger',
            data: <?php echo json_encode(array_values($opExpPerPassData)); ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: `Operating expenses per passenger - <?= $selectedYear4 ?><?= $selectedMonth4 > 0 ? ' - ' . $months[$selectedMonth4] : '' ?><?= $selectedAirport4 > 0 ? ' - ' . $airportMap[$selectedAirport4] : '' ?>`
            },
            legend: {
                position: 'top'
            }
        },
        scales: {
            x: {
                title: { display: true, text: 'Month' }
            },
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Value' }
            }
        }
    }
});

// Chart 5: Return on assets (ROA)
new Chart(document.getElementById('chart50').getContext('2d'), {
    type: 'bar',
    data: {
        labels: monthLabels,
        datasets: [{
            label: 'Return on assets (ROA)',
            data: <?php echo json_encode(array_values($roaData)); ?>,
            backgroundColor: 'rgba(255, 206, 86, 0.6)',
            borderColor: 'rgba(255, 206, 86, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: `Return on assets (ROA) - <?= $selectedYear5 ?><?= $selectedMonth5 > 0 ? ' - ' . $months[$selectedMonth5] : '' ?><?= $selectedAirport5 > 0 ? ' - ' . $airportMap[$selectedAirport5] : '' ?>`
            },
            legend: {
                position: 'top'
            }
        },
        scales: {
            x: {
                title: { display: true, text: 'Month' }
            },
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Value' }
            }
        }
    }
});

// Chart 6: Cleanliness of the Airport rating
new Chart(document.getElementById('chart51').getContext('2d'), {
    type: 'bar',
    data: {
        labels: monthLabels,
        datasets: [{
            label: 'Cleanliness of the Airport rating',
            data: <?php echo json_encode(array_values($cleanRatingData)); ?>,
            backgroundColor: 'rgba(75, 192, 192, 0.6)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: `Cleanliness of the Airport rating - <?= $selectedYear6 ?><?= $selectedMonth6 > 0 ? ' - ' . $months[$selectedMonth6] : '' ?><?= $selectedAirport6 > 0 ? ' - ' . $airportMap[$selectedAirport6] : '' ?>`
            },
            legend: {
                position: 'top'
            }
        },
        scales: {
            x: {
                title: { display: true, text: 'Month' }
            },
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Value' }
            }
        }
    }
});

// Chart 7: Net cash flow
new Chart(document.getElementById('chart52').getContext('2d'), {
    type: 'bar',
    data: {
        labels: monthLabels,
        datasets: [{
            label: 'Net cash flow',
            data: <?php echo json_encode(array_values($netCashFlowData)); ?>,
            backgroundColor: 'rgba(153, 102, 255, 0.6)',
            borderColor: 'rgba(153, 102, 255, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: `Net cash flow - <?= $selectedYear7 ?><?= $selectedMonth7 > 0 ? ' - ' . $months[$selectedMonth7] : '' ?><?= $selectedAirport7 > 0 ? ' - ' . $airportMap[$selectedAirport7] : '' ?>`
            },
            legend: {
                position: 'top'
            }
        },
        scales: {
            x: {
                title: { display: true, text: 'Month' }
            },
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Value' }
            }
        }
    }
});

// Preserve all GET parameters from other forms
function preserveGetParameters(form, chartId) {
    const urlParams = new URLSearchParams(window.location.search);
    const formData = new FormData(form);
    
    // Collect all current GET parameters
    const allParams = new URLSearchParams();
    urlParams.forEach((value, key) => {
        allParams.set(key, value);
    });
    
    // Update with new form data
    formData.forEach((value, key) => {
        allParams.set(key, value);
    });
    
    // Store scroll position and target chart
    sessionStorage.setItem('scrollPosition', window.pageYOffset || document.documentElement.scrollTop);
    sessionStorage.setItem('targetChart', chartId);
    
    // Redirect with all parameters
    window.location.search = allParams.toString();
}

// Update submitFormWithScroll to use preserveGetParameters
function submitFormWithScroll(form, chartId) {
    preserveGetParameters(form, chartId);
}
</script>

<?php include 'includes/footer.php'; ?>