//Jquery to manage data
$( document ).ready(function() {
 //load relavant columns and datset
 // window.addEventListener('load', getFinancialData(), false);
//get the name of page and load data
    
var path = window.location.pathname;
var page = path.split("/").pop();
    
//Financial data management    
 
if(page =="financial.php")
{
   getFinancialData();
}
    
 
function getFinancialData()
{
        $.ajax({
          type: "POST",
          url: 'Controller/financialController.php',           
          dataType: "json",
          data: { "financialList": 1},
          success: function(data) 
            { 
                
                var len = data.length;
                
                for( var i = 0; i<len; i++){                    
                    var id = data[i]['id'];
                    var cateogry = data[i]['category'];                  
                          
                    
                    $("#cardList").append("<div class='row'><div class='col-12'><div class='card'><div class='card-header'><h1 class='card-title mb-0'>"+cateogry+"</h1></div><div class='card-body'><div class='my-5'  id='cat"+id+"'>&nbsp;</div></div></div></div></div>");
                    getLevelData1(id);
                }
                
                					

            },
            error: function(XMLHttpRequest, textStatus, errorThrown) { 


            } 


          }); 
}
    
function getLevelData1($id)
{
        $.ajax({
          type: "POST",
          url: 'Controller/financialController.php',           
          dataType: "json",
          data: { "financialList": $id},
          success: function(data) 
            { 
                
                var len = data.length;
                $("#cat"+$id).append("<div class='tab'>	<ul class='nav nav-tabs' role='tablist'>");
                for( var i = 0; i<len; i++){                    
                    var id = data[i]['id'];
                    var cateogry = data[i]['category'];  
                    
                    $("#cat"+$id).append("<li class='nav-item'><a class='nav-link active' href='#tab"+id+"' data-bs-toggle='tab' role='tab'>"+cateogry+"</a></li>");
                    
                   // $("#cat"+$id).append("<div class='row'><div class='col-12'><div class='card'><div class='card-header'><h5 class='card-title mb-0'>"+cateogry+"</h5></div><div class='card-body'><div class='my-5' id='subcat"+id+"'>&nbsp;</div></div></div></div></div>");
                   //getLevelData2(id);
                    

                    
                }
                
                 for( var i = 0; i<len; i++){                    
                    var id = data[i]['id'];
                    var cateogry = data[i]['category'];  
                    
                    $("#cat"+$id).append("<div class='tab-pane active' id='tab"+id+"' role='tabpanel'><h4 class=tab-title'>Default tabs</h4><p></p></div>");
                    
                   // $("#cat"+$id).append("<div class='row'><div class='col-12'><div class='card'><div class='card-header'><h5 class='card-title mb-0'>"+cateogry+"</h5></div><div class='card-body'><div class='my-5' id='subcat"+id+"'>&nbsp;</div></div></div></div></div>");
                   //getLevelData2(id);
                    

                    
                }
                
                $("#cat"+$id).append("</ul></div>");
                					

            },
            error: function(XMLHttpRequest, textStatus, errorThrown) { 


            } 


          }); 
}
    
function getLevelData2($id)
{
        $.ajax({
          type: "POST",
          url: 'Controller/financialController.php',           
          dataType: "json",
          data: { "financialList": $id},
          success: function(data) 
            { 
                
                var len = data.length;
                
                if(len >0)
                {
                    for( var i = 0; i<len; i++){                    
                    var id = data[i]['id'];
                    var cateogry = data[i]['category'];                
                    $("#subcat"+$id).append("<div class='row'><div class='col-12'><div class='card'><div class='card-header'><h5 class='card-title mb-0'>"+cateogry+"</h5></div><div class='card-body'><div class='my-5' >&nbsp;</div></div></div></div></div>");
                    
                    }   
                }
                else
                {
                    
                    
                }
                
                          
                					

            },
            error: function(XMLHttpRequest, textStatus, errorThrown) { 


            } 


          }); 
}
     
    
    
});